# Missing modules and implementation status after v0.1.7

| Capability | Status | Notes |
|---|---|---|
| Federation peer tenant-admin privilege escalation | Hardened | Registration creates pending disabled peer; independent activation UI still missing |
| Federation handling visibility | Hardened baseline | Only TLP:CLEAR/WHITE shown through shared listing; no full marking-policy engine |
| Federation ingress | Partial | Size/rate limits and HMAC; mTLS must be enforced at trusted ingress |
| CSV formula injection | Fixed | Formula-leading cells neutralized and quoted |
| Production security headers | Baseline added | Reverse-proxy TLS and deployment review still required |
| Database migrations | Foundation added | Bootstrap migration; future revisions must be generated and reviewed |
| Backup coverage | Expanded | Organization data v2; validation is dry-run, not restore |
| Sensor durability | Partial | HTTP retry improved; durable offset/queue still missing |
| MFA / SSO / account recovery | Missing | Requires identity architecture and UI |
| Global/National threat map | Missing | Requires real, consented telemetry and geospatial pipeline |
| EDR / cloud / Kubernetes integrations | Missing | Connector frameworks and deployment-specific credentials required |
| Chain of custody / evidence vault | Missing | Requires immutable storage, hashing, access logging and retention controls |
| Multi-country sovereign governance UI | Missing | Needs platform authority, legal agreements and human approval process |

Do not represent missing capabilities as implemented. Integrations require operator configuration and real data sources; a dashboard mockup is not live telemetry.
