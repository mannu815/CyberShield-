"""Bounded, defensive normalizers for Wazuh, Suricata EVE and Zeek JSON events."""
from __future__ import annotations
import hashlib, ipaddress, json
from datetime import datetime, timezone
from typing import Any

SOURCES = {"wazuh", "suricata", "zeek"}
SEVERITIES = {"critical", "high", "medium", "low", "info"}
SENSITIVE = ("password", "passwd", "token", "secret", "cookie", "authorization", "api_key", "session")

def _clean(value: Any, limit: int = 500) -> str:
    if value is None: return ""
    if isinstance(value, (dict, list)): value = json.dumps(value, separators=(",", ":"), default=str)
    return str(value).replace("\x00", "")[:limit]

def _ip(value: Any) -> str | None:
    try: return str(ipaddress.ip_address(str(value))) if value else None
    except ValueError: return None

def _time(value: Any) -> datetime:
    if isinstance(value, (int, float)):
        try: return datetime.fromtimestamp(value, timezone.utc)
        except (ValueError, OSError, OverflowError): return datetime.now(timezone.utc)
    if isinstance(value, str):
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            return parsed.replace(tzinfo=timezone.utc) if parsed.tzinfo is None else parsed
        except ValueError: pass
    return datetime.now(timezone.utc)

def _attrs(raw: dict) -> dict:
    out = {}
    for key, value in list(raw.items())[:40]:
        k = _clean(key, 64)
        if any(s in k.lower() for s in SENSITIVE): continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            out[k] = value if not isinstance(value, str) else value[:500]
    return out

def normalize(source: str, raw: dict) -> dict:
    if source not in SOURCES or not isinstance(raw, dict): raise ValueError("Unsupported event source or invalid event")
    if source == "wazuh":
        data = raw.get("data") if isinstance(raw.get("data"), dict) else {}
        rule = raw.get("rule") if isinstance(raw.get("rule"), dict) else {}
        agent = raw.get("agent") if isinstance(raw.get("agent"), dict) else {}
        level = int(rule.get("level", 0) or 0)
        severity = "critical" if level >= 14 else "high" if level >= 10 else "medium" if level >= 7 else "low" if level >= 4 else "info"
        event_type = _clean(rule.get("id") or raw.get("event_type") or "wazuh.alert", 80)
        message = _clean(raw.get("full_log") or rule.get("description") or "Wazuh alert", 2000)
        src_ip = _ip(data.get("srcip") or data.get("src_ip")); dst_ip = _ip(data.get("dstip") or data.get("dst_ip"))
        ts = _time(raw.get("timestamp"))
        attrs = {"rule_id": _clean(rule.get("id"), 40), "rule_level": level, "agent_id": _clean(agent.get("id"), 40), "agent_name": _clean(agent.get("name"), 120), "decoder": _clean((raw.get("decoder") or {}).get("name") if isinstance(raw.get("decoder"), dict) else "", 80), **_attrs(data)}
    elif source == "suricata":
        alert = raw.get("alert") if isinstance(raw.get("alert"), dict) else {}
        sev = int(alert.get("severity", 3) or 3)
        severity = "critical" if sev == 1 else "high" if sev == 2 else "medium" if sev == 3 else "info"
        event_type = _clean(raw.get("event_type") or "suricata.event", 80)
        message = _clean(alert.get("signature") or raw.get("event_type") or "Suricata event", 2000)
        src_ip, dst_ip = _ip(raw.get("src_ip")), _ip(raw.get("dest_ip"))
        ts = _time(raw.get("timestamp"))
        attrs = {"signature_id": _clean(alert.get("signature_id"), 40), "category": _clean(alert.get("category"), 120), "action": _clean(alert.get("action"), 40), "src_port": raw.get("src_port") if isinstance(raw.get("src_port"), int) else None, "dest_port": raw.get("dest_port") if isinstance(raw.get("dest_port"), int) else None, "proto": _clean(raw.get("proto"), 20), "flow_id": _clean(raw.get("flow_id"), 40)}
    else:
        event_type = _clean(raw.get("_path") or raw.get("event_type") or "zeek.event", 80)
        message = _clean(raw.get("notice") or raw.get("note") or event_type, 2000)
        src_ip, dst_ip = _ip(raw.get("id.orig_h") or raw.get("src_ip")), _ip(raw.get("id.resp_h") or raw.get("dst_ip"))
        ts = _time(raw.get("ts") or raw.get("timestamp"))
        attrs = {"uid": _clean(raw.get("uid"), 80), "proto": _clean(raw.get("proto"), 20), "service": _clean(raw.get("service"), 40), "conn_state": _clean(raw.get("conn_state"), 20), "orig_bytes": raw.get("orig_bytes") if isinstance(raw.get("orig_bytes"), int) else None, "resp_bytes": raw.get("resp_bytes") if isinstance(raw.get("resp_bytes"), int) else None, "orig_pkts": raw.get("orig_pkts") if isinstance(raw.get("orig_pkts"), int) else None, "resp_pkts": raw.get("resp_pkts") if isinstance(raw.get("resp_pkts"), int) else None}
        severity = "medium" if event_type in {"notice", "weird"} else "info"
    attrs = {k:v for k,v in attrs.items() if v is not None and v != ""}
    canonical = {"source":source,"event_type":event_type,"event_time":ts.isoformat() if (raw.get("timestamp") or raw.get("ts")) else None,"src_ip":src_ip,"dst_ip":dst_ip,"severity":severity,"message":message,"attributes":attrs}
    fingerprint = hashlib.sha256(json.dumps(canonical, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
    return {**canonical, "fingerprint":fingerprint, "event_time":ts}
