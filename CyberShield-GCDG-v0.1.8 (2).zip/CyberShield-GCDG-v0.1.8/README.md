# CyberShield AI / GCDG — v0.1.7 Security Hardening Foundation

An open-source-first portfolio project combining secure multi-tenant APIs, evidence-based security assessment, cloud configuration analysis, curated threat intelligence and AI-assisted explanations.

> **Release status: engineering MVP / local validation required.** This is not a production-ready commercial scanner. It does not perform autonomous exploitation or arbitrary live-target scanning. Findings from supplied evidence are indicators requiring human validation.

## Implemented in this package

- FastAPI and SQLAlchemy foundation.
- Argon2 password hashing; short-lived JWT authentication.
- Admin, analyst and viewer roles.
- Organization-scoped users, assets, assessments, findings, events and audit logs.
- Admin-provisioned accounts; no public self-registration.
- Login and API rate limits (in-memory development limiter).
- Asset registration requiring an authorization reference.
- HTTP security-header evidence analysis (supplied header snapshot; no outbound target requests).
- Offline JSON cloud/IaC configuration checks for public storage, broad administrative ingress and wildcard IAM actions.
- Curated CVE record API with known-exploited flag.
- Deterministic AI explanation fallback clearly marked as non-generative.
- JSON assessment report export.
- Initial architecture and threat model.

## Quick start — Windows 11

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Put the generated secret in `.env` as `JWT_SECRET`. Do not commit `.env`.

```powershell
python -m scripts.bootstrap_admin --organization "CyberShield Lab" --email "YOUR_EMAIL" --name "Project Admin"
pytest -q
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs`.

## API workflow

1. `POST /api/v1/auth/token` with form fields `username` and `password`.
2. Authorize Swagger with the returned bearer token.
3. `POST /api/v1/assets` as admin/analyst. Include `name`, `target`, and an authorization ticket/contract reference.
4. `POST /api/v1/assets/{id}/assessments/headers` with a previously collected, authorized HTTP response-header snapshot.
5. `POST /api/v1/assets/{id}/assessments/cloud-config` with normalized JSON configuration evidence.
6. View `/api/v1/assessments`, `/api/v1/assessments/{id}/findings`, `/api/v1/findings/{id}/explanation` and `/api/v1/reports/assessments/{id}.json`.
7. Use the Phase 3 `/api/v1/threat-intel/*` endpoints to configure, sync and review NVD/CISA KEV/MISP/OpenCTI intelligence; the earlier curated-record API remains available.

## Important limitations

- Current header analysis accepts evidence supplied by the user; it does not fetch URLs.
- Cloud checks analyze normalized JSON only; no AWS/Azure account connector is included.
- The AI endpoint is a deterministic fallback, not an LLM integration.
- Phase 3 feed ingestion is manual and bounded; no scheduled worker or full historical NVD mirror is included.
- Rate limiting is in-memory and unsuitable for multi-worker production.
- Development uses SQLAlchemy `create_all()`; production startup does not create tables. Use Alembic (`alembic upgrade head`) and review every future migration.
- v0.1.7 hardens peer registration, federation visibility, CSV exports, response headers, production configuration, backup coverage and CI configuration.
- Federation peer registration now creates a disabled pending request. A platform-level sovereign approval workflow is not yet implemented; do not activate peers without an independently audited process.
- The included backup export is organization-scoped and broader than v0.1.6, but validation is dry-run only and restore is not implemented.
- Use PostgreSQL, Redis-backed rate limiting, trusted-ingress mTLS, managed secrets, off-host backups, monitoring, externalized audit storage, and formal security testing before any public deployment.

## Documentation

- `docs/ARCHITECTURE.md`
- `docs/THREAT_MODEL.md`
- `docs/ROADMAP.md`

## Safety

Only register assets for which you have explicit authorization. Do not use this project for brute force, denial-of-service, destructive testing, credential theft or unauthorized access. AI explanations are advisory and must not be treated as proof of exploitability.

## Legacy v1.8 preservation

The `legacy_v1_8/` directory contains a copy of the supplied v1.8 application for reference and migration. It is intentionally not mounted into the new API process. Keep the legacy database backed up and do not run both applications against the same SQLite database. Migrate useful modules one at a time after adapting their authentication, tenant ownership and scope enforcement.

## Docker (local development only)

Create `.env` and set a strong `JWT_SECRET`, then:

```bash
docker compose up --build
```

The API binds to `127.0.0.1:8000` on the host. Do not expose this development compose configuration directly to the public internet.

## CI

GitHub Actions runs compile checks, pytest, Bandit and pip-audit. A clean CI run is necessary but not sufficient for a production security claim.

## Global Cyber Defence Grid foundation

See `docs/GLOBAL_DEFENCE_GRID.md` for the sovereign federated architecture, ten command systems, operating rules, data contracts, response lifecycle and production acceptance gates. The foundation adds framework-neutral event normalization, deterministic reference detections, guarded response proposals and policy-gated indicator export under `app/global_grid/`. These are local engineering primitives, not a live global security network.

See `docs/DEPLOYMENT_NOTES.md` for Windows setup and production hardening requirements.

## GCDG federation signing increment (v0.1.1)

The `app/global_grid/signing.py` module provides a minimized HMAC-signed indicator envelope for development peer exchange. It enforces explicit policy approval, peer routing, freshness, payload integrity, indicator validation and restricted handling labels. v0.1.2 wires this to a persistent federation gateway. See `docs/FEDERATION_SIGNING_V0_1_1.md` for security boundaries and production requirements.

## Sovereign federation gateway (v0.1.2)

The federation gateway accepts only approved, signed threat indicators. It does not accept commands, remote execution tasks, or automated response instructions.

1. Generate a Fernet encryption key: `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"`.
2. Set `GCDG_FERNET_KEY` and a unique `GCDG_FEDERATION_NODE_ID` in `.env` on each node.
3. Submit a peer registration request as an organization admin. The peer remains disabled and unapproved until independent platform-level sovereign review; tenant admins cannot activate global peers. Transfer any provisioned shared HMAC secret using an independent secure channel.
4. Put `/api/v1/federation/*` behind mTLS, firewall allowlists, request-size limits and monitoring. HMAC envelope verification is an additional application-level control, not a replacement for mTLS.
5. Send only minimized, non-restricted indicators. Ingested indicators are stored locally; no response action is triggered.

The gateway uses SQL uniqueness constraints for replay nonces and duplicate sender/payload detection, and prunes expired replay records during ingestion. Federation mTLS must be enforced at a trusted ingress. Production schema management uses Alembic; see `RELEASE_NOTES_v0.1.7.md`.


See `docs/PHASE_STATUS.md` for the honest ten-phase GCDG delivery status and acceptance gates.


## Threat intelligence ingestion (GCDG v0.1.3 / Phase 3)

Phase 3 adds bounded, manually initiated NVD and CISA KEV ingestion, plus optional MISP and OpenCTI connectors. CVE/IOC records and sync history are organization-scoped; ingestion is audited and rate-limited. Review `docs/THREAT_INTELLIGENCE_PHASE3.md` for connector configuration, API routes, data limitations and safe operation. Feed matches are advisory only and never trigger automatic blocking or response.


## Phase 4 — Real-time Defensive Detection

Phase 4 adds Wazuh, Suricata and Zeek JSON event ingestion, organization-scoped sensor keys, event deduplication, starter correlation rules and a human-reviewed alert API. See `docs/DETECTION_PHASE4.md` for sensor setup, endpoint details and safe synthetic test events. This is an MVP integration layer; no live sensor deployment is bundled and no automated blocking/response is performed.


## Phase 5 — SOC Dashboard & Incident Case Management (v0.1.5)

Open `http://127.0.0.1:8000/soc` after starting the API. Paste a valid access token to load the organization-scoped dashboard. The token is held in page memory only. Analysts/admins can create and update incident cases, link alerts, assign cases to active users in the same organization, add investigation notes and review timelines. JSON/CSV exports are available from the dashboard or `GET /api/v1/incidents/export?format=json|csv`. See `docs/PHASE5_SOC_INCIDENTS.md`.

## Phases 6–10 (v0.1.6)

This release adds evidence-grounded analyst decision support, asset risk profiles, assurance evidence tracking, organization-scoped backup export/checksum validation, operational readiness checks, and sovereign governance decision records. See [`docs/PHASES6_TO10.md`](docs/PHASES6_TO10.md) for API endpoints and limitations. These capabilities are MVPs; no external LLM, live government SOC integration, certified compliance assessment, or automatic restore is included.

## Phases 6–10 — v0.1.6
See [`docs/PHASES6_TO10.md`](docs/PHASES6_TO10.md). Includes deterministic evidence-based case analysis, asset risk context, assurance evidence, backup validation and sovereign governance records. It is intentionally not marketed as autonomous AI or certified national infrastructure.
