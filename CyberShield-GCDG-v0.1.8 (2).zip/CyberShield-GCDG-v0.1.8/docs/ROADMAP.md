# Engineering roadmap and honest release gates

## Milestone A — Secure platform foundation (implemented in this package; validate locally)
Auth, roles, organization records, audit logs, asset inventory, rate limiting, evidence analysis, JSON reports, threat record CRUD and deterministic explanations.

## Milestone B — Assessment engine
Build isolated passive HTTP/TLS workers only after DNS pinning, strict allowlist matching, redirect revalidation, egress filtering, bounded concurrency and per-target request budgets are tested. Add safe static checks and optional integrations (ZAP baseline, Semgrep, Trivy, Checkov) behind explicit user-approved profiles.

## Milestone C — Threat intelligence
Phase 3 MVP now includes manual, bounded NVD/CISA KEV ingestion and optional MISP/OpenCTI connectors, tenant-scoped IOC/CVE storage, provenance, deduplication, sync history and exact IOC correlation. Remaining work: scheduled ingestion, durable incremental cursors, broader STIX parsing, stale-feed monitoring, source terms review and asset/software-version correlation. Do not treat CVE presence alone as proof that an asset is vulnerable.

## Milestone D — AI security analyst
Add a provider abstraction with local/free model option where hardware permits. Use retrieval from curated CWE/CVE/OWASP content. Require structured output, citations to evidence, abstention, prompt-injection tests, PII/secret redaction and model evaluation. Never let AI execute scanner commands or mark a finding confirmed.

## Milestone E — Cloud security
Add read-only AWS/Azure connectors using least-privilege roles and explicit account consent. Begin with offline IaC analysis; later support cloud APIs with audit trails and scope checks. Never request long-lived cloud access keys where workload identity is available.

## Milestone F — Security operations
Normalize events, correlate signals, add alert rules and a tested event pipeline. Include retention controls and tenant isolation.

## Milestone G — Remediation and verification
Generate suggested patches and regression tests; require human approval before changes. Re-run deterministic checks and preserve before/after evidence.

## Milestone H — Release quality
Alembic, PostgreSQL, Redis, Docker, CI, SBOM, SAST/dependency scanning, backup/restore tests, observability, load testing, deployment threat model, demo tenant and reproducible benchmark report.

## Portfolio evidence required
Publish architecture and threat model, a short demo, API docs, tests, benchmark methodology/results, known limitations, SBOM, CI status and a sample report generated only from a deliberately vulnerable local lab.

## Phase 4 completed in v0.1.4 (MVP)
- Defensive telemetry ingestion for Wazuh, Suricata and Zeek.
- Organization-scoped sensor credentials, normalized event storage, deduplication and explainable starter detections.
- Human-reviewed alert workflow and minimal sensor shipper.

## Phase 5 — SOC Dashboard & Case Management (MVP in v0.1.5)
- Implemented browser dashboard at `/soc`, overview/trend APIs, case management, alert linking, same-tenant analyst assignment, notes, timeline and JSON/CSV exports.
- Remaining: alert search/pagination, aging/SLA metrics, source health heartbeats, redacted export profiles, PDF reports and websocket updates.
- No automated response; all incident actions remain human-reviewed.

## Phases 6–10 — Platform maturity MVPs (v0.1.6)
- Phase 6: evidence-grounded deterministic analyst investigation and local IOC correlation. Remaining: vetted model provider, retrieval, evals, prompt-injection controls and evidence citations before enabling any LLM.
- Phase 7: asset owner/criticality/classification profiles and transparent finding-weight risk prioritization. Remaining: software inventory, dependency/SBOM correlation, lifecycle, exposure context and calibrated risk model.
- Phase 8: baseline control catalog and organization-scoped evidence tracking. Remaining: official framework mapping, control testing, evidence lifecycle, auditor workflow and independent assessment.
- Phase 9: org-scoped export, checksum validation and readiness checks. Remaining: encrypted object storage, automated database backups, retention, key rotation, tested restore and disaster recovery exercises.
- Phase 10: governance decisions and read-only federation peer visibility, with existing explicit peer enrollment. Remaining: sovereign legal agreements, data-sharing policy engine, key rotation, peer health monitoring, mTLS, multi-node interoperability and independent governance review.
