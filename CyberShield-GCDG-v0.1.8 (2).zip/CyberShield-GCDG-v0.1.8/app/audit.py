from fastapi import Request
from sqlalchemy.orm import Session
from app.db.models import AuditLog, User


def write_audit(db: Session, request: Request, action: str, outcome: str, user: User | None = None, resource: str = "", details: dict | None = None):
    # Never put passwords, bearer tokens, cookies, or raw request bodies in audit details.
    ip = request.client.host if request and request.client else "unknown"
    db.add(AuditLog(
        organization_id=user.organization_id if user else None,
        actor_user_id=user.id if user else None,
        actor_email=user.email if user else "anonymous",
        action=action[:100], resource=resource[:255], outcome=outcome[:30],
        client_ip=ip[:64], details=details or {},
    ))
    db.commit()
