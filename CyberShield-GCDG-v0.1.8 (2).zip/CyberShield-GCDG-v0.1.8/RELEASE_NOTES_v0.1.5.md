# CyberShield GCDG v0.1.5 — Phase 5

Adds SOC dashboard APIs, organization-scoped incident case management, alert-to-case linking, analyst assignment, notes, activity timeline, and JSON/CSV exports. No automated response capability is introduced.

See `docs/PHASE5_SOC_INCIDENTS.md` for routes, example payload, permissions and limitations.
