@echo off
setlocal
cd /d "%~dp0"
if exist .venv\Scripts\activate.bat (
  call .venv\Scripts\activate.bat
)
if not exist .env (
  echo .env not found. Auto-generating secure configuration...
  python -c "import secrets; from cryptography.fernet import Fernet; jwt = secrets.token_urlsafe(48); fernet = Fernet.generate_key().decode(); tmpl = open('.env.example', 'r').read(); tmpl = tmpl.replace('REPLACE_WITH_AT_LEAST_32_RANDOM_BYTES', jwt).replace('replace_with_generated_fernet_key', fernet); open('.env', 'w').write(tmpl); print('Generated secure .env with unique cryptographic keys.')"
)
python -c "from app.core.config import settings; print('Configuration loaded for', settings.app_name)"
if errorlevel 1 goto failed
echo Starting CyberShield Sovereign Command Hub at http://127.0.0.1:8000
start "" http://127.0.0.1:8000
python -m uvicorn app.main:app --host 127.0.0.1 --port 8000
exit /b 0
:failed
echo Configuration failed. Check .env and required dependencies.
pause
exit /b 1
