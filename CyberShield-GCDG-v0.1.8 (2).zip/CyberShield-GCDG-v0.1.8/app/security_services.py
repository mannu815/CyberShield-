"""Deterministic, evidence-based assessment helpers. No exploit payloads are sent."""
from __future__ import annotations
import ipaddress, json, re
from urllib.parse import urlsplit

SEVERITY_ORDER = {"critical": 5, "high": 4, "medium": 3, "low": 2, "informational": 1}

def normalize_web_target(value: str) -> str:
    value = value.strip()
    if not value or len(value) > 512:
        raise ValueError("Target is required and must be at most 512 characters")
    if "://" not in value: value = "https://" + value
    u = urlsplit(value)
    if u.scheme not in {"http", "https"} or not u.hostname or u.username or u.password:
        raise ValueError("Only valid HTTP(S) URLs without embedded credentials are accepted")
    if u.port and u.port not in {80, 443, 8080, 8443}:
        raise ValueError("Only approved web ports 80, 443, 8080 and 8443 are accepted")
    host = u.hostname.rstrip(".").lower()
    if host == "localhost" or host.endswith((".localhost", ".local", ".internal", ".test")):
        raise ValueError("Local and internal hostnames are not accepted")
    try:
        ip = ipaddress.ip_address(host)
        if not ip.is_global: raise ValueError("Non-public IP targets are blocked")
    except ValueError as e:
        if "blocked" in str(e): raise
        if not re.fullmatch(r"(?=.{1,253}$)([a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*[a-zA-Z]{2,63}", host):
            raise ValueError("Invalid hostname")
    return value

def analyze_headers(headers: dict[str, str], scheme: str = "https") -> list[dict]:
    h = {str(k).lower(): str(v)[:1000] for k,v in headers.items()}
    out=[]
    checks=[
      ("strict-transport-security","HSTS header missing","medium","Enable HSTS after confirming HTTPS works across the intended host scope."),
      ("content-security-policy","Content Security Policy missing","medium","Define and test a restrictive Content-Security-Policy; avoid unsafe-inline where practical."),
      ("x-content-type-options","MIME sniffing protection missing","low","Set X-Content-Type-Options: nosniff."),
      ("referrer-policy","Referrer policy missing","low","Set a privacy-appropriate Referrer-Policy."),
      ("permissions-policy","Permissions policy missing","informational","Disable browser features the application does not require."),
    ]
    if scheme.lower() != "https":
      out.append(dict(title="HTTPS not evidenced",severity="high",status="potential",category="transport",confidence="high",evidence={"scheme":scheme},remediation="Serve the application over HTTPS and redirect HTTP to HTTPS."))
    for key,title,sev,fix in checks:
      if key not in h:
        out.append(dict(title=title,severity=sev,status="potential",category="http_headers",confidence="medium",evidence={"missing_header":key},remediation=fix))
      else:
        out.append(dict(title=f"{key} present",severity="informational",status="observed",category="http_headers",confidence="high",evidence={"header":key,"value":h[key][:300]},remediation="Review the configured value against application requirements."))
    csp=h.get("content-security-policy","")
    if csp and "*" in csp:
      out.append(dict(title="CSP contains wildcard source",severity="low",status="review_required",category="http_headers",confidence="medium",evidence={"header":"content-security-policy","indicator":"wildcard source present"},remediation="Review wildcard sources and replace them with explicit trusted origins where feasible."))
    return out

def analyze_cloud_config(document: dict) -> list[dict]:
    """Inspect a small normalized cloud/IaC JSON shape; does not connect to cloud accounts."""
    out=[]
    def add(title,sev,path,evidence,fix): out.append(dict(title=title,severity=sev,status="potential",category="cloud_configuration",confidence="medium",evidence={"path":path,"observed":evidence},remediation=fix))
    resources=document.get("resources",[]) if isinstance(document,dict) else []
    if not isinstance(resources,list): raise ValueError("resources must be a JSON array")
    for i,r in enumerate(resources[:500]):
      if not isinstance(r,dict): continue
      typ=str(r.get("type","")).lower(); props=r.get("properties",{}) if isinstance(r.get("properties",{}),dict) else {}
      if "storage" in typ or "bucket" in typ:
        if props.get("publicAccess") is True or props.get("publicRead") is True:
          add("Storage resource appears publicly readable","high",f"resources[{i}].properties",{"type":typ,"publicRead":True},"Disable public access unless explicitly required; use private access and least-privilege policies.")
      if "securitygroup" in typ or "firewall" in typ:
        for j,rule in enumerate(props.get("ingress",[]) if isinstance(props.get("ingress",[]),list) else []):
          if isinstance(rule,dict) and rule.get("source") in {"0.0.0.0/0","::/0"} and rule.get("port") in {22,3389,"22","3389", "*"}:
            add("Administrative ingress exposed to the internet","high",f"resources[{i}].properties.ingress[{j}]",rule,"Restrict administrative access to approved VPN or trusted CIDR ranges; remove broad internet exposure.")
      if "iam" in typ or "role" in typ or "policy" in typ:
        actions=props.get("actions",[])
        if "*" in actions:
          add("Wildcard IAM action detected","high",f"resources[{i}].properties.actions",actions,"Replace wildcard actions with the minimum required permissions.")
    return out

def ai_explanation(finding: dict) -> dict:
    """Safe deterministic fallback; clearly labels itself as non-generative."""
    return {"provider":"deterministic-fallback","generated":False,"summary":f"{finding.get('title','Finding')} is classified as {finding.get('severity','unknown')} based on the supplied evidence.","evidence":finding.get("evidence",{}),"limitations":"This is rule-based interpretation, not an LLM verdict. Validate in the application's full context.","recommended_action":finding.get("remediation", "Review the finding manually.")}
