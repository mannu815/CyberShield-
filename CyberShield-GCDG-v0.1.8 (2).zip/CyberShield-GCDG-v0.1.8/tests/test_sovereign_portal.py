from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.session import Base
from app.db.models import Organization, User, PeerNode, DetectionEvent, DetectionAlert, IncidentCase
from app.api.sovereign import sovereign_overview, sovereign_peers


def seed():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    db = Session()
    org = Organization(name="Sovereign Node", slug="sovereign-node")
    db.add(org); db.flush()
    actor = User(organization_id=org.id, email="platform@example.test", full_name="Platform Admin", password_hash="x", role="platform_admin")
    db.add(actor); db.flush()
    peer = PeerNode(node_id="node-np-01", display_name="Nepal Node", country_code="NP", shared_secret_ciphertext="encrypted", enabled=False, policy_approved=False)
    db.add(peer); db.commit()
    return engine, db, actor


def test_sovereign_overview_reports_global_metadata_only():
    engine, db, actor = seed()
    result = sovereign_overview(db, actor)
    assert result["organizations"] == 1
    assert result["peers_pending"] == 1
    assert "sovereign organization boundary" in result["scope_notice"]
    db.close(); engine.dispose()


def test_sovereign_peer_list_never_exposes_shared_secret_ciphertext():
    engine, db, actor = seed()
    result = sovereign_peers(db, actor)
    assert result[0]["node_id"] == "node-np-01"
    assert result[0]["state"] == "pending_review"
    assert "shared_secret_ciphertext" not in result[0]
    db.close(); engine.dispose()


def test_only_platform_admin_passes_sovereign_role_gate():
    from fastapi import HTTPException
    from app.dependencies import require_roles
    engine, db, actor = seed()
    gate = require_roles("platform_admin")
    assert gate(actor) is actor
    tenant_admin = User(organization_id=actor.organization_id, email="tenant@example.test", full_name="Tenant Admin", password_hash="x", role="admin")
    db.add(tenant_admin); db.flush()
    try:
        gate(tenant_admin)
        assert False, "tenant admin must not pass sovereign role gate"
    except HTTPException as exc:
        assert exc.status_code == 403
    db.close(); engine.dispose()
