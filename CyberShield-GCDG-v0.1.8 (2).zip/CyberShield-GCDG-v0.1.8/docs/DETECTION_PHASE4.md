# Phase 4 — Defensive Detection & Event Correlation

## What is included

- Organization-scoped sensor credentials for Wazuh, Suricata and Zeek. Keys are generated once, stored as SHA-256 hashes and can be disabled by an organization admin.
- HTTPS sensor ingestion endpoint with source binding, bounded batches (250 events / 1 MB), rate limiting, strict IP parsing, field allowlisting and sensitive-field filtering.
- Source normalizers for Wazuh `alerts.json`, Suricata EVE JSON and Zeek JSON logs.
- Deterministic SHA-256 event fingerprints and organization-scoped deduplication.
- Explainable rules for high/critical Wazuh and Suricata alerts, Zeek notices/weird events and repeated Wazuh authentication failures.
- Alert lifecycle (`open`, `acknowledged`, `resolved`), summary and event APIs. All data is isolated by organization.
- `scripts/sensor_shipper.py`, a minimal HTTPS-verified JSON-lines shipper. It tails from EOF so it does not upload old log history on initial start.

## API

All routes are under `/api/v1/detection`.

| Method | Route | Permission |
|---|---|---|
| POST | `/sensors` | admin |
| GET | `/sensors` | admin, analyst |
| POST | `/sensors/{sensor_id}/disable` | admin |
| POST | `/ingest/{wazuh\|suricata\|zeek}` | sensor key (`X-Sensor-Key`) |
| GET | `/events` | authenticated user, own organization |
| GET | `/alerts` | authenticated user, own organization |
| PATCH | `/alerts/{alert_id}` | admin, analyst |
| GET | `/summary` | authenticated user, own organization |

Create one credential per sensor/source from an admin account. The API key is returned once. Store it in a secret manager or protected environment variable; do not put it in source control or log output. Disable a credential immediately if exposed.

## Sensor shipper setup

Install and configure the upstream products separately. Enable JSON output for each source:

- Wazuh: use the manager's `alerts.json` output.
- Suricata: enable the `eve-log` JSON output and select relevant event types.
- Zeek: enable JSON log output (for example, `@load policy/tuning/json-logs` in the Zeek site policy).

On the machine that can read the sensor log, set environment variables and run the shipper:

```powershell
$env:CYBERSHIELD_API_URL = "https://your-cybershield-host"
$env:CYBERSHIELD_SENSOR_SOURCE = "suricata"
$env:CYBERSHIELD_SENSOR_KEY = "csg_REPLACE_WITH_KEY"
$env:CYBERSHIELD_SENSOR_LOG = "C:\\ProgramData\\Suricata\\log\\eve.json"
python scripts/sensor_shipper.py
```

Use `wazuh` or `zeek` and the correct JSON-lines log path for those sources. Keep the shipper close to the sensor, use a restricted service account with read-only log access, and use HTTPS with a valid certificate. Do not expose sensor keys in command history on shared systems; environment variables above are a quick local test method, not a production secret-management design.

## Test ingestion without a live sensor

Create a sensor key in the admin UI/API, then send a small test batch:

```powershell
$headers = @{ "X-Sensor-Key" = "csg_REPLACE_WITH_KEY" }
$body = @{ events = @(@{ timestamp = "2026-11-05T12:00:00Z"; event_type = "alert"; src_ip = "203.0.113.9"; dest_ip = "192.0.2.10"; alert = @{ signature = "Test signature - benign fixture"; severity = 1; signature_id = 900001 } }) } | ConvertTo-Json -Depth 8
Invoke-RestMethod -Method Post -Uri "https://your-cybershield-host/api/v1/detection/ingest/suricata" -Headers $headers -ContentType "application/json" -Body $body
```

This uses documentation-only TEST-NET IP addresses and a synthetic signature. It does not represent a live attack.

## Detection rules and limitations

- Suricata severity 1/2 and Wazuh rule levels >=10 generate high/critical alerts.
- Zeek `notice` / `weird` events generate medium alerts.
- Five or more Wazuh authentication-failure events from one source IP in ten minutes generate a repeated-failure alert.
- These are starter rules, not a complete SOC analytics library. Tune thresholds per environment to reduce false positives.
- Event deduplication is exact fingerprint matching, not fuzzy correlation. Event payloads are deliberately reduced; raw packets, full process command lines, credentials, tokens and cookies are not stored.
- Current shipper is a minimal tailer, not a resilient production log-forwarding agent: it has no durable offset checkpoint, TLS client certificate support, backpressure queue or guaranteed delivery. Run under a supervisor and use a production log-forwarding platform for critical telemetry.
- No live Wazuh, Suricata or Zeek services were available during this build; upstream connectivity and deployment compatibility must be verified in the target environment.
- `Base.metadata.create_all()` creates new tables on a fresh database but does not migrate existing deployed schemas. Back up the DB and add Alembic migrations before production upgrades.
- No automated blocking, endpoint isolation, firewall changes, remote commands or hack-back are implemented. Alerts require human review.
