from __future__ import annotations
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from hashlib import sha256
import json
from typing import Any

SEVERITIES = {"info", "low", "medium", "high", "critical"}

@dataclass(frozen=True)
class NormalizedEvent:
    event_id: str
    tenant_id: str
    node_id: str
    observed_at: str
    source: str
    event_type: str
    severity: str = "info"
    src_ip: str | None = None
    dst_ip: str | None = None
    asset_ref: str | None = None
    attributes: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "NormalizedEvent":
        required = ("event_id", "tenant_id", "node_id", "observed_at", "source", "event_type")
        missing = [key for key in required if not payload.get(key)]
        if missing:
            raise ValueError(f"Missing required event fields: {', '.join(missing)}")
        severity = str(payload.get("severity", "info")).lower()
        if severity not in SEVERITIES:
            raise ValueError("Unsupported severity")
        # Validate timestamp without requiring a particular fractional precision.
        datetime.fromisoformat(str(payload["observed_at"]).replace("Z", "+00:00"))
        allowed = {k: payload.get(k) for k in cls.__dataclass_fields__ if k in payload}
        allowed["severity"] = severity
        allowed.setdefault("attributes", {})
        if not isinstance(allowed["attributes"], dict):
            raise ValueError("attributes must be an object")
        return cls(**allowed)

    def digest(self) -> str:
        body = json.dumps(asdict(self), sort_keys=True, separators=(",", ":"), default=str)
        return sha256(body.encode()).hexdigest()

@dataclass(frozen=True)
class Detection:
    rule_id: str
    title: str
    severity: str
    rationale: str
    event_id: str

RULES = {
    "AUTH_FAILURE_BURST": {"event_type": "authentication_failure", "minimum": 5, "severity": "high", "title": "Authentication failure burst"},
    "PRIVILEGE_CHANGE": {"event_type": "privilege_change", "minimum": 1, "severity": "critical", "title": "Privileged access change"},
    "MALWARE_ALERT": {"event_type": "malware_detection", "minimum": 1, "severity": "critical", "title": "Endpoint malware detection"},
}

def detect(events: list[NormalizedEvent]) -> list[Detection]:
    """Simple deterministic reference rules; production correlation needs a stream engine."""
    detections: list[Detection] = []
    failures: dict[tuple[str, str], list[NormalizedEvent]] = {}
    for event in events:
        if event.event_type == "authentication_failure":
            key = (event.tenant_id, event.asset_ref or "unknown")
            failures.setdefault(key, []).append(event)
        for rule_id, rule in RULES.items():
            if rule["event_type"] == event.event_type and rule["minimum"] == 1:
                detections.append(Detection(rule_id, rule["title"], rule["severity"], f"Observed event type: {event.event_type}", event.event_id))
    for (_, asset), batch in failures.items():
        if len(batch) >= RULES["AUTH_FAILURE_BURST"]["minimum"]:
            last = batch[-1]
            detections.append(Detection("AUTH_FAILURE_BURST", RULES["AUTH_FAILURE_BURST"]["title"], "high", f"{len(batch)} failures observed for asset {asset}; validate source and time window.", last.event_id))
    return detections
