# CyberShield GCDG v0.1.6 — Phases 6–10

This release layers five defensive platform capabilities onto v0.1.5. These are working MVP APIs and data models, not a production national SOC or a certified compliance product.

## Phase 6 — Analyst decision support
- `POST /api/v1/analyst/cases/{case_id}/investigate` builds an evidence-led investigation from organization-scoped incident alerts and detection events.
- Optional exact-match correlation against the organization's locally stored threat-intelligence IOC values.
- Returns evidence references, deterministic confidence heuristic, and human-review recommendations; stores an investigation record.
- No external LLM is called and no AI-generated claim is presented as fact. No automatic containment, blocking, or remediation.

## Phase 7 — Asset inventory and risk context
- `GET /api/v1/platform/assets` lists organization-owned assets and profile metadata.
- `PUT /api/v1/platform/assets/{asset_id}/profile` records owner, criticality, environment, data classification, and tags.
- `GET /api/v1/platform/assets/{asset_id}/risk` combines declared asset criticality with unresolved assessment findings using a transparent weighted heuristic.
- This score is prioritization support, not probability, CVSS, or a validated enterprise risk calculation.

## Phase 8 — Security assurance and evidence
- `GET /api/v1/assurance/catalog` exposes a small GCDG baseline checklist.
- `POST /api/v1/assurance/evidence`, `GET /api/v1/assurance/evidence`, and `GET /api/v1/assurance/summary` maintain evidence records and status counts.
- The baseline is an operational checklist, not an official reproduction of NIST/CIS text, legal advice, audit opinion, or certification.

## Phase 9 — Resilience and recovery readiness
- `GET /api/v1/ops/readiness` checks configuration prerequisites without exposing secret values.
- `GET /api/v1/ops/backup/export` exports a bounded organization-scoped JSON snapshot and SHA-256 integrity digest. Password hashes, federation shared-secret ciphertext, and sensor key hashes are excluded.
- `POST /api/v1/ops/backup/validate` validates format, organization, dataset shape, size and checksum in dry-run mode only. It does not restore or write data.
- Production backup requires encrypted off-host storage, retention controls, key management, database-native backups, and periodic restore drills. The API export is not a replacement for database backups.

## Phase 10 — Sovereign governance and federation operations
- `GET /api/v1/governance/federation-peers` displays peer status without revealing credentials.
- Peer enrollment and national approval continue through the existing admin peer-registration workflow; the new governance view is read-only to avoid silently granting tenant admins control over a global node registry.
- `POST /api/v1/governance/decisions` and `GET /api/v1/governance/decisions` record admin decisions with rationale.
- `GET /api/v1/ops/readiness` includes federation encryption configuration status.
- Federation remains indicator-only in this MVP; no raw national telemetry pooling, cross-border user records, or autonomous response.

## Operational requirements before production
1. Back up existing databases and create reviewed Alembic migrations. `Base.metadata.create_all()` creates missing tables but does not migrate existing schemas.
2. Set `APP_ENV=production`, use PostgreSQL, managed secrets, TLS/mTLS at the gateway, restrictive network egress, and strong admin MFA at the identity layer.
3. Put backups in encrypted off-host storage and test recovery in an isolated environment.
4. Define legal authority, data-sharing agreements, retention/deletion schedules, incident escalation, and independent audit requirements for each sovereign node.
5. Run the full test suite with the pinned requirements and perform integration, load, failover, security and restore testing. This build did not perform live integrations with national systems or external AI providers.

## Safety boundaries
Passive/authorized collection, human-reviewed recommendations, and approved indicator exchange only. No offensive scanning beyond separately authorized assessment workflows, no exploit execution, no hack-back, no arbitrary command execution, and no automatic destructive response.
