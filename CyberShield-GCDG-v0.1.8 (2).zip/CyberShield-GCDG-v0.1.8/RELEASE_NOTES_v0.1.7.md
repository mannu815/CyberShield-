# CyberShield GCDG v0.1.7 — Security Hardening Foundation

## Implemented in this release
- Tenant admins can no longer activate or approve a global federation peer. Peer registration now creates a disabled, unapproved request pending independent platform-level sovereign review.
- Federation indicator listing is restricted to organization admins and public/clear handling labels (`TLP:CLEAR`, `WHITE`).
- Federation ingestion has request-size and sender-ID validation, a dedicated rate-limit decorator, generic validation errors, and expired replay-nonce cleanup.
- Incident CSV export neutralizes spreadsheet formula-leading values and quotes all cells.
- Production responses receive a restrictive Content-Security-Policy, Permissions-Policy and HSTS; production settings reject SQLite and common placeholder JWT secrets.
- Production app startup no longer calls `create_all`; Alembic bootstrap infrastructure is included.
- CI supplies a test-only JWT secret so test collection does not fail due to missing configuration.
- Sensor shipper now retries HTTP errors for its final partial batch as well as full batches.
- Organization backup format v2 includes assets/profiles, assessments/findings, detection events/alerts, incident cases/notes/activities, investigations, threat intelligence, compliance evidence, governance decisions and audit logs. Credentials and federation secrets remain excluded.

## Important migration instructions
Fresh database:
```bash
alembic upgrade head
```
Existing v0.1.6 database created with SQLAlchemy `create_all()`:
1. Stop the application and take a verified database backup.
2. Keep the existing schema; do not delete the database.
3. Run `alembic stamp 0001` to mark the existing schema as the bootstrap baseline.
4. Start the application with `APP_ENV=production` only after setting PostgreSQL and a unique JWT secret.

The bootstrap migration is metadata-based for fresh installations. Future schema changes must be generated, reviewed and committed as explicit Alembic revisions.

## Not yet complete / not production certified
- There is no complete platform-superadmin web workflow to review and activate pending sovereign peers. Until implemented, activation must be performed through a controlled, independently audited operator procedure.
- mTLS is not enforced by the FastAPI process itself. Configure it at a trusted ingress, restrict backend network access, and do not trust arbitrary forwarded certificate headers.
- Backup validation remains dry-run only; automated restore and full disaster-recovery exercises are not implemented.
- Sensor shipper still does not persist a durable offset or pending batch across process restarts.
- MFA, SSO, password recovery, full RBAC UI, global threat map, cloud/Kubernetes integrations, full evidence chain-of-custody, and complete multi-country SOC workflows remain future modules.
- This release is a defensive engineering MVP, not a certified national/global cyber-defence platform.

## Verification
- Python compileall and AST parsing are required before release.
- Full pytest could not be completed in the build environment because `pwdlib` is not installed and package installation was blocked by unavailable network access. CI installs pinned dependencies and should be run before deployment.
