from datetime import datetime, timezone
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.session import Base
from app.db.models import Organization, ThreatIntelIOC, ThreatIntelSyncLog, ThreatRecord
from app.threat_intel import connectors

@pytest.fixture
def db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    try:
        yield session
    finally:
        session.close(); engine.dispose()

def test_misp_ip_normalization():
    item = connectors._normalize_misp_attribute({"type": "ip-dst", "value": "203.0.113.7", "to_ids": True})
    assert item["indicator_type"] == "ip"
    assert item["value"] == "203.0.113.7"

def test_misp_domain_normalization_and_rejects_invalid():
    item = connectors._normalize_misp_attribute({"type": "domain", "value": "Example.COM."})
    assert item["value"] == "example.com"
    assert connectors._normalize_misp_attribute({"type": "domain", "value": "bad domain"}) is None

def test_misp_hash_validation():
    assert connectors._normalize_misp_attribute({"type": "sha256", "value": "a" * 64})["value"] == "a" * 64
    assert connectors._normalize_misp_attribute({"type": "sha256", "value": "xyz"}) is None

def test_kev_parser_filters_bad_cve(monkeypatch):
    monkeypatch.setattr(connectors, "_get_json", lambda *a, **k: {"vulnerabilities": [
        {"cveID": "CVE-2024-12345", "shortDescription": "Known exploited", "dateAdded": "2024-01-01"},
        {"cveID": "not-a-cve"}]})
    rows = connectors.fetch_kev()
    assert len(rows) == 1
    assert rows[0]["known_exploited"] is True

def test_nvd_parser_extracts_cvss(monkeypatch):
    monkeypatch.setattr(connectors, "_get_json", lambda *a, **k: {"totalResults": 1, "vulnerabilities": [{"cve": {
        "id": "CVE-2024-12345", "descriptions": [{"lang": "en", "value": "Example issue"}],
        "metrics": {"cvssMetricV31": [{"baseSeverity": "HIGH", "cvssData": {"baseScore": 8.8}}]}, "references": []}}]})
    rows = connectors.fetch_nvd()
    assert rows[0]["cvss_score"] == "8.8"
    assert rows[0]["severity"] == "high"

def test_ioc_org_source_uniqueness(db):
    org = Organization(name="Test", slug="test"); db.add(org); db.commit()
    values = dict(organization_id=org.id, source="misp", indicator_type="ip", value="203.0.113.7", confidence=70,
                  threat_label="test", description="", tags=[], references=[], raw_metadata={})
    db.add(ThreatIntelIOC(**values)); db.commit()
    db.add(ThreatIntelIOC(**values))
    from sqlalchemy.exc import IntegrityError
    with pytest.raises(IntegrityError): db.commit()

def test_connector_url_requires_https_and_public_ip():
    with pytest.raises(connectors.FeedError):
        connectors._configured_https_url("http://misp.example.org", "MISP_URL")
    with pytest.raises(connectors.FeedError):
        connectors._configured_https_url("https://127.0.0.1", "MISP_URL")
    assert connectors._configured_https_url("https://misp.example.org/", "MISP_URL") == "https://misp.example.org"

def test_opencti_import_accepts_only_simple_stix_patterns(monkeypatch):
    monkeypatch.setattr(connectors.settings, "opencti_url", "https://opencti.example.org")
    monkeypatch.setattr(connectors.settings, "opencti_token", "test-token")
    monkeypatch.setattr(connectors, "_post_json", lambda *a, **k: {"data": {"indicators": {"edges": [
        {"node": {"id": "1", "name": "test ip", "pattern": "[ipv4-addr:value = '203.0.113.9']", "confidence": 85}},
        {"node": {"id": "2", "name": "complex", "pattern": "[ipv4-addr:value = '203.0.113.8' AND network-traffic:dst_port = 443]"}}
    ]}}})
    rows = connectors.fetch_opencti()
    assert len(rows) == 1
    assert rows[0]["value"] == "203.0.113.9"
