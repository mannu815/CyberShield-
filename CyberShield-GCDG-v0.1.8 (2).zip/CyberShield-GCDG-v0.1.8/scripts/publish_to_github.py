#!/usr/bin/env python3
"""
CyberShield GitHub Publisher
Publishes the CyberShield GCDG workspace directly to GitHub via the official GitHub REST/Git Data API.
Zero external software required (no git.exe or winget admin rights needed).
"""

import os
import sys
import json
import base64
import argparse
from pathlib import Path
from getpass import getpass
import httpx

PROJECT_ROOT = Path(__file__).resolve().parent.parent

# Files and directory patterns to ignore
IGNORE_DIRS = {".git", ".venv", "venv", "env", "__pycache__", ".pytest_cache", ".idea", ".vscode", "htmlcov"}
IGNORE_EXTS = {".pyc", ".pyo", ".pyd", ".db", ".sqlite", ".sqlite3", ".log"}
IGNORE_FILES = {".env", ".coverage"}


def should_ignore(rel_path: Path) -> bool:
    for part in rel_path.parts:
        if part in IGNORE_DIRS or part.startswith(".pytest_cache"):
            return True
    if rel_path.name in IGNORE_FILES:
        return True
    if rel_path.name.startswith(".env.") and not rel_path.name.endswith(".example"):
        return True
    if rel_path.suffix.lower() in IGNORE_EXTS:
        return True
    return False


def collect_files(root: Path) -> list[tuple[Path, str]]:
    files_to_upload = []
    for p in root.rglob("*"):
        if p.is_file():
            rel = p.relative_to(root)
            if not should_ignore(rel):
                # Git paths must use forward slashes
                git_path = rel.as_posix()
                files_to_upload.append((p, git_path))
    return files_to_upload


def main():
    parser = argparse.ArgumentParser(description="Publish CyberShield to GitHub")
    parser.add_argument("--token", help="GitHub Personal Access Token (classic with repo scope, or fine-grained with read/write)")
    parser.add_argument("--repo", default="CyberShield-GCDG-National-SOC", help="Repository name on GitHub")
    parser.add_argument("--private", action="store_true", help="Create as a private repository (default is public)")
    parser.add_argument("--description", default="CyberShield AI / GCDG v0.1.8 — National SOC & Sovereign Admin Defensive Platform", help="Repository description")
    args = parser.parse_args()

    token = args.token or os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if not token:
        if sys.stdin.isatty():
            token = getpass("Enter GitHub Personal Access Token (repo scope): ").strip()
        else:
            print("Error: GITHUB_TOKEN is not provided. Set GITHUB_TOKEN environment variable or pass --token.", file=sys.stderr)
            sys.exit(1)

    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "CyberShield-GitHub-Publisher/1.0"
    }

    client = httpx.Client(headers=headers, timeout=60.0)

    # 1. Verify credentials and get current user
    print("[*] Verifying GitHub token...")
    user_resp = client.get("https://api.github.com/user")
    if user_resp.status_code != 200:
        print(f"[-] Authentication failed: HTTP {user_resp.status_code} - {user_resp.text}", file=sys.stderr)
        sys.exit(1)

    owner = user_resp.json()["login"]
    print(f"[+] Authenticated as GitHub user: @{owner}")

    # 2. Check if repo already exists or create it
    repo_name = args.repo
    print(f"[*] Checking repository {owner}/{repo_name}...")
    repo_resp = client.get(f"https://api.github.com/repos/{owner}/{repo_name}")
    
    if repo_resp.status_code == 404:
        print(f"[*] Creating new repository: {owner}/{repo_name}...")
        create_resp = client.post("https://api.github.com/user/repos", json={
            "name": repo_name,
            "description": args.description,
            "private": args.private,
            "auto_init": True
        })
        if create_resp.status_code not in (200, 201):
            print(f"[-] Failed to create repository: HTTP {create_resp.status_code} - {create_resp.text}", file=sys.stderr)
            sys.exit(1)
        repo_data = create_resp.json()
        print(f"[+] Created repository: {repo_data['html_url']}")
    elif repo_resp.status_code == 200:
        repo_data = repo_resp.json()
        print(f"[+] Repository already exists: {repo_data['html_url']}")
    else:
        print(f"[-] Error querying repository: HTTP {repo_resp.status_code} - {repo_resp.text}", file=sys.stderr)
        sys.exit(1)

    repo_html_url = repo_data["html_url"]

    # 3. Get default branch reference
    default_branch = repo_data.get("default_branch", "main")
    ref_resp = client.get(f"https://api.github.com/repos/{owner}/{repo_name}/git/ref/heads/{default_branch}")
    
    parent_commit_sha = None
    base_tree_sha = None
    if ref_resp.status_code == 200:
        parent_commit_sha = ref_resp.json()["object"]["sha"]
        commit_resp = client.get(f"https://api.github.com/repos/{owner}/{repo_name}/git/commits/{parent_commit_sha}")
        if commit_resp.status_code == 200:
            base_tree_sha = commit_resp.json()["tree"]["sha"]

    # 4. Collect project files
    files = collect_files(PROJECT_ROOT)
    print(f"[*] Prepared {len(files)} files to upload to GitHub...")

    tree_items = []
    uploaded = 0

    for local_path, git_path in files:
        try:
            content_bytes = local_path.read_bytes()
            b64_content = base64.b64encode(content_bytes).decode("ascii")
            blob_resp = client.post(
                f"https://api.github.com/repos/{owner}/{repo_name}/git/blobs",
                json={"content": b64_content, "encoding": "base64"}
            )
            if blob_resp.status_code in (200, 201):
                blob_sha = blob_resp.json()["sha"]
                tree_items.append({
                    "path": git_path,
                    "mode": "100644",
                    "type": "blob",
                    "sha": blob_sha
                })
                uploaded += 1
                if uploaded % 15 == 0 or uploaded == len(files):
                    print(f"  -> Processed {uploaded}/{len(files)} files...")
            else:
                print(f"  [!] Failed to upload blob for {git_path}: {blob_resp.text}", file=sys.stderr)
        except Exception as e:
            print(f"  [!] Error reading {git_path}: {e}", file=sys.stderr)

    # 5. Create Git Tree
    print("[*] Creating Git tree structure on GitHub...")
    tree_payload = {"tree": tree_items}
    # Do not set base_tree if replacing with complete clean tree
    tree_resp = client.post(f"https://api.github.com/repos/{owner}/{repo_name}/git/trees", json=tree_payload)
    if tree_resp.status_code not in (200, 201):
        print(f"[-] Failed to create git tree: HTTP {tree_resp.status_code} - {tree_resp.text}", file=sys.stderr)
        sys.exit(1)
    
    new_tree_sha = tree_resp.json()["sha"]
    print(f"[+] Git tree created: {new_tree_sha[:8]}")

    # 6. Create Git Commit
    print("[*] Creating commit...")
    commit_payload = {
        "message": "CyberShield GCDG v0.1.8 - National SOC & Sovereign Admin Defensive Platform\n\nFull clean build with remediated security configurations, updated landing hub, and passing tests.",
        "tree": new_tree_sha
    }
    if parent_commit_sha:
        commit_payload["parents"] = [parent_commit_sha]
    
    commit_resp = client.post(f"https://api.github.com/repos/{owner}/{repo_name}/git/commits", json=commit_payload)
    if commit_resp.status_code not in (200, 201):
        print(f"[-] Failed to create commit: HTTP {commit_resp.status_code} - {commit_resp.text}", file=sys.stderr)
        sys.exit(1)

    new_commit_sha = commit_resp.json()["sha"]
    print(f"[+] Commit created: {new_commit_sha[:8]}")

    # 7. Update branch reference
    print(f"[*] Updating branch reference heads/{default_branch}...")
    if parent_commit_sha:
        patch_resp = client.patch(
            f"https://api.github.com/repos/{owner}/{repo_name}/git/refs/heads/{default_branch}",
            json={"sha": new_commit_sha, "force": True}
        )
    else:
        patch_resp = client.post(
            f"https://api.github.com/repos/{owner}/{repo_name}/git/refs",
            json={"ref": f"refs/heads/{default_branch}", "sha": new_commit_sha}
        )

    if patch_resp.status_code not in (200, 201):
        print(f"[-] Failed to update branch reference: HTTP {patch_resp.status_code} - {patch_resp.text}", file=sys.stderr)
        sys.exit(1)

    print("\n" + "=" * 60)
    print("SUCCESS: CyberShield has been published to GitHub!")
    print(f"Repository Link: {repo_html_url}")
    print("=" * 60 + "\n")
    return repo_html_url


if __name__ == "__main__":
    main()
