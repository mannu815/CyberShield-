from __future__ import annotations
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from hashlib import sha256
import json

@dataclass(frozen=True)
class ResponseProposal:
    proposal_id: str
    tenant_id: str
    asset_ref: str
    action: str
    rationale: str
    rollback_plan: str
    expires_at: str
    status: str = "proposed"

    def validate(self) -> None:
        if self.status != "proposed":
            raise ValueError("New proposals must begin in proposed state")
        if not all((self.proposal_id, self.tenant_id, self.asset_ref, self.action, self.rationale, self.rollback_plan, self.expires_at)):
            raise ValueError("Proposal fields cannot be empty")
        if self.action.lower() in {"remote_shell", "exploit", "credential_dump", "wipe", "hack_back"}:
            raise ValueError("Intrusive or destructive actions are not supported")
        expiry = datetime.fromisoformat(self.expires_at.replace("Z", "+00:00"))
        if expiry.tzinfo is None:
            raise ValueError("expires_at must include a timezone")

@dataclass(frozen=True)
class ShareableIndicator:
    indicator: str
    indicator_type: str
    source: str
    confidence: float
    first_seen: str
    expires_at: str
    handling: str
    shareable: bool
    country_policy_approved: bool

    def export(self) -> dict:
        if not self.shareable or not self.country_policy_approved:
            raise PermissionError("Indicator is not approved for cross-border sharing")
        if not 0 <= self.confidence <= 1:
            raise ValueError("confidence must be between 0 and 1")
        if self.handling.upper() in {"TLP:RED", "RESTRICTED", "PERSONAL_DATA"}:
            raise PermissionError("Handling label prohibits federation export")
        payload = asdict(self)
        payload.pop("shareable")
        payload.pop("country_policy_approved")
        canonical = json.dumps(payload, sort_keys=True, separators=(",", ":"))
        return {"payload": payload, "sha256": sha256(canonical.encode()).hexdigest(), "signature": None,
                "signature_note": "Attach a node-PKI signature in the deployed federation gateway."}
