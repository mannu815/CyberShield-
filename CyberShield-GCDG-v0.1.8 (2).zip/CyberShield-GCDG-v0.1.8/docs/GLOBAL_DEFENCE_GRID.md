# CyberShield Global Cyber Defence Grid (GCDG)

**Architecture baseline — v0.1 | Defensive / authorized operations only**

## Mission
A federated platform that helps sovereign governments and critical-sector operators detect, investigate, contain and recover from cyber incidents. It is an integration and coordination layer, not a universal administrator of the world's networks. Each participating country operates its own node and retains control of its sensitive telemetry.

## Ten command systems

| System | Mission | Inputs | Outputs / controls |
|---|---|---|---|
| 1. Global Threat Intelligence | Correlate indicators, CVEs, exploited vulnerabilities and campaigns | MISP, OpenCTI, CISA KEV, vendor advisories, CERT submissions | Confidence-scored, sourced indicators; expiry and handling labels |
| 2. Detection Grid | Detect endpoint, identity, network, cloud and application anomalies | Wazuh, Suricata, Zeek, cloud audit logs, EDR/SIEM | Normalized events, detections, alerts and evidence references |
| 3. Vulnerability Intelligence | Prioritize exposure on registered/authorized assets | CMDB, authenticated scanners, SBOM, CVE feeds | Risk-ranked findings and remediation tickets; scope/ROE gates |
| 4. AI Cyber Intelligence | Assist triage, clustering and analyst investigation | Sanitized events, approved threat context | Explanations with provenance and confidence; analyst remains decision-maker |
| 5. Response Orchestration | Coordinate containment and recovery | Validated alerts, playbooks, approvals | Human-approved, least-privilege, reversible actions with rollback/audit |
| 6. Identity Defence | Detect identity abuse and privileged-account anomalies | IdP, MFA, PAM, directory and session logs | Step-up auth, token/session revocation proposals, access review |
| 7. Critical Infrastructure Protection | Monitor OT/ICS and essential services safely | Passive OT sensors, asset inventories, vendor advisories | Safety-aware alerts; no control-system write action by default |
| 8. Digital Forensics & Incident Command | Preserve evidence and coordinate response | Endpoint/network/cloud evidence, analyst notes | Immutable evidence manifest, timeline, chain of custody, case reports |
| 9. Sovereign Federation | Share approved intelligence across national nodes | Signed, minimized indicator packages | Policy-checked exchange, provenance, revocation and audit |
| 10. National/Global Command Dashboard | Present operational risk and coordination status | Node health, incident metrics, approved aggregate data | Role-scoped situational awareness; no raw cross-border telemetry by default |

## Logical architecture

```mermaid
flowchart TB
  subgraph COUNTRY[Country / Sovereign Security Domain]
    SENSORS[Wazuh / EDR / Suricata / Zeek / Cloud & IdP logs]
    COLLECT[Local collectors + schema normalization]
    BUS[Local event bus]
    DETECT[Detection & correlation engine]
    CASE[Incident / evidence service]
    RESP[Policy-gated response broker]
    DATA[(National data store + object evidence vault)]
    IAM[National IAM / MFA / RBAC / audit]
    SENSORS --> COLLECT --> BUS --> DETECT --> CASE
    BUS --> DATA
    DETECT --> DATA
    CASE --> DATA
    IAM --> CASE
    CASE --> RESP
  end
  CASE -->|approved, minimized, signed intel only| FED[Federation gateway]
  FED <--> PEERS[Other sovereign nodes]
  FED --> GLOBAL[Global coordination & aggregate dashboard]
  GLOBAL -->|advisories / signed indicators| FED
```

## Core operating rules
1. **Sovereignty:** raw logs, identities, packet captures and personal data stay in-country unless a lawful, documented transfer is approved.
2. **Authorization:** asset assessment requires an owner, written authorization, defined scope, time window and rules of engagement.
3. **No hack-back:** never exploit, persist on, or take control of a suspected attacker's device. Attribution is probabilistic; route evidence to competent authorities.
4. **Telemetry reality:** public IPs and network paths may be observed in logs; IPs can be VPNs, proxies, NAT gateways or compromised relays. MAC addresses are generally link-local and cannot be discovered across the public internet.
5. **Human control:** destructive/high-impact response actions require two-person approval, bounded scope, rollback plan and post-action verification. AI cannot directly execute privileged actions.
6. **Evidence integrity:** timestamp, source, collector identity, hash, handling label and chain-of-custody events accompany evidence.
7. **Safety:** OT/ICS integrations are passive by default; any active action follows sector safety engineering and owner approval.

## Event contract
Normalized event fields: `event_id`, `tenant_id`, `node_id`, `observed_at`, `received_at`, `source`, `sensor_id`, `event_type`, `severity`, `src_ip`, `dst_ip`, `src_port`, `dst_port`, `principal_ref` (pseudonymous), `asset_ref`, `mitre_techniques[]`, `indicator_refs[]`, `evidence_refs[]`, `raw_hash`, `handling`. Raw payloads remain in the local evidence vault; only minimized fields are shared.

## Federation contract
A node may export only indicators explicitly marked `shareable`, with a source, confidence, first/last seen, expiry, TLP/handling label, country policy decision and cryptographic signature. Never export raw personal data, credentials, packet captures or unredacted case notes through the default federation channel. Receiving nodes validate signature, schema, expiry, revocation and local policy before ingesting.

## Response lifecycle
`proposed -> reviewed -> approved -> executed -> verified` (or `rejected/cancelled/rolled_back`). Each proposal records the target asset, rationale, supporting alerts, exact action, blast-radius estimate, preconditions, approvers, expiry and rollback. The MVP stores proposals only; it does not run remote commands or change firewalls/endpoints.

## Integration roadmap
- **Phase A — Secure node:** PostgreSQL, migrations, MFA/SSO, RBAC/ABAC, tenant isolation, append-only audit, secrets management, backups and restore drills.
- **Phase B — Telemetry:** Wazuh/Suricata/Zeek adapters, signed collector identity, queue (Redpanda/Kafka), schema registry, deduplication and backpressure.
- **Phase C — Intelligence:** MISP/OpenCTI and CVE/KEV ingestion with provenance, confidence, expiry and false-positive handling.
- **Phase D — Detection:** deterministic rules first, correlation and anomaly scoring second; benchmark precision/recall and analyst workload.
- **Phase E — Incident operations:** case management, evidence vault, chain of custody, approved response broker and rollback drills.
- **Phase F — Federation:** node PKI, mutual TLS, signed exchange, policy engine, data minimization and national legal agreements.
- **Phase G — Resilience:** multi-region per country, tested disaster recovery, offline mode, supply-chain signing, penetration tests and independent audits.

## Production acceptance gates
Threat model and privacy impact assessment approved; independent security review; tenant-isolation tests; MFA and privileged access controls; signed software builds/SBOM; encrypted backups with restore test; 24/7 on-call and incident runbooks; legal basis and cross-border data agreements; OT safety approval; measurable SLOs; red-team exercise; disaster-recovery exercise. Do not describe a node as production-ready until these gates pass.

## What this repository delivers
This package preserves the existing CyberShield FastAPI foundation and adds a framework-neutral, testable reference layer for event normalization, deterministic detection, response proposals and sovereign indicator export. It is **not** a deployed global network, live SIEM, autonomous attribution system or production-grade response system. External sensors, national PKI, queues, storage, legal governance and operational teams must be deployed and independently validated.
