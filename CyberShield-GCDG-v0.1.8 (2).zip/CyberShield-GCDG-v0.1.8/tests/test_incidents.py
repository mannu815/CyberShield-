from datetime import datetime, timezone
import pytest
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.session import Base
from app.db.models import Organization, User, DetectionEvent, DetectionAlert, IncidentCase, IncidentCaseAlert, IncidentCaseActivity, IncidentCaseNote

@pytest.fixture
def db():
    engine=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    Session=sessionmaker(bind=engine); session=Session()
    org=Organization(name='Blue Team',slug='blue-team'); session.add(org); session.flush()
    user=User(organization_id=org.id,email='analyst@example.test',full_name='Analyst',password_hash='not-used',role='analyst')
    session.add(user); session.commit()
    yield session,org,user
    session.close(); engine.dispose()

def test_case_is_org_scoped_and_links_alerts(db):
    session,org,user=db
    event=DetectionEvent(organization_id=org.id,source='suricata',source_event_type='alert',severity='high',message='Test',attributes={},fingerprint='a'*64,event_time=datetime.now(timezone.utc))
    session.add(event); session.flush()
    alert=DetectionAlert(organization_id=org.id,event_id=event.id,rule_id='test.rule',title='Test alert',severity='high',status='open',description='test',remediation='review')
    session.add(alert); session.flush()
    case=IncidentCase(organization_id=org.id,case_number='CS-TEST12345',title='Investigate test alert',severity='high',created_by=user.id)
    session.add(case); session.flush(); session.add(IncidentCaseAlert(case_id=case.id,alert_id=alert.id)); session.commit()
    linked=session.query(IncidentCaseAlert).filter_by(case_id=case.id).one()
    assert linked.alert_id==alert.id
    assert session.query(IncidentCase).filter_by(id=case.id,organization_id=org.id).one().case_number=='CS-TEST12345'
    assert session.query(IncidentCase).filter_by(id=case.id,organization_id=org.id+100).first() is None

def test_case_activity_and_note_tables(db):
    session,org,user=db
    case=IncidentCase(organization_id=org.id,case_number='CS-TEST12346',title='Case',severity='medium',created_by=user.id)
    session.add(case); session.flush()
    session.add(IncidentCaseActivity(case_id=case.id,organization_id=org.id,actor_user_id=user.id,action='case.created',details={'origin':'test'}))
    session.add(IncidentCaseNote(case_id=case.id,organization_id=org.id,author_user_id=user.id,body='Reviewed evidence'))
    session.commit()
    assert session.query(IncidentCaseActivity).filter_by(case_id=case.id).count()==1
    assert session.query(IncidentCaseNote).filter_by(case_id=case.id).one().body=='Reviewed evidence'
