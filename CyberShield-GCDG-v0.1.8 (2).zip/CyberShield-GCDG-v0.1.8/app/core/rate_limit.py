from slowapi import Limiter
from slowapi.util import get_remote_address
from app.core.config import settings

# Development-only in-memory limiter. Replace with a Redis-backed storage URI
# before running multiple workers or deploying publicly.
limiter = Limiter(key_func=get_remote_address, default_limits=[settings.rate_limit_default])
