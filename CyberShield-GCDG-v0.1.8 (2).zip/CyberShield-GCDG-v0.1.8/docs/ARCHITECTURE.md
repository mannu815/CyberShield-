# CyberShield AI 2.0 — Architecture

## Current implemented scope

- FastAPI API with versioned `/api/v1` routes.
- Organization-scoped users, assets, assessments, findings, security events and audit logs.
- Argon2 password hashing and short-lived JWT access tokens.
- Admin / analyst / viewer authorization.
- Admin provisioning, audit-log retrieval and login/default rate limits.
- Asset registration requiring an authorization reference.
- Evidence-input HTTP header assessment (no target network traffic).
- JSON cloud/IaC-like configuration analysis (no cloud account connection).
- CVE record upsert/list API for curated/imported threat intelligence.
- JSON assessment report export.
- Deterministic AI explanation fallback that explicitly does not claim to be an LLM.

## Trust boundaries

1. Browser/client to API: bearer token authentication, request validation, rate limiting.
2. API to database: SQLAlchemy parameterized ORM queries and organization filters.
3. User-supplied evidence/configuration to analyzers: treated as untrusted data; never executed.
4. AI boundary: current explanation endpoint is deterministic. Future LLM calls must receive minimized evidence, treat it as untrusted, and return schema-validated suggestions only.

## Tenant isolation

Every customer-owned record includes `organization_id`. API queries for assets, assessments, findings, events and audit logs filter by the authenticated organization. Threat records are intentionally shared global reference data. Cross-tenant integration tests are required before public deployment.

## Assessment model

The current assessment APIs analyze supplied response-header snapshots and normalized JSON cloud configuration. They do not connect to arbitrary targets, crawl, exploit, brute force, or change infrastructure. Findings are potential/observed evidence, not a claim of exploitability. An authorized live passive HTTP engine is a later milestone and must implement DNS pinning, redirect revalidation, egress controls, timeouts, request budgets and scope enforcement before activation.

## Production gaps

- Replace startup `create_all()` with Alembic migrations.
- Use PostgreSQL and Redis-backed rate limiting.
- Add refresh-token rotation/revocation and MFA.
- Add immutable/append-only audit storage and alerting.
- Add CSRF strategy if browser cookies are introduced; current API uses bearer tokens.
- Add secrets manager, TLS termination, trusted proxy configuration and deployment hardening.
- Add formal cross-tenant, authorization, dependency, fuzz and load tests.
- Add SAST, dependency scanning, SBOM and signed build artifacts in CI.
