# Deployment notes — Global Grid foundation

## Local development (Windows PowerShell)

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
$env:JWT_SECRET = "replace-with-a-random-secret-at-least-32-characters"
$env:DATABASE_URL = "sqlite:///./cybershield.db"
uvicorn app.main:app --reload
```

Open `http://127.0.0.1:8000/docs` and `http://127.0.0.1:8000/health`.

## Run tests

```powershell
python -m pip install -r requirements-dev.txt
$env:JWT_SECRET = "test-secret-change-me-at-least-32-characters"
pytest -q
```

## Before any government pilot

Use PostgreSQL, Alembic migrations, external secrets manager, TLS/mTLS, national identity provider, MFA, immutable centralized audit, signed collectors, durable queue, object-lock evidence storage, backup/restore tests, SIEM integration tests, formal threat model, privacy/legal review and independent penetration testing. The included reference detector is intentionally small and is not a substitute for Wazuh/Suricata/Zeek or a production SIEM.
