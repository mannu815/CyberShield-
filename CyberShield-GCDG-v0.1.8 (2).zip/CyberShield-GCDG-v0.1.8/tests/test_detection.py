import pytest
from datetime import datetime, timezone, timedelta
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.session import Base
from app.db.models import Organization, DetectionEvent, DetectionAlert
from app.detection.normalizers import normalize
from app.detection.rules import correlate

@pytest.fixture
def db():
    engine=create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session=sessionmaker(bind=engine); session=Session()
    org=Organization(name="Test Org",slug="test-org"); session.add(org); session.commit()
    yield session,org
    session.close(); engine.dispose()

def test_suricata_normalization_and_ip_validation():
    event=normalize("suricata",{"timestamp":"2026-11-05T12:00:00Z","event_type":"alert","src_ip":"203.0.113.9","dest_ip":"192.0.2.10","alert":{"signature":"ET test signature","severity":1,"signature_id":123}})
    assert event["severity"]=="critical"
    assert event["src_ip"]=="203.0.113.9"
    assert event["attributes"]["signature_id"]=="123"

def test_wazuh_normalization_drops_sensitive_fields():
    event=normalize("wazuh",{"timestamp":"2026-11-05T12:00:00Z","rule":{"id":"5710","level":12,"description":"Failed password"},"agent":{"id":"001"},"data":{"srcip":"203.0.113.4","password":"dont-store","user":"alice"}})
    assert event["severity"]=="high"
    assert event["src_ip"]=="203.0.113.4"
    assert "password" not in event["attributes"]

def test_zeek_normalization():
    event=normalize("zeek",{"_path":"conn","ts":1793880000,"id.orig_h":"203.0.113.1","id.resp_h":"192.0.2.1","proto":"tcp","uid":"Cabc"})
    assert event["source"]=="zeek" and event["src_ip"]=="203.0.113.1"

def test_fingerprint_stable_for_same_event():
    raw={"event_type":"alert","src_ip":"203.0.113.9","dest_ip":"192.0.2.1","alert":{"signature":"same","severity":2}}
    assert normalize("suricata",raw)["fingerprint"]==normalize("suricata",raw)["fingerprint"]

def test_high_suricata_event_creates_human_review_alert(db):
    session,org=db
    event=normalize("suricata",{"event_type":"alert","src_ip":"203.0.113.9","alert":{"signature":"suspicious test","severity":1}})
    row=DetectionEvent(organization_id=org.id,source="suricata",source_event_type=event["event_type"],severity=event["severity"],message=event["message"],src_ip=event["src_ip"],dst_ip=None,attributes=event["attributes"],fingerprint=event["fingerprint"],event_time=event["event_time"])
    session.add(row); session.flush(); correlate(session,row); session.commit()
    alert=session.query(DetectionAlert).one()
    assert alert.rule_id=="network.signature.high" and alert.status=="open"
    assert "validate" in alert.remediation.lower()

def test_wazuh_auth_failure_burst_rule(db):
    session,org=db
    now=datetime.now(timezone.utc)
    for i in range(5):
        item=normalize("wazuh",{"timestamp":(now.replace(microsecond=0)+timedelta(seconds=i)).isoformat(),"rule":{"id":"5710","level":8,"description":"Failed password authentication"},"data":{"srcip":"203.0.113.8"}})
        row=DetectionEvent(organization_id=org.id,source="wazuh",source_event_type=item["event_type"],severity=item["severity"],message=item["message"],src_ip=item["src_ip"],dst_ip=None,attributes=item["attributes"],fingerprint=item["fingerprint"],event_time=item["event_time"])
        session.add(row); session.flush(); correlate(session,row)
    session.commit()
    assert session.query(DetectionAlert).filter_by(rule_id="auth.repeated_failure").count()==1
