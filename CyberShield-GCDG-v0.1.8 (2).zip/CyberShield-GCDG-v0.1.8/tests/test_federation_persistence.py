from datetime import datetime, timezone, timedelta
import pytest
from sqlalchemy import create_engine
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import sessionmaker
from app.db.session import Base
from app.db.models import FederationReplayNonce, FederatedIndicator

@pytest.fixture
def db():
    engine = create_engine("sqlite:///:memory:")
    Base.metadata.create_all(engine)
    Session = sessionmaker(bind=engine)
    session = Session()
    try:
        yield session
    finally:
        session.close()
        engine.dispose()

def test_nonce_is_persistently_unique_per_sender(db):
    expiry = datetime.now(timezone.utc) + timedelta(minutes=5)
    db.add(FederationReplayNonce(sender_node="peer-a", nonce="a" * 32, expires_at=expiry))
    db.commit()
    db.add(FederationReplayNonce(sender_node="peer-a", nonce="a" * 32, expires_at=expiry))
    with pytest.raises(IntegrityError):
        db.commit()
    db.rollback()

def test_same_nonce_from_different_peers_is_allowed(db):
    expiry = datetime.now(timezone.utc) + timedelta(minutes=5)
    db.add_all([
        FederationReplayNonce(sender_node="peer-a", nonce="b" * 32, expires_at=expiry),
        FederationReplayNonce(sender_node="peer-b", nonce="b" * 32, expires_at=expiry),
    ])
    db.commit()
    assert db.query(FederationReplayNonce).count() == 2

def test_indicator_digest_is_unique(db):
    row = dict(sender_node="peer-a", value="203.0.113.5", indicator_type="ipv4", confidence="0.9",
               handling="TLP:GREEN", payload_sha256="c" * 64, payload={"value":"203.0.113.5"})
    db.add(FederatedIndicator(**row)); db.commit()
    db.add(FederatedIndicator(**row))
    with pytest.raises(IntegrityError):
        db.commit()
    db.rollback()
