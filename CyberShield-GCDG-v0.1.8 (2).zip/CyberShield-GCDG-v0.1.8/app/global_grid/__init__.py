"""Defensive, policy-first primitives for the CyberShield sovereign grid."""
