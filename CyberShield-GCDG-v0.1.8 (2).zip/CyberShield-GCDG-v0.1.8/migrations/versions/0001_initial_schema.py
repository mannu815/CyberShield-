"""Create the initial CyberShield schema from registered SQLAlchemy metadata.

This is a bootstrap migration for fresh installations. For an existing v0.1.6
installation whose tables were created by create_all(), run `alembic stamp 0001`
then generate/apply subsequent migrations; do not run a destructive reset.
"""
from alembic import op
from app.db.session import Base
from app.db import models  # noqa: F401

revision = "0001"
down_revision = None
branch_labels = None
depends_on = None

def upgrade():
    Base.metadata.create_all(bind=op.get_bind())

def downgrade():
    Base.metadata.drop_all(bind=op.get_bind())
