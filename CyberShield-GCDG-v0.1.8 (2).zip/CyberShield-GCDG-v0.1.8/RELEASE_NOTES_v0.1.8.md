# CyberShield GCDG v0.1.8 — National SOC & Sovereign Admin

- Added `/national-soc`, an authenticated organization-scoped SOC workspace connected to live dashboard, alert, event, incident and assurance APIs.
- Added `/sovereign-admin`, a separate platform control-plane portal for global aggregate metadata, peer governance and audit review.
- Added `platform_admin`-only sovereign endpoints for global overview, peer listing, approve/reject/suspend decisions and global audit records.
- Peer decisions require a reason and are written to the audit log. Tenant `admin` remains unable to approve sovereign peers.
- Added local CLI role provisioning with explicit target confirmation; no public role-escalation API.
- Added shared portal stylesheet, authenticated CSV export, tests and deployment/security notes.
- National raw event and incident data remains tenant scoped; sovereign overview only returns aggregate counts and federation governance metadata.

This is an MVP interface layer. It does not claim government deployment, production-grade national identity proofing, legal trust establishment, or certified operational readiness.
