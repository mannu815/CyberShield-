# CyberShield release notes

## GCDG v0.1.1 — 2026-11-05
- Added `app/global_grid/signing.py`: canonical JSON, HMAC-SHA256 envelope signing and verification, sender/recipient binding, freshness checks, nonce validation, digest checks and indicator policy validation.
- Added eight standard-library unit tests covering success, policy rejection, tampering, wrong recipient, expiry, restricted handling, stale envelopes and weak keys.
- Added federation signing security-boundary documentation.
- No existing legacy v1.8 files or existing API routes were removed.

## Known limitations carried forward
- The FastAPI application still initializes SQLAlchemy tables with `Base.metadata.create_all()` at import time; Alembic migrations are not present.
- Full dependency-based tests were not runnable in the build environment because package-index network access was unavailable.
- Federation signing is a library primitive only: no peer API, durable nonce/replay store, mTLS gateway or national PKI integration exists yet.

## 0.1.2 — Persistent sovereign federation gateway
- Added encrypted peer-secret storage and admin peer registry.
- Added signed indicator ingestion, persistent replay protection, duplicate detection and received IOC inventory.
- Added tests for nonce and payload uniqueness constraints.
- Federation remains intelligence-only; no automated defensive action is triggered.


## v0.1.3 — GCDG Phase 3 threat intelligence MVP
- Added bounded NVD CVE API 2.0 and CISA KEV catalog ingestion.
- Added optional MISP REST and OpenCTI GraphQL IOC connectors.
- Added tenant-scoped CVE/IOC tables, provenance metadata, confidence, references and sync history.
- Added role-protected, rate-limited manual sync APIs, exact IOC correlation, audit events and connector documentation.
- No automated blocking or response; connector validation and schema migrations remain deployment requirements.

## v0.1.4 — Phase 4 Detection & Event Correlation
- Added organization-scoped Wazuh, Suricata and Zeek sensor credentials with one-time key display and admin disable action.
- Added bounded authenticated ingestion, source normalization, event fingerprint deduplication and deterministic detection rules.
- Added event/alert APIs, alert acknowledgement/resolution and detection summary.
- Added minimal HTTPS JSON-lines sensor shipper and Phase 4 setup/test documentation.
- No autonomous response or blocking actions.


## v0.1.5 — Phase 5 SOC Dashboard & Incident Management
- Added dark browser dashboard at `/soc` with memory-only bearer token handling.
- Added dashboard overview/trends, organization-scoped incident cases, alert linking, analyst assignment, notes, timeline and JSON/CSV exports.
- Added tests and Phase 5 operating/security documentation.
- No automated containment or response.

## v0.1.6 — Phases 6–10
- Added deterministic, evidence-linked analyst case investigation and local IOC exact-match correlation.
- Added asset profiles and transparent weighted risk prioritization.
- Added baseline assurance catalog and organization-scoped evidence tracking.
- Added organization-scoped JSON backup export, checksum validation (dry-run only), and operations readiness checks.
- Added admin governance decisions and federation peer approval controls.
- Added phase documentation and explicit production/safety limitations.


## v0.1.7 — Security hardening foundation
- Disabled direct tenant-admin activation of global federation peers; registration now enters pending sovereign review.
- Restricted shared federation indicator visibility to admin + clear handling labels; added ingress size/rate controls and replay nonce cleanup.
- Neutralized CSV spreadsheet formulas; strengthened production security headers and config guardrails.
- Added Alembic bootstrap, CI JWT test configuration, sensor final-batch HTTP retry, and organization backup v2 coverage.
- Documented remaining gaps: mTLS ingress enforcement, peer approval UI, durable sensor offsets, backup restore, MFA/SSO, cloud integrations and national SOC workflows.

## v0.1.8 — National SOC & Sovereign Admin
- Added authenticated National SOC and Sovereign Admin portals.
- Added platform-admin-only global peer governance, aggregate overview and global audit APIs.
- Added audited, reason-required peer approve/reject/suspend decisions and local-only role provisioning.
- Added portal tests and sovereign operations documentation.
