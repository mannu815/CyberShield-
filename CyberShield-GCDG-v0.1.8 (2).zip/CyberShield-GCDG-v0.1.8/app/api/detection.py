from __future__ import annotations
import hashlib, secrets, json
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models import User, SensorCredential, DetectionEvent, DetectionAlert
from app.dependencies import require_roles, get_current_user
from app.audit import write_audit
from app.core.rate_limit import limiter
from app.detection.normalizers import normalize, SOURCES
from app.detection.rules import correlate

router = APIRouter(prefix="/detection", tags=["Detection & Event Correlation"])

class SensorIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    source: str = Field(pattern="^(wazuh|suricata|zeek)$")

class IngestBatch(BaseModel):
    events: list[dict] = Field(min_length=1, max_length=250)

@router.post("/sensors", status_code=201)
def create_sensor(payload: SensorIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    secret = "csg_" + secrets.token_urlsafe(32)
    row = SensorCredential(organization_id=user.organization_id, name=payload.name.strip(), source=payload.source, key_hash=hashlib.sha256(secret.encode()).hexdigest())
    db.add(row); db.commit(); db.refresh(row)
    write_audit(db, request, "detection.sensor.create", "success", user, f"sensor:{row.id}", {"source":row.source})
    return {"id":row.id,"name":row.name,"source":row.source,"api_key":secret,"warning":"Store this key securely; it is shown only once."}

@router.get("/sensors")
def list_sensors(db: Session = Depends(get_db), user: User = Depends(require_roles("admin","analyst"))):
    rows=db.query(SensorCredential).filter_by(organization_id=user.organization_id).order_by(SensorCredential.id.desc()).all()
    return [{"id":r.id,"name":r.name,"source":r.source,"enabled":r.enabled,"created_at":r.created_at} for r in rows]

@router.post("/sensors/{sensor_id}/disable")
def disable_sensor(sensor_id:int,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin"))):
    row=db.query(SensorCredential).filter_by(id=sensor_id,organization_id=user.organization_id).first()
    if not row: raise HTTPException(404,"Sensor not found")
    row.enabled=False; db.commit()
    write_audit(db,request,"detection.sensor.disable","success",user,f"sensor:{row.id}",{"source":row.source})
    return {"id":row.id,"enabled":row.enabled,"status":"disabled"}

@router.post("/ingest/{source}")
@limiter.limit("120/minute")
def ingest(source: str, request: Request, payload: IngestBatch, x_sensor_key: str = Header(default="", alias="X-Sensor-Key"), db: Session = Depends(get_db)):
    if source not in SOURCES: raise HTTPException(404,"Unsupported sensor source")
    if len(x_sensor_key) < 20 or len(x_sensor_key) > 200: raise HTTPException(401,"Invalid sensor credentials")
    key_hash=hashlib.sha256(x_sensor_key.encode()).hexdigest()
    sensor=db.query(SensorCredential).filter_by(key_hash=key_hash,source=source,enabled=True).first()
    if not sensor: raise HTTPException(401,"Invalid sensor credentials")
    try:
        raw_size=len(json.dumps(payload.model_dump(),separators=(",",":"),default=str).encode())
    except Exception: raise HTTPException(400,"Invalid event payload")
    if raw_size > 1_000_000: raise HTTPException(413,"Batch exceeds 1 MB limit")
    inserted=duplicates=0; event_ids=[]
    for raw in payload.events:
        try: item=normalize(source,raw)
        except (ValueError, TypeError): continue
        existing=db.query(DetectionEvent.id).filter_by(organization_id=sensor.organization_id,fingerprint=item["fingerprint"]).first()
        if existing: duplicates+=1; continue
        row=DetectionEvent(organization_id=sensor.organization_id,sensor_id=sensor.id,source=source,source_event_type=item["event_type"],severity=item["severity"],message=item["message"],src_ip=item["src_ip"],dst_ip=item["dst_ip"],attributes=item["attributes"],fingerprint=item["fingerprint"],event_time=item["event_time"])
        db.add(row); db.flush(); inserted+=1; event_ids.append(row.id)
        correlate(db,row)
    sensor.last_seen=datetime.now(timezone.utc)
    db.commit()
    return {"status":"accepted","source":source,"received":len(payload.events),"inserted":inserted,"duplicates":duplicates,"alerts_created":db.query(DetectionAlert).filter(DetectionAlert.event_id.in_(event_ids)).count() if event_ids else 0}

@router.get("/events")
def list_events(limit:int=Query(100,ge=1,le=250),source:str|None=None,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    q=db.query(DetectionEvent).filter_by(organization_id=user.organization_id)
    if source:
        if source not in SOURCES: raise HTTPException(400,"Invalid source")
        q=q.filter_by(source=source)
    rows=q.order_by(DetectionEvent.id.desc()).limit(limit).all()
    return [_event_out(r) for r in rows]

def _event_out(r):
    return {"id":r.id,"source":r.source,"event_type":r.source_event_type,"severity":r.severity,"message":r.message,"src_ip":r.src_ip,"dst_ip":r.dst_ip,"attributes":r.attributes,"event_time":r.event_time,"received_at":r.received_at}

@router.get("/alerts")
def list_alerts(status:str|None=None,limit:int=Query(100,ge=1,le=250),db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    q=db.query(DetectionAlert).filter_by(organization_id=user.organization_id)
    if status:
        if status not in {"open","acknowledged","resolved"}: raise HTTPException(400,"Invalid status")
        q=q.filter_by(status=status)
    rows=q.order_by(DetectionAlert.id.desc()).limit(limit).all()
    return [_alert_out(r) for r in rows]

def _alert_out(r):
    return {"id":r.id,"event_id":r.event_id,"rule_id":r.rule_id,"title":r.title,"severity":r.severity,"status":r.status,"description":r.description,"src_ip":r.src_ip,"remediation":r.remediation,"created_at":r.created_at,"updated_at":r.updated_at}

class AlertUpdate(BaseModel):
    status: str = Field(pattern="^(acknowledged|resolved)$")

@router.patch("/alerts/{alert_id}")
def update_alert(alert_id:int,payload:AlertUpdate,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    row=db.query(DetectionAlert).filter_by(id=alert_id,organization_id=user.organization_id).first()
    if not row: raise HTTPException(404,"Alert not found")
    row.status=payload.status; row.updated_at=datetime.now(timezone.utc); db.commit()
    write_audit(db,request,"detection.alert.update","success",user,f"alert:{row.id}",{"status":row.status})
    return _alert_out(row)

@router.get("/summary")
def summary(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    base=db.query(DetectionEvent).filter_by(organization_id=user.organization_id)
    alerts=db.query(DetectionAlert).filter_by(organization_id=user.organization_id)
    return {"events_total":base.count(),"events_24h":base.filter(DetectionEvent.received_at>=datetime.now(timezone.utc)-timedelta(hours=24)).count(),"alerts_open":alerts.filter_by(status="open").count(),"alerts_critical":alerts.filter_by(severity="critical",status="open").count(),"by_source":{s:base.filter_by(source=s).count() for s in sorted(SOURCES)},"mode":"detection and human-reviewed alerting only"}
