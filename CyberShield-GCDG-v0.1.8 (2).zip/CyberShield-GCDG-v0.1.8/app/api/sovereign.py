from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Query
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models import PeerNode, AuditLog, Organization, User, DetectionEvent, DetectionAlert, IncidentCase, FederatedIndicator
from app.dependencies import require_roles
from app.audit import write_audit

router = APIRouter(prefix="/api/v1/sovereign", tags=["Sovereign Platform Administration"])

@router.get("/overview")
def sovereign_overview(db: Session = Depends(get_db), actor: User = Depends(require_roles("platform_admin"))):
    return {
        "organizations": db.query(Organization).count(),
        "users": db.query(User).count(),
        "peers": db.query(PeerNode).count(),
        "peers_pending": db.query(PeerNode).filter_by(enabled=False, policy_approved=False).count(),
        "peers_active": db.query(PeerNode).filter_by(enabled=True, policy_approved=True).count(),
        "federated_indicators": db.query(FederatedIndicator).count(),
        "events": db.query(DetectionEvent).count(),
        "alerts_open": db.query(DetectionAlert).filter_by(status="open").count(),
        "incidents_open": db.query(IncidentCase).filter(IncidentCase.status.in_(["open", "investigating", "contained"])).count(),
        "generated_at": datetime.now(timezone.utc),
        "scope_notice": "Global operational metadata only. Country telemetry remains in its sovereign organization boundary."
    }

@router.get("/peers")
def sovereign_peers(db: Session = Depends(get_db), actor: User = Depends(require_roles("platform_admin"))):
    rows = db.query(PeerNode).order_by(PeerNode.created_at.desc()).limit(500).all()
    return [{"id":p.id,"node_id":p.node_id,"display_name":p.display_name,"country_code":p.country_code,
             "enabled":p.enabled,"policy_approved":p.policy_approved,"created_at":p.created_at,
             "state":"active" if p.enabled and p.policy_approved else "pending_review" if not p.enabled and not p.policy_approved else "disabled_or_inconsistent"} for p in rows]

@router.post("/peers/{peer_id}/decision")
def peer_decision(peer_id: int, payload: dict, request: Request, db: Session = Depends(get_db), actor: User = Depends(require_roles("platform_admin"))):
    decision = payload.get("decision") if isinstance(payload, dict) else None
    rationale = payload.get("rationale", "") if isinstance(payload, dict) else ""
    if decision not in {"approve", "reject", "suspend"}:
        raise HTTPException(422, "decision must be approve, reject, or suspend")
    if not isinstance(rationale, str) or len(rationale.strip()) < 12 or len(rationale) > 2000:
        raise HTTPException(422, "Provide a rationale of 12-2000 characters")
    peer = db.query(PeerNode).filter_by(id=peer_id).first()
    if not peer:
        raise HTTPException(404, "Peer not found")
    if decision == "approve":
        peer.policy_approved, peer.enabled = True, True
    elif decision == "reject":
        peer.policy_approved, peer.enabled = False, False
    else:
        peer.enabled = False
    db.commit(); db.refresh(peer)
    write_audit(db, request, f"sovereign.peer.{decision}", "success", actor, f"peer:{peer.node_id}", {"rationale":rationale.strip(),"enabled":peer.enabled,"policy_approved":peer.policy_approved})
    return {"id":peer.id,"node_id":peer.node_id,"enabled":peer.enabled,"policy_approved":peer.policy_approved,"state":"active" if peer.enabled and peer.policy_approved else "pending_or_suspended"}

@router.get("/audit")
def sovereign_audit(limit: int = Query(100, ge=1, le=250), db: Session = Depends(get_db), actor: User = Depends(require_roles("platform_admin"))):
    rows = db.query(AuditLog).order_by(AuditLog.id.desc()).limit(limit).all()
    return [{"id":r.id,"created_at":r.created_at,"actor_email":r.actor_email,"action":r.action,"resource":r.resource,"outcome":r.outcome,"organization_id":r.organization_id,"details":r.details} for r in rows]
