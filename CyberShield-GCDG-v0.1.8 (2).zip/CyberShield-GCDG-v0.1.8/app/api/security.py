from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field, HttpUrl
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models import User, Asset, Assessment, Finding, SecurityEvent, ThreatRecord
from app.dependencies import get_current_user, require_roles
from app.audit import write_audit
from app.security_services import normalize_web_target, analyze_headers, analyze_cloud_config, ai_explanation
from datetime import datetime, timezone
import json, csv, io
from fastapi.responses import StreamingResponse

router=APIRouter(tags=["Security Intelligence"])
class AssetIn(BaseModel):
 name:str=Field(min_length=2,max_length=160)
 target:str=Field(min_length=4,max_length=512)
 authorization_reference:str=Field(min_length=3,max_length=255,description="Ticket, contract or written authorization reference")
class HeaderAssessmentIn(BaseModel):
 headers:dict[str,str]
 scheme:str="https"
class CloudAssessmentIn(BaseModel):
 document:dict
class EventIn(BaseModel):
 event_type:str=Field(min_length=2,max_length=80)
 severity:str=Field(default="info",pattern="^(critical|high|medium|low|info)$")
 source:str=Field(default="manual",max_length=120)
 message:str=Field(min_length=2,max_length=2000)
 attributes:dict={}

def owned_asset(db,user,asset_id):
 a=db.query(Asset).filter(Asset.id==asset_id,Asset.organization_id==user.organization_id,Asset.active.is_(True)).first()
 if not a: raise HTTPException(404,"Asset not found")
 return a

@router.post("/assets",status_code=201)
def create_asset(payload:AssetIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
 try: target=normalize_web_target(payload.target)
 except ValueError as e: raise HTTPException(400,str(e))
 a=Asset(organization_id=user.organization_id,name=payload.name.strip(),asset_type="web",canonical_target=target,authorization_reference=payload.authorization_reference.strip(),created_by=user.id)
 db.add(a)
 try: db.commit()
 except Exception:
  db.rollback(); raise HTTPException(409,"This target is already registered in your organization")
 db.refresh(a); write_audit(db,request,"asset.create","success",user,f"asset:{a.id}")
 return {"id":a.id,"name":a.name,"target":a.canonical_target,"authorization_reference":a.authorization_reference,"active":a.active}

@router.get("/assets")
def list_assets(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
 return [{"id":a.id,"name":a.name,"target":a.canonical_target,"active":a.active,"created_at":a.created_at} for a in db.query(Asset).filter(Asset.organization_id==user.organization_id).order_by(Asset.id.desc()).all()]

def save_assessment(db,user,asset,kind,findings,evidence):
 summary={"total":len(findings),"by_severity":{s:sum(1 for f in findings if f["severity"]==s) for s in ["critical","high","medium","low","informational"]},"mode":"evidence-analysis; no exploit traffic"}
 a=Assessment(organization_id=user.organization_id,asset_id=asset.id,created_by=user.id,assessment_type=kind,summary=summary,evidence=evidence)
 db.add(a); db.flush()
 for f in findings:
  db.add(Finding(organization_id=user.organization_id,assessment_id=a.id,title=f["title"],severity=f["severity"],confidence=f.get("confidence","medium"),status=f.get("status","potential"),category=f["category"],evidence=f.get("evidence",{}),remediation=f["remediation"]))
 db.commit(); db.refresh(a); return a,summary

@router.post("/assets/{asset_id}/assessments/headers",status_code=201)
def assess_headers(asset_id:int,payload:HeaderAssessmentIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
 asset=owned_asset(db,user,asset_id); findings=analyze_headers(payload.headers,payload.scheme)
 a,summary=save_assessment(db,user,asset,"http-header-evidence",findings,{"scheme":payload.scheme,"headers_received":sorted(payload.headers.keys())})
 write_audit(db,request,"assessment.headers","success",user,f"assessment:{a.id}")
 return {"assessment_id":a.id,"asset_id":asset.id,"summary":summary,"findings":findings}

@router.post("/assets/{asset_id}/assessments/cloud-config",status_code=201)
def assess_cloud(asset_id:int,payload:CloudAssessmentIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
 asset=owned_asset(db,user,asset_id); findings=analyze_cloud_config(payload.document)
 a,summary=save_assessment(db,user,asset,"cloud-config-json",findings,{"resource_count":len(payload.document.get("resources",[])) if isinstance(payload.document.get("resources",[]),list) else None})
 write_audit(db,request,"assessment.cloud_config","success",user,f"assessment:{a.id}")
 return {"assessment_id":a.id,"summary":summary,"findings":findings}

@router.get("/assessments")
def list_assessments(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
 rows=db.query(Assessment).filter(Assessment.organization_id==user.organization_id).order_by(Assessment.id.desc()).limit(100).all()
 return [{"id":a.id,"asset_id":a.asset_id,"type":a.assessment_type,"status":a.status,"summary":a.summary,"created_at":a.created_at} for a in rows]

@router.get("/assessments/{assessment_id}/findings")
def findings(assessment_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
 a=db.query(Assessment).filter(Assessment.id==assessment_id,Assessment.organization_id==user.organization_id).first()
 if not a: raise HTTPException(404,"Assessment not found")
 rows=db.query(Finding).filter(Finding.assessment_id==a.id,Finding.organization_id==user.organization_id).all()
 return [{"id":f.id,"title":f.title,"severity":f.severity,"confidence":f.confidence,"status":f.status,"category":f.category,"evidence":f.evidence,"remediation":f.remediation} for f in rows]

@router.get("/findings/{finding_id}/explanation")
def explain(finding_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
 f=db.query(Finding).filter(Finding.id==finding_id,Finding.organization_id==user.organization_id).first()
 if not f: raise HTTPException(404,"Finding not found")
 return ai_explanation({"title":f.title,"severity":f.severity,"evidence":f.evidence,"remediation":f.remediation})

@router.post("/events",status_code=201)
def create_event(payload:EventIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
 safe_attributes = {str(k)[:64]: v for k, v in list(payload.attributes.items())[:20] if not any(x in str(k).lower() for x in ("password", "token", "secret", "cookie", "authorization", "api_key")) and isinstance(v, (str, int, float, bool, type(None)))}
 e=SecurityEvent(organization_id=user.organization_id,event_type=payload.event_type,severity=payload.severity,source=payload.source,message=payload.message,attributes=safe_attributes)
 db.add(e); db.commit(); db.refresh(e); write_audit(db,request,"security_event.create","success",user,f"event:{e.id}")
 return {"id":e.id,"created_at":e.created_at}

@router.get("/events")
def list_events(limit:int=100,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
 limit=max(1,min(limit,200)); rows=db.query(SecurityEvent).filter(SecurityEvent.organization_id==user.organization_id).order_by(SecurityEvent.id.desc()).limit(limit).all()
 return [{"id":e.id,"event_type":e.event_type,"severity":e.severity,"source":e.source,"message":e.message,"attributes":e.attributes,"created_at":e.created_at} for e in rows]

@router.get("/reports/assessments/{assessment_id}.json")
def export_report(assessment_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
 a=db.query(Assessment).filter(Assessment.id==assessment_id,Assessment.organization_id==user.organization_id).first()
 if not a: raise HTTPException(404,"Assessment not found")
 fs=db.query(Finding).filter(Finding.assessment_id==a.id).all()
 return {"product":"CyberShield AI","report_version":"1.0","assessment":{"id":a.id,"type":a.assessment_type,"created_at":a.created_at,"summary":a.summary,"evidence":a.evidence},"findings":[{"id":f.id,"title":f.title,"severity":f.severity,"status":f.status,"confidence":f.confidence,"category":f.category,"evidence":f.evidence,"remediation":f.remediation} for f in fs],"limitations":["Evidence analysis only; not a full penetration test.","Potential findings require human validation.","No exploit traffic was generated."]}

class ThreatRecordIn(BaseModel):
    cve_id: str = Field(pattern=r"^CVE-\d{4}-\d{4,}$")
    summary: str = Field(default="", max_length=5000)
    severity: str = Field(default="unknown", pattern="^(critical|high|medium|low|unknown)$")
    cvss_score: str = Field(default="", max_length=10)
    known_exploited: bool = False
    references: list[str] = Field(default_factory=list, max_length=20)

@router.post("/threat-intelligence/records", status_code=201)
def upsert_threat_record(payload: ThreatRecordIn, request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst"))):
    record = db.query(ThreatRecord).filter(ThreatRecord.organization_id == user.organization_id, ThreatRecord.cve_id == payload.cve_id).first()
    if record is None:
        record = ThreatRecord(organization_id=user.organization_id, cve_id=payload.cve_id, source="manual_import")
        db.add(record)
    record.summary = payload.summary
    record.severity = payload.severity
    record.cvss_score = payload.cvss_score
    record.known_exploited = payload.known_exploited
    record.references = [u for u in payload.references if u.startswith("https://")][:20]
    record.updated_at = datetime.now(timezone.utc)
    db.commit(); db.refresh(record)
    write_audit(db, request, "threat_intel.upsert", "success", user, f"threat:{record.cve_id}")
    return {"cve_id": record.cve_id, "severity": record.severity, "known_exploited": record.known_exploited}

@router.get("/threat-intelligence/records")
def list_threat_records(limit: int = 100, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    limit = max(1, min(limit, 200))
    rows = db.query(ThreatRecord).filter(ThreatRecord.organization_id == user.organization_id).order_by(ThreatRecord.known_exploited.desc(), ThreatRecord.updated_at.desc()).limit(limit).all()
    return [{"cve_id": r.cve_id, "summary": r.summary, "severity": r.severity, "cvss_score": r.cvss_score, "known_exploited": r.known_exploited, "references": r.references, "updated_at": r.updated_at} for r in rows]
