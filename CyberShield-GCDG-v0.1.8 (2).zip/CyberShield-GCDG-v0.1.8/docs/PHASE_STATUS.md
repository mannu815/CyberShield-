# Phase Status

| Phase | Capability | Status in v0.1.6 |
|---|---|---|
| 1 | Secure foundation, auth, RBAC, audit | MVP |
| 2 | Signed sovereign federation gateway | MVP |
| 3 | Threat intelligence connectors | MVP; external feeds require operator credentials |
| 4 | Wazuh/Suricata/Zeek event ingestion and correlation | MVP; live sensors require deployment |
| 5 | SOC dashboard and incident case management | MVP |
| 6 | Evidence-grounded analyst decision support | MVP; deterministic engine, no external LLM |
| 7 | Asset profiles and risk prioritization | MVP; heuristic score |
| 8 | Assurance controls and evidence tracking | MVP; not certification |
| 9 | Backup export, checksum validation and readiness | MVP; validation is dry-run, not restore |
| 10 | Sovereign governance and federation peer approvals | MVP; indicator exchange only |

Production readiness is not asserted. Review `docs/PHASES6_TO10.md`, `docs/THREAT_MODEL.md`, and `docs/DEPLOYMENT_NOTES.md`.
