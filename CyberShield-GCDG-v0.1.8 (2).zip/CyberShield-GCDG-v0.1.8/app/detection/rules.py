from datetime import datetime, timedelta, timezone
from app.db.models import DetectionEvent, DetectionAlert

def correlate(db, event: DetectionEvent):
    """Create deterministic, explainable alerts; never executes response actions."""
    rules=[]
    if event.source=="suricata" and event.severity in {"critical","high"}:
        rules.append(("network.signature.high","High-severity network IDS signature",event.severity,"Review the Suricata signature, packet context and affected asset. Validate before containment."))
    if event.source=="wazuh" and event.severity in {"critical","high"}:
        rules.append(("host.alert.high","High-severity host security alert",event.severity,"Review the Wazuh rule, endpoint telemetry and change history. Validate before response."))
    if event.source=="zeek" and event.source_event_type in {"notice","weird"}:
        rules.append(("network.zeek.notice","Zeek network notice","medium","Review the Zeek notice and surrounding connection metadata."))
    if event.source=="wazuh" and event.src_ip and any(x in (event.message+event.source_event_type).lower() for x in ("authentication failed","login failed","failed password","invalid user")):
        since=datetime.now(timezone.utc)-timedelta(minutes=10)
        count=db.query(DetectionEvent).filter(DetectionEvent.organization_id==event.organization_id,DetectionEvent.source=="wazuh",DetectionEvent.src_ip==event.src_ip,DetectionEvent.event_time>=since).count()
        if count>=5: rules.append(("auth.repeated_failure","Repeated authentication failures from one source IP","high","Investigate the source IP, account targeting and endpoint logs. Apply approved identity controls only after validation."))
    for rule,title,severity,remediation in rules:
        if not db.query(DetectionAlert.id).filter_by(organization_id=event.organization_id,rule_id=rule,event_id=event.id).first():
            db.add(DetectionAlert(organization_id=event.organization_id,event_id=event.id,rule_id=rule,title=title,severity=severity,description=event.message[:1000],src_ip=event.src_ip,remediation=remediation))
