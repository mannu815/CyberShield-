from __future__ import annotations
import csv, io, secrets
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy import func
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.db.models import (User, DetectionAlert, DetectionEvent, IncidentCase, IncidentCaseAlert,
                           IncidentCaseNote, IncidentCaseActivity)
from app.dependencies import get_current_user, require_roles
from app.audit import write_audit

router = APIRouter(tags=["SOC Dashboard & Incident Management"])
STATUSES = {"open", "investigating", "contained", "resolved", "closed"}
SEVERITIES = {"critical", "high", "medium", "low", "info"}

class CaseCreate(BaseModel):
    title: str = Field(min_length=3, max_length=200)
    description: str = Field(default="", max_length=10000)
    severity: str = Field(default="medium", pattern="^(critical|high|medium|low|info)$")
    alert_ids: list[int] = Field(default_factory=list, max_length=100)

class CaseUpdate(BaseModel):
    status: str | None = Field(default=None, pattern="^(open|investigating|contained|resolved|closed)$")
    severity: str | None = Field(default=None, pattern="^(critical|high|medium|low|info)$")
    assigned_to: int | None = None
    title: str | None = Field(default=None, min_length=3, max_length=200)
    description: str | None = Field(default=None, max_length=10000)

class NoteCreate(BaseModel):
    body: str = Field(min_length=1, max_length=10000)


def _case(db, case):
    links = db.query(IncidentCaseAlert).filter_by(case_id=case.id).all()
    return {"id":case.id,"case_number":case.case_number,"title":case.title,"description":case.description,
            "severity":case.severity,"status":case.status,"assigned_to":case.assigned_to,
            "created_by":case.created_by,"alert_ids":[x.alert_id for x in links],
            "created_at":case.created_at,"updated_at":case.updated_at,"resolved_at":case.resolved_at}


def _activity(db, case, user, action, details=None):
    db.add(IncidentCaseActivity(case_id=case.id, organization_id=user.organization_id,
        actor_user_id=user.id, action=action, details=details or {}))


def _get_case(db, case_id, org_id):
    row=db.query(IncidentCase).filter_by(id=case_id, organization_id=org_id).first()
    if not row: raise HTTPException(404, "Incident case not found")
    return row

@router.get("/api/v1/dashboard/overview")
def dashboard_overview(db:Session=Depends(get_db), user:User=Depends(get_current_user)):
    now=datetime.now(timezone.utc); since=now-timedelta(hours=24)
    ev=db.query(DetectionEvent).filter_by(organization_id=user.organization_id)
    al=db.query(DetectionAlert).filter_by(organization_id=user.organization_id)
    cases=db.query(IncidentCase).filter_by(organization_id=user.organization_id)
    return {"generated_at":now,"events":{"total":ev.count(),"last_24h":ev.filter(DetectionEvent.received_at>=since).count(),
            "by_source":{s:ev.filter_by(source=s).count() for s in ("wazuh","suricata","zeek")}},
            "alerts":{"open":al.filter_by(status="open").count(),"critical_open":al.filter_by(status="open",severity="critical").count(),
            "by_severity":{s:al.filter_by(severity=s,status="open").count() for s in sorted(SEVERITIES)}},
            "cases":{"open":cases.filter(IncidentCase.status.in_(["open","investigating","contained"])).count(),
            "unassigned":cases.filter(IncidentCase.status.in_(["open","investigating","contained"]),IncidentCase.assigned_to.is_(None)).count(),
            "resolved_24h":cases.filter(IncidentCase.resolved_at>=since).count()},
            "mode":"read-only dashboard; incident actions require analyst review"}

@router.get("/api/v1/dashboard/trends")
def dashboard_trends(days:int=Query(7,ge=1,le=30),db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    start=datetime.now(timezone.utc)-timedelta(days=days)
    rows=db.query(func.date(DetectionEvent.received_at),DetectionEvent.source,func.count(DetectionEvent.id)).filter(
        DetectionEvent.organization_id==user.organization_id,DetectionEvent.received_at>=start).group_by(
        func.date(DetectionEvent.received_at),DetectionEvent.source).all()
    data={}
    for day,source,count in rows: data.setdefault(str(day),{})[source]=count
    return {"days":days,"events_by_day_and_source":[{"date":d,"sources":data[d]} for d in sorted(data)]}

@router.post("/api/v1/incidents/cases",status_code=201)
def create_case(payload:CaseCreate,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    ids=list(dict.fromkeys(payload.alert_ids))
    alerts=[]
    if ids:
        alerts=db.query(DetectionAlert).filter(DetectionAlert.organization_id==user.organization_id,DetectionAlert.id.in_(ids)).all()
        if len(alerts)!=len(ids): raise HTTPException(422,"One or more alerts do not exist in your organization")
    case=IncidentCase(organization_id=user.organization_id,case_number="CS-"+secrets.token_hex(5).upper(),
        title=payload.title.strip(),description=payload.description,severity=payload.severity,created_by=user.id)
    db.add(case); db.flush()
    for alert in alerts: db.add(IncidentCaseAlert(case_id=case.id,alert_id=alert.id))
    _activity(db,case,user,"case.created",{"linked_alert_ids":ids})
    db.commit(); db.refresh(case)
    write_audit(db,request,"incident.case.create","success",user,f"case:{case.id}",{"severity":case.severity,"linked_alert_count":len(ids)})
    return _case(db,case)

@router.get("/api/v1/incidents/cases")
def list_cases(status:str|None=None,severity:str|None=None,assigned_to:int|None=None,limit:int=Query(100,ge=1,le=250),
               db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    q=db.query(IncidentCase).filter_by(organization_id=user.organization_id)
    if status:
        if status not in STATUSES: raise HTTPException(400,"Invalid case status")
        q=q.filter_by(status=status)
    if severity:
        if severity not in SEVERITIES: raise HTTPException(400,"Invalid severity")
        q=q.filter_by(severity=severity)
    if assigned_to is not None: q=q.filter_by(assigned_to=assigned_to)
    return [_case(db,r) for r in q.order_by(IncidentCase.updated_at.desc()).limit(limit).all()]

@router.get("/api/v1/incidents/cases/{case_id}")
def get_case(case_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    return _case(db,_get_case(db,case_id,user.organization_id))

@router.patch("/api/v1/incidents/cases/{case_id}")
def update_case(case_id:int,payload:CaseUpdate,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    case=_get_case(db,case_id,user.organization_id); changes={}
    data=payload.model_dump(exclude_unset=True)
    if "assigned_to" in data and data["assigned_to"] is not None:
        target=db.query(User).filter_by(id=data["assigned_to"],organization_id=user.organization_id,is_active=True).first()
        if not target: raise HTTPException(422,"Assignee must be an active user in your organization")
    for key,value in data.items():
        if getattr(case,key)!=value: changes[key]={"from":getattr(case,key),"to":value}; setattr(case,key,value)
    if case.status in {"resolved","closed"}:
        case.resolved_at=case.resolved_at or datetime.now(timezone.utc)
    elif "status" in data: case.resolved_at=None
    case.updated_at=datetime.now(timezone.utc)
    if changes: _activity(db,case,user,"case.updated",changes)
    db.commit(); db.refresh(case)
    write_audit(db,request,"incident.case.update","success",user,f"case:{case.id}",{"changed_fields":list(changes)})
    return _case(db,case)

@router.post("/api/v1/incidents/cases/{case_id}/notes",status_code=201)
def add_note(case_id:int,payload:NoteCreate,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    case=_get_case(db,case_id,user.organization_id)
    note=IncidentCaseNote(case_id=case.id,organization_id=user.organization_id,author_user_id=user.id,body=payload.body.strip())
    db.add(note); _activity(db,case,user,"note.added",{}); case.updated_at=datetime.now(timezone.utc); db.commit(); db.refresh(note)
    write_audit(db,request,"incident.case.note","success",user,f"case:{case.id}")
    return {"id":note.id,"case_id":case.id,"author_user_id":note.author_user_id,"body":note.body,"created_at":note.created_at}

@router.get("/api/v1/incidents/cases/{case_id}/timeline")
def case_timeline(case_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    case=_get_case(db,case_id,user.organization_id)
    acts=db.query(IncidentCaseActivity).filter_by(case_id=case.id,organization_id=user.organization_id).all()
    notes=db.query(IncidentCaseNote).filter_by(case_id=case.id,organization_id=user.organization_id).all()
    items=[{"type":"activity","action":a.action,"actor_user_id":a.actor_user_id,"details":a.details,"created_at":a.created_at} for a in acts]
    items += [{"type":"note","action":"note.added","actor_user_id":n.author_user_id,"details":{"body":n.body},"created_at":n.created_at} for n in notes]
    return sorted(items,key=lambda x:x["created_at"])

@router.get("/api/v1/incidents/export")
def export_incidents(format:str=Query("json",pattern="^(json|csv)$"),db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    rows=db.query(IncidentCase).filter_by(organization_id=user.organization_id).order_by(IncidentCase.created_at.desc()).limit(1000).all()
    data=[_case(db,r) for r in rows]
    if format=="json": return JSONResponse(content=[{**x,"created_at":x["created_at"].isoformat(),"updated_at":x["updated_at"].isoformat(),"resolved_at":x["resolved_at"].isoformat() if x["resolved_at"] else None} for x in data])
    def safe_csv_cell(value):
        text = str(value if value is not None else "")
        # Spreadsheet applications may execute formula-leading cells on open.
        if text.lstrip("\ufeff\t\r ").startswith(("=", "+", "-", "@")):
            return "'" + text
        return text
    stream=io.StringIO(newline=""); writer=csv.DictWriter(stream,fieldnames=["case_number","title","severity","status","assigned_to","alert_ids","created_at","updated_at"], quoting=csv.QUOTE_ALL)
    writer.writeheader()
    for x in data:
        row={k:(",".join(map(str,x[k])) if k=="alert_ids" else x[k]) for k in writer.fieldnames}
        writer.writerow({k:safe_csv_cell(v) for k,v in row.items()})
    return StreamingResponse(iter([stream.getvalue()]),media_type="text/csv",headers={"Content-Disposition":"attachment; filename=cybershield-incidents.csv"})
