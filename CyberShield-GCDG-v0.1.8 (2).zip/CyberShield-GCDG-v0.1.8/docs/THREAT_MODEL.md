# Threat model (initial)

## Assets
Credentials, JWT signing secret, organization records, authorized asset inventory, assessment evidence, findings, threat-intelligence records, audit logs.

## Threat actors
Unauthenticated internet user, compromised organization user, malicious tenant, malicious input embedded in evidence/configuration, compromised dependency, deployment operator error.

## Main risks and controls

| Risk | Initial control | Remaining work |
|---|---|---|
| Password disclosure | Argon2 password hashing; no password logging | MFA, breached-password checks |
| Token theft | Short-lived signed JWT; no token in audit logs | Revocation/rotation, secure browser storage |
| Brute-force login | Login rate limit | Redis shared limiter, lockout telemetry |
| Cross-tenant data access | Organization filters on customer data | Automated adversarial tenant tests for every route |
| Unauthorized target assessment | Asset registration requires authorization reference; current analyzers consume evidence only | Verify authorization evidence and scope lifecycle |
| SSRF / DNS rebinding | No live arbitrary-target fetching in this release | Egress proxy, DNS pinning, redirect/IP revalidation before live scanner |
| Malicious cloud config | JSON treated as data, never executed | Parser limits, fuzzing, schema versioning |
| Prompt injection | No external LLM execution in current release | Isolate retrieved text, tool allowlists, output validation, eval suite |
| Audit tampering | Audit records persisted in DB | Append-only external sink and integrity verification |
| Secret leakage | `.env` ignored by Git; secrets configured via environment | Secret scanning and managed secret store |

## Security invariants

- No destructive tests, brute force, denial-of-service, credential harvesting or arbitrary code execution.
- Every customer-owned object must be queried with the authenticated organization ID.
- AI output cannot confirm vulnerabilities or trigger actions by itself.
- Findings must retain evidence and remediation context.
- Unknown or inconclusive evidence must not be presented as a confirmed vulnerability.
