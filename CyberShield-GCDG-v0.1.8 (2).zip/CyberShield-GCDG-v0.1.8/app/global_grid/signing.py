"""Cryptographic envelope primitives for approved sovereign indicator exchange.

This module uses per-peer HMAC-SHA256 secrets as a development bridge. For
production federation, terminate mutually-authenticated TLS at the gateway and
replace HMAC key distribution with node PKI/asymmetric signatures (for example
Ed25519 or an organization-approved national PKI profile).
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from hashlib import sha256
import hmac
import json
import re
import secrets
from typing import Any

_ALLOWED_TYPES = {"ipv4", "ipv6", "domain", "url", "sha256", "sha1", "md5", "cve"}
_BLOCKED_HANDLING = {"TLP:RED", "RESTRICTED", "PERSONAL_DATA"}
_HEX = re.compile(r"^(?:[0-9a-fA-F]{64}|[0-9a-fA-F]{40}|[0-9a-fA-F]{32})$")


def canonical_json(value: Any) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


@dataclass(frozen=True)
class Indicator:
    value: str
    indicator_type: str
    source_node: str
    confidence: float
    first_seen: str
    expires_at: str
    handling: str

    def validate(self, now: datetime | None = None) -> None:
        now = now or datetime.now(timezone.utc)
        if self.indicator_type not in _ALLOWED_TYPES:
            raise ValueError("unsupported indicator_type")
        if not self.value or len(self.value) > 2048:
            raise ValueError("indicator value is empty or too long")
        if not self.source_node or len(self.source_node) > 128:
            raise ValueError("source_node is required and must be <=128 characters")
        if not 0.0 <= self.confidence <= 1.0:
            raise ValueError("confidence must be between 0 and 1")
        if self.handling.upper() in _BLOCKED_HANDLING:
            raise PermissionError("handling label prohibits federation")
        first = _parse_time(self.first_seen)
        expiry = _parse_time(self.expires_at)
        if expiry <= now:
            raise ValueError("indicator has expired")
        if first > now + timedelta(minutes=5):
            raise ValueError("first_seen is implausibly in the future")
        if expiry <= first:
            raise ValueError("expires_at must be later than first_seen")
        if self.indicator_type in {"md5", "sha1", "sha256"} and not _HEX.fullmatch(self.value):
            raise ValueError("hash indicator has invalid hexadecimal length")
        if self.indicator_type == "cve" and not re.fullmatch(r"CVE-\d{4}-\d{4,}", self.value):
            raise ValueError("invalid CVE identifier")


def _parse_time(value: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise ValueError("timestamps must be ISO-8601") from exc
    if parsed.tzinfo is None:
        raise ValueError("timestamps must include a timezone")
    return parsed.astimezone(timezone.utc)


def build_envelope(
    indicator: Indicator,
    *,
    sender_node: str,
    recipient_node: str,
    policy_approved: bool,
    peer_secret: bytes,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Create a minimized, signed package only after explicit policy approval."""
    if not policy_approved:
        raise PermissionError("national policy approval is required")
    if len(peer_secret) < 32:
        raise ValueError("peer_secret must contain at least 32 bytes")
    if not sender_node or not recipient_node or sender_node == recipient_node:
        raise ValueError("distinct sender_node and recipient_node are required")
    now = now or datetime.now(timezone.utc)
    indicator.validate(now)
    payload = asdict(indicator)
    envelope = {
        "schema": "cybershield.gcdg.indicator.v1",
        "sender_node": sender_node,
        "recipient_node": recipient_node,
        "issued_at": now.astimezone(timezone.utc).isoformat(),
        "nonce": secrets.token_hex(16),
        "payload": payload,
    }
    envelope["payload_sha256"] = sha256(canonical_json(payload)).hexdigest()
    envelope["signature"] = hmac.new(peer_secret, canonical_json(envelope), sha256).hexdigest()
    return envelope


def verify_envelope(
    envelope: dict[str, Any],
    *,
    expected_sender: str,
    expected_recipient: str,
    peer_secret: bytes,
    now: datetime | None = None,
    max_age: timedelta = timedelta(minutes=5),
) -> Indicator:
    """Verify authenticity, integrity, routing, freshness and payload policy.

    The caller MUST atomically persist/reject the nonce per sender after this
    function succeeds; this module intentionally does not pretend to provide a
    distributed replay database.
    """
    if len(peer_secret) < 32:
        raise ValueError("peer_secret must contain at least 32 bytes")
    if not isinstance(envelope, dict):
        raise ValueError("envelope must be an object")
    supplied_sig = envelope.get("signature")
    if not isinstance(supplied_sig, str):
        raise PermissionError("missing signature")
    unsigned = {k: v for k, v in envelope.items() if k != "signature"}
    expected_sig = hmac.new(peer_secret, canonical_json(unsigned), sha256).hexdigest()
    if not hmac.compare_digest(supplied_sig, expected_sig):
        raise PermissionError("invalid federation signature")
    if envelope.get("schema") != "cybershield.gcdg.indicator.v1":
        raise ValueError("unsupported federation schema")
    if envelope.get("sender_node") != expected_sender or envelope.get("recipient_node") != expected_recipient:
        raise PermissionError("federation route does not match configured peer")
    nonce = envelope.get("nonce")
    if not isinstance(nonce, str) or not re.fullmatch(r"[0-9a-f]{32}", nonce):
        raise ValueError("invalid nonce")
    issued = _parse_time(envelope.get("issued_at", ""))
    now = now or datetime.now(timezone.utc)
    if issued > now + timedelta(seconds=30) or now - issued > max_age:
        raise PermissionError("federation envelope is outside the accepted time window")
    payload = envelope.get("payload")
    if not isinstance(payload, dict):
        raise ValueError("payload must be an object")
    digest = sha256(canonical_json(payload)).hexdigest()
    if not hmac.compare_digest(str(envelope.get("payload_sha256", "")), digest):
        raise PermissionError("payload digest mismatch")
    indicator = Indicator(**payload)
    indicator.validate(now)
    return indicator
