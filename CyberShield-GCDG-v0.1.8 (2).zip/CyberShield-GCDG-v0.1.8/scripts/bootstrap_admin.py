import argparse
import re
import sys
from pathlib import Path
from getpass import getpass

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy.orm import Session
from app.core.security import hash_password
from app.db.models import Organization, User
from app.db.session import Base, SessionLocal, engine


def slugify(value: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", value.lower()).strip("-")
    return slug[:80] or "organization"


def main():
    parser = argparse.ArgumentParser(description="Create the first CyberShield AI organization administrator")
    parser.add_argument("--organization", required=True)
    parser.add_argument("--email", required=True)
    parser.add_argument("--name", required=True)
    parser.add_argument("--password", required=False, help="Administrator password (minimum 12 chars). Prompted if omitted.")
    args = parser.parse_args()
    if args.password:
        password = args.password
    else:
        password = getpass("Admin password (minimum 12 characters): ")
        confirmation = getpass("Confirm password: ")
        if password != confirmation:
            raise SystemExit("Passwords do not match")
    if len(password) < 12:
        raise SystemExit("Password must contain at least 12 characters")
    Base.metadata.create_all(bind=engine)
    db: Session = SessionLocal()
    try:
        email = args.email.strip().lower()
        if db.query(User).filter(User.email == email).first():
            raise SystemExit("This email already exists")
        base_slug = slugify(args.organization)
        slug, suffix = base_slug, 1
        while db.query(Organization).filter(Organization.slug == slug).first():
            suffix += 1
            slug = f"{base_slug[:70]}-{suffix}"
        org = Organization(name=args.organization.strip(), slug=slug)
        db.add(org)
        db.flush()
        admin = User(organization_id=org.id, email=email, full_name=args.name.strip(), password_hash=hash_password(password), role="admin", is_active=True)
        db.add(admin)
        db.commit()
        print(f"Created organization '{org.name}' and administrator '{admin.email}'.")
    finally:
        db.close()


if __name__ == "__main__":
    main()
