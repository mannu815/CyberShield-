from __future__ import annotations
import base64
from pathlib import Path
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
import httpx

router = APIRouter(prefix="/api/v1/deploy", tags=["Deployment"])

PROJECT_ROOT = Path(__file__).resolve().parent.parent.parent

IGNORE_DIRS = {".git", ".venv", "venv", "env", "__pycache__", ".pytest_cache", ".idea", ".vscode", "htmlcov"}
IGNORE_EXTS = {".pyc", ".pyo", ".pyd", ".db", ".sqlite", ".sqlite3", ".log"}
IGNORE_FILES = {".env", ".coverage"}


def should_ignore(rel_path: Path) -> bool:
    for part in rel_path.parts:
        if part in IGNORE_DIRS or part.startswith(".pytest_cache"):
            return True
    if rel_path.name in IGNORE_FILES:
        return True
    if rel_path.name.startswith(".env.") and not rel_path.name.endswith(".example"):
        return True
    if rel_path.suffix.lower() in IGNORE_EXTS:
        return True
    return False


def collect_files(root: Path) -> list[tuple[Path, str]]:
    files_to_upload = []
    for p in root.rglob("*"):
        if p.is_file():
            rel = p.relative_to(root)
            if not should_ignore(rel):
                files_to_upload.append((p, rel.as_posix()))
    return files_to_upload


class DeployRequest(BaseModel):
    token: str = Field(min_length=10, max_length=300)
    repo_name: str = Field(default="CyberShield-GCDG-National-SOC", min_length=1, max_length=100)
    description: str = Field(default="CyberShield AI / GCDG v0.1.8 — National SOC & Sovereign Admin Platform", max_length=350)
    private: bool = False


@router.post("/github")
async def deploy_to_github(payload: DeployRequest):
    token = payload.token.strip()
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "CyberShield-Web-Deployer/1.0"
    }

    async with httpx.AsyncClient(headers=headers, timeout=90.0) as client:
        # 1. Verify token
        user_resp = await client.get("https://api.github.com/user")
        if user_resp.status_code != 200:
            raise HTTPException(status_code=401, detail="Invalid GitHub token or authentication expired. Ensure 'repo' scope is selected.")
        
        user_info = user_resp.json()
        owner = user_info["login"]

        # 2. Check if repo exists or create it
        repo_name = payload.repo_name.strip()
        repo_resp = await client.get(f"https://api.github.com/repos/{owner}/{repo_name}")
        
        if repo_resp.status_code == 404:
            create_resp = await client.post("https://api.github.com/user/repos", json={
                "name": repo_name,
                "description": payload.description,
                "private": payload.private,
                "auto_init": True
            })
            if create_resp.status_code not in (200, 201):
                err = create_resp.json().get("message", create_resp.text)
                raise HTTPException(status_code=400, detail=f"Failed to create repository: {err}")
            repo_data = create_resp.json()
        elif repo_resp.status_code == 200:
            repo_data = repo_resp.json()
        else:
            raise HTTPException(status_code=repo_resp.status_code, detail=f"Error checking repository: {repo_resp.text}")

        repo_html_url = repo_data["html_url"]
        default_branch = repo_data.get("default_branch", "main")

        # 3. Get latest commit SHA on branch
        ref_resp = await client.get(f"https://api.github.com/repos/{owner}/{repo_name}/git/ref/heads/{default_branch}")
        parent_commit_sha = None
        if ref_resp.status_code == 200:
            parent_commit_sha = ref_resp.json()["object"]["sha"]

        # 4. Collect project files
        files = collect_files(PROJECT_ROOT)
        tree_items = []

        for local_path, git_path in files:
            try:
                content_bytes = local_path.read_bytes()
                b64_content = base64.b64encode(content_bytes).decode("ascii")
                blob_resp = await client.post(
                    f"https://api.github.com/repos/{owner}/{repo_name}/git/blobs",
                    json={"content": b64_content, "encoding": "base64"}
                )
                if blob_resp.status_code in (200, 201):
                    tree_items.append({
                        "path": git_path,
                        "mode": "100644",
                        "type": "blob",
                        "sha": blob_resp.json()["sha"]
                    })
                else:
                    raise HTTPException(status_code=500, detail=f"Failed uploading {git_path}: {blob_resp.text}")
            except HTTPException:
                raise
            except Exception as e:
                raise HTTPException(status_code=500, detail=f"Error reading {git_path}: {str(e)}")

        # 5. Create Git Tree
        tree_resp = await client.post(
            f"https://api.github.com/repos/{owner}/{repo_name}/git/trees",
            json={"tree": tree_items}
        )
        if tree_resp.status_code not in (200, 201):
            raise HTTPException(status_code=500, detail=f"Failed creating git tree: {tree_resp.text}")
        
        new_tree_sha = tree_resp.json()["sha"]

        # 6. Create Git Commit
        commit_payload = {
            "message": "CyberShield GCDG v0.1.8 - National SOC & Sovereign Admin Defensive Platform\n\nFull release with remediated security controls, landing hub, and passing test suites.",
            "tree": new_tree_sha
        }
        if parent_commit_sha:
            commit_payload["parents"] = [parent_commit_sha]

        commit_resp = await client.post(
            f"https://api.github.com/repos/{owner}/{repo_name}/git/commits",
            json=commit_payload
        )
        if commit_resp.status_code not in (200, 201):
            raise HTTPException(status_code=500, detail=f"Failed creating commit: {commit_resp.text}")

        new_commit_sha = commit_resp.json()["sha"]

        # 7. Update branch ref
        if parent_commit_sha:
            patch_resp = await client.patch(
                f"https://api.github.com/repos/{owner}/{repo_name}/git/refs/heads/{default_branch}",
                json={"sha": new_commit_sha, "force": True}
            )
        else:
            patch_resp = await client.post(
                f"https://api.github.com/repos/{owner}/{repo_name}/git/refs",
                json={"ref": f"refs/heads/{default_branch}", "sha": new_commit_sha}
            )

        if patch_resp.status_code not in (200, 201):
            raise HTTPException(status_code=500, detail=f"Failed updating branch ref: {patch_resp.text}")

        return {
            "status": "success",
            "owner": owner,
            "repo_name": repo_name,
            "repo_url": repo_html_url,
            "files_uploaded": len(tree_items),
            "commit_sha": new_commit_sha[:8]
        }
