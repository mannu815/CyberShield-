# GCDG Phase 3 — Threat intelligence ingestion (v0.1.3)

## Included

- NVD CVE API 2.0 ingestion (bounded to at most five 100-record pages per run; NVD API key is optional but recommended for rate limits).
- CISA Known Exploited Vulnerabilities (KEV) catalog ingestion; KEV status is treated as an exploited-in-the-wild signal, not proof that a local asset is vulnerable.
- Optional MISP REST attribute ingestion for selected IP, domain, URL, email and file-hash observables.
- Optional OpenCTI GraphQL ingestion for simple STIX IPv4, domain and SHA-256 patterns. Complex STIX patterns are deliberately skipped rather than guessed.
- Organization-scoped CVE/IOC records, source provenance, timestamps, confidence, references, duplicate handling, sync history and audit events.
- Manual, role-protected sync endpoints with a per-IP rate limit. No automatic blocking, scanning or response action is performed.

## Configure

Copy `.env.example` to `.env`. Keep tokens out of source control. For NVD, set `NVD_API_KEY` if available. For MISP and OpenCTI, set their HTTPS base URLs and API tokens. Connector URLs are operator-controlled environment settings, never caller-supplied API parameters. Permit only the required external hosts in the node's outbound firewall/DNS policy. The application rejects non-HTTPS URLs and private/link-local IP literals, disables redirects and enforces timeouts and response-size limits; network egress controls remain necessary to mitigate DNS rebinding and compromised DNS.

## API

All routes are under `/api/v1/threat-intel` and require a bearer token:

| Method | Route | Role | Purpose |
|---|---|---|---|
| GET | `/feeds` | admin, analyst | Connector configuration status; never returns secrets |
| POST | `/sync/nvd` | admin, analyst | Fetch a bounded NVD CVE page set |
| POST | `/sync/cisa-kev` | admin, analyst | Import CISA KEV catalog |
| POST | `/sync/misp` | admin, analyst | Import configured MISP attributes |
| POST | `/sync/opencti` | admin, analyst | Import configured OpenCTI indicators |
| GET | `/cves` | admin, analyst, viewer | List organization CVE intelligence; optional `known_exploited` filter |
| GET | `/iocs` | admin, analyst, viewer | List organization IOC records; optional `indicator_type` filter |
| GET | `/correlate?value=...` | admin, analyst, viewer | Exact-match lookup against locally ingested IOCs |
| GET | `/sync-history` | admin, analyst | View bounded ingestion history |

Use Swagger at `/docs` after starting the API. Sync is intentionally manual. Example sequence: check `/feeds`, run `/sync/cisa-kev`, run `/sync/nvd`, then review `/cves?known_exploited=true`. Configure and sync MISP/OpenCTI only after entering operator-approved connector credentials.

## Data handling and limitations

- CVE and IOC records are tenant/organization scoped; the API does not expose other organizations' records.
- NVD ingestion is bounded to at most 500 CVEs per run. It is not a complete historical NVD mirror and does not yet maintain a durable pagination cursor or incremental watermark.
- CISA KEV is a catalog snapshot; a KEV match does not establish that a given product/version is installed or exposed.
- MISP imports up to 1,000 `to_ids` attributes per run and normalizes only supported observable types. OpenCTI imports at most 100 indicators per run and accepts only the listed simple STIX patterns.
- Feed records are untrusted intelligence. Verify source, freshness, confidence, asset applicability and false-positive context before acting.
- No indicator triggers endpoint blocking, firewall changes, remote commands, exploitation or cross-border forwarding.
- The project still uses development `create_all()` schema initialization. Back up the database and use proper Alembic migrations before upgrading an existing production database. Review the Phase 1/2 production gaps in `PHASE_STATUS.md`.
