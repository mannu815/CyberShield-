import pytest
from app.global_grid.contracts import NormalizedEvent, detect
from app.global_grid.governance import ResponseProposal, ShareableIndicator

def event(i, kind="authentication_failure"):
    return NormalizedEvent.from_dict({"event_id":str(i),"tenant_id":"t1","node_id":"np-1","observed_at":"2026-11-05T10:00:00+00:00","source":"test-sensor","event_type":kind,"asset_ref":"idp-1"})

def test_auth_failure_burst_detected_at_threshold():
    assert detect([event(i) for i in range(5)])[0].rule_id == "AUTH_FAILURE_BURST"

def test_privilege_change_is_critical():
    result = detect([event(1, "privilege_change")])
    assert result[0].severity == "critical"

def test_event_requires_tenant_and_valid_severity():
    with pytest.raises(ValueError):
        NormalizedEvent.from_dict({"event_id":"1"})
    payload = {"event_id":"1","tenant_id":"t","node_id":"n","observed_at":"2026-11-05T10:00:00+00:00","source":"s","event_type":"x","severity":"catastrophic"}
    with pytest.raises(ValueError):
        NormalizedEvent.from_dict(payload)

def test_response_proposal_rejects_hackback():
    proposal = ResponseProposal("p1","t1","host-1","hack_back","suspected intrusion","none","2026-11-06T00:00:00+00:00")
    with pytest.raises(ValueError): proposal.validate()

def test_federation_requires_explicit_approval():
    indicator = ShareableIndicator("203.0.113.10","ipv4","local-soc",0.8,"2026-11-01T00:00:00Z","2026-11-10T00:00:00Z","TLP:GREEN",True,False)
    with pytest.raises(PermissionError): indicator.export()

def test_federation_export_minimizes_governance_fields():
    indicator = ShareableIndicator("203.0.113.10","ipv4","local-soc",0.8,"2026-11-01T00:00:00Z","2026-11-10T00:00:00Z","TLP:GREEN",True,True)
    result = indicator.export()
    assert "country_policy_approved" not in result["payload"]
    assert len(result["sha256"]) == 64
