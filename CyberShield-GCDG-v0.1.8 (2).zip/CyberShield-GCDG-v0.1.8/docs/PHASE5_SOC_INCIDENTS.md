# Phase 5 — SOC Dashboard & Incident Case Management

## Included
- Organization-scoped dashboard overview and event trend APIs.
- Incident cases with unique case numbers, severity, lifecycle status and analyst assignment.
- Link multiple detection alerts to one case; reject alert IDs outside the caller's organization.
- Analyst notes and an auditable case activity timeline.
- JSON and CSV incident exports (up to 1,000 cases per export).
- Role controls: authenticated users can view; admins and analysts can create/update cases and add notes. Assignees must be active users in the same organization.

## API routes
- `GET /api/v1/dashboard/overview`
- `GET /api/v1/dashboard/trends?days=7`
- `POST /api/v1/incidents/cases`
- `GET /api/v1/incidents/cases`
- `GET /api/v1/incidents/cases/{case_id}`
- `PATCH /api/v1/incidents/cases/{case_id}`
- `POST /api/v1/incidents/cases/{case_id}/notes`
- `GET /api/v1/incidents/cases/{case_id}/timeline`
- `GET /api/v1/incidents/export?format=json|csv`

## Example
```json
{
  "title": "Investigate suspicious network activity",
  "description": "Review the source host, affected assets and supporting telemetry.",
  "severity": "high",
  "alert_ids": [12, 13]
}
```

## Security and limitations
- All case, alert, event, assignee and note reads/writes are restricted to the authenticated user's organization.
- No automated containment, endpoint commands, blocking, or external notification is performed.
- Export is limited to 1,000 cases per request. Protect exported files as sensitive operational data.
- This release adds tables. `Base.metadata.create_all()` creates missing tables on a fresh database but does not safely migrate existing deployed schemas. Back up the DB and use Alembic migrations before production upgrade.
- Dashboard is API-first; it does not yet include a polished browser frontend, websocket streaming, SLA workflows, or PDF report generation.
