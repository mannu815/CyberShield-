@echo off
setlocal
cd /d "%~dp0"
set PYTHON_CMD=
where py >nul 2>nul
if not errorlevel 1 (
  set PYTHON_CMD=py -3
) else (
  where python >nul 2>nul
  if not errorlevel 1 (
    set PYTHON_CMD=python
  ) else (
    echo Python was not found. Install Python 3.11 or newer and add it to PATH.
    pause
    exit /b 1
  )
)

if not exist .venv\Scripts\python.exe %PYTHON_CMD% -m venv .venv
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
if errorlevel 1 goto failed
pip install -r requirements.txt
if errorlevel 1 goto failed
if not exist .env (
  python -c "import secrets; from cryptography.fernet import Fernet; jwt = secrets.token_urlsafe(48); fernet = Fernet.generate_key().decode(); tmpl = open('.env.example', 'r').read(); tmpl = tmpl.replace('REPLACE_WITH_AT_LEAST_32_RANDOM_BYTES', jwt).replace('replace_with_generated_fernet_key', fernet); open('.env', 'w').write(tmpl); print('Generated secure .env with unique JWT_SECRET and Fernet keys.')"
)
if not exist .env goto failed
echo.
echo Setup complete. Secure .env has been generated with unique cryptographic secrets.
echo Optional: configure NVD_API_KEY, MISP_URL/MISP_API_KEY and OPENCTI_URL/OPENCTI_TOKEN in .env.
echo Next: bootstrap the first administrator:
echo   python -m scripts.bootstrap_admin --organization "CyberShield Lab" --email "admin@cybershield.local" --name "National Admin"
echo Then run run_windows.bat to launch the Sovereign Command Hub.
pause
exit /b 0
:failed
echo Setup failed. Read the error above and retry.
pause
exit /b 1
