from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from slowapi import _rate_limit_exceeded_handler
from slowapi.errors import RateLimitExceeded
from app.core.rate_limit import limiter
from app.api import admin, auth, security, federation, threat_intel, detection, incidents, platform, sovereign
from app.core.config import settings
from app.db.session import Base, engine
from app.db import models  # noqa: F401 - registers ORM models

# Development convenience only. Production schema changes must be applied with Alembic.
if settings.app_env != "production":
    Base.metadata.create_all(bind=engine)
app = FastAPI(title=settings.app_name, version="0.1.8-national-soc-sovereign-admin", description="Defensive cyber operations, threat intelligence, detection and incident management MVP")
app.mount("/static", StaticFiles(directory=str(Path(__file__).parent / "static")), name="static")
app.state.limiter = limiter
app.add_exception_handler(RateLimitExceeded, _rate_limit_exceeded_handler)
app.include_router(auth.router, prefix="/api/v1")
app.include_router(admin.router, prefix="/api/v1")
app.include_router(security.router, prefix="/api/v1")
app.include_router(federation.router, prefix="/api/v1")
app.include_router(threat_intel.router, prefix="/api/v1")
app.include_router(detection.router, prefix="/api/v1")
app.include_router(incidents.router)
app.include_router(platform.router)
app.include_router(sovereign.router)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'; form-action 'self'; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; connect-src 'self'")
    if settings.app_env == "production":
        response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
    response.headers.setdefault("Cache-Control", "no-store" if request.url.path.startswith("/api/") else "no-cache")
    return response


@app.get("/national-soc", response_class=HTMLResponse, include_in_schema=False)
def national_soc_dashboard():
    return HTMLResponse((Path(__file__).parent / "static" / "national_soc.html").read_text(encoding="utf-8"))


@app.get("/sovereign-admin", response_class=HTMLResponse, include_in_schema=False)
def sovereign_admin_portal():
    return HTMLResponse((Path(__file__).parent / "static" / "sovereign_admin.html").read_text(encoding="utf-8"))


@app.get("/health", tags=["System"])
def health():
    return {"status": "ok", "product": "CyberShield AI", "version": "0.1.8-national-soc-sovereign-admin", "mode": "threat intelligence + defensive detection MVP"}


@app.get("/", tags=["System"], response_class=HTMLResponse)
def root(request: Request):
    accept = request.headers.get("accept", "")
    if "text/html" in accept or "*/*" in accept:
        index_file = Path(__file__).parent / "static" / "index.html"
        if index_file.exists():
            return HTMLResponse(index_file.read_text(encoding="utf-8"))
    return JSONResponse({"product": "CyberShield AI", "version": "0.1.8", "docs": "/docs", "health": "/health", "national_soc": "/national-soc", "sovereign_admin": "/sovereign-admin", "soc": "/soc"})


@app.get("/soc", response_class=HTMLResponse, include_in_schema=False)
def soc_dashboard():
    return HTMLResponse((Path(__file__).parent / "static" / "soc.html").read_text(encoding="utf-8"))
