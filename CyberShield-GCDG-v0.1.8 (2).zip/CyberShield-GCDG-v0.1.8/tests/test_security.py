from app.core.security import hash_password, verify_password, create_access_token, decode_access_token


def test_password_hash_is_not_plaintext_and_verifies():
    encoded = hash_password("CorrectHorseBatteryStaple!42")
    assert encoded != "CorrectHorseBatteryStaple!42"
    assert verify_password("CorrectHorseBatteryStaple!42", encoded)
    assert not verify_password("wrong-password", encoded)


def test_access_token_contains_tenant_and_role():
    token = create_access_token(7, 3, "analyst")
    claims = decode_access_token(token)
    assert claims["sub"] == "7"
    assert claims["org"] == 3
    assert claims["role"] == "analyst"
    assert claims["type"] == "access"
