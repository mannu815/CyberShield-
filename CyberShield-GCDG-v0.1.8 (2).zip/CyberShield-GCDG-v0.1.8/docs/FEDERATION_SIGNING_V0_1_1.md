# Federation signing core — v0.1.1

This increment adds a standard-library-only signed indicator envelope to `app/global_grid/signing.py`.

## Implemented
- Explicit policy approval gate before export.
- Per-peer HMAC-SHA256 integrity/authenticity check.
- Canonical JSON serialization and payload SHA-256 digest.
- Sender/recipient binding, schema version, 128-bit nonce, issue time and freshness window.
- Indicator type, confidence, timestamp, expiry, hash/CVE format and handling-label validation.
- No raw logs, credentials, packet captures, case notes or personal identity fields in the envelope schema.

## Not yet implemented
- This is not an HTTP federation API or a deployed peer network.
- The caller must atomically persist nonce values per sender to prevent replay; a database-backed replay store is a required next step.
- HMAC is a development bridge, not the final multi-party national PKI design. Production requires mutual TLS, per-peer secret vaulting/rotation or an approved asymmetric PKI profile, certificate revocation, key lifecycle procedures and independent review.
- `policy_approved=True` is a caller-supplied decision, not a substitute for a country policy engine, legal basis, signed approval record or audit trail.

## Tests
Run the isolated standard-library suite from the repository root:

```bash
python -m unittest tests.test_federation_signing -v
```

The complete FastAPI test suite still requires installing `requirements.txt`; this execution environment had no package-index network access, so dependency installation and the full suite could not be completed here.

## v0.1.2 persistent federation gateway additions

- Admin-only peer registration at `POST /api/v1/admin/federation/peers`; an explicit `policy_approved: true` is required. A generated HMAC secret is returned once and stored encrypted with Fernet; a second node can import the same secret using the `shared_secret` field.
- Admin peer inventory at `GET /api/v1/admin/federation/peers` (never returns secret material).
- Signed indicator ingestion at `POST /api/v1/federation/indicators/{sender_node}`. The receiver checks peer approval, sender/recipient binding, signature, payload digest, timestamp, indicator policy and expiry.
- Replay nonces and accepted indicators are persisted with database uniqueness constraints; repeated nonce or repeated sender+payload is rejected with HTTP 409.
- Authenticated indicator inventory at `GET /api/v1/federation/indicators`.

### Configuration and operating requirements

Set `GCDG_FEDERATION_NODE_ID` uniquely for each node. Generate `GCDG_FERNET_KEY` using `python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"` and protect it as a deployment secret. Never commit `.env`. Exchange the one-time peer HMAC secret over a separate secure channel and configure the corresponding peer record on both sides. The HMAC shared-secret design is an MVP bridge, not national-grade PKI. Put the federation API behind mutually authenticated TLS (mTLS), a restrictive network policy, and a reverse proxy that strips untrusted client-certificate headers. No automatic blocking, scanning, or remote response is performed by federation ingestion.

New tables are created by the current `create_all` startup mechanism. Before production rollout, create and review Alembic migrations; do not rely on `create_all` for schema evolution.

### Peer registration payload

Generate on the first node (secret returned once):

```json
{"node_id":"partner-node-02","display_name":"Partner National SOC","country_code":"XX","policy_approved":true}
```

On the paired node, register the reciprocal peer with the same secret over a secure out-of-band channel:

```json
{"node_id":"np-node-01","display_name":"Nepal Node","country_code":"NP","policy_approved":true,"shared_secret":"PASTE_THE_SECURELY_TRANSFERRED_SECRET"}
```

Use a real ISO 3166-1 alpha-2 country code in deployment. The `XX` value above is only a placeholder.
