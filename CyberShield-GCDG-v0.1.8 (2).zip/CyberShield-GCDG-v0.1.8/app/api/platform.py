from __future__ import annotations
import json, hashlib, hmac
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Request, Body
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import func
from app.db.session import get_db
from app.db.models import (User, Asset, AssetProfile, Assessment, Finding, DetectionEvent, DetectionAlert,
    IncidentCase, IncidentCaseAlert, IncidentCaseNote, IncidentCaseActivity, ThreatIntelIOC, AIInvestigation, ComplianceEvidence, GovernanceDecision,
    PeerNode, FederatedIndicator, AuditLog, AssetProfile, Assessment, Finding, ThreatIntelCVE, ThreatIntelSyncLog)
from app.dependencies import get_current_user, require_roles
from app.core.config import settings
from app.audit import write_audit

router=APIRouter(tags=["AI Analyst, Asset Risk, Assurance & Platform Operations"])

class InvestigationIn(BaseModel):
    include_ioc_correlation: bool = True

class AssetProfileIn(BaseModel):
    owner: str = Field(default="", max_length=160)
    criticality: str = Field(default="medium", pattern="^(critical|high|medium|low)$")
    environment: str = Field(default="production", pattern="^(production|staging|development|test)$")
    data_classification: str = Field(default="internal", pattern="^(public|internal|confidential|restricted)$")
    tags: list[str] = Field(default_factory=list, max_length=30)

class EvidenceIn(BaseModel):
    framework: str = Field(default="GCDG-Baseline", min_length=2, max_length=60)
    control_id: str = Field(min_length=2, max_length=80)
    title: str = Field(min_length=3, max_length=200)
    status: str = Field(default="not_assessed", pattern="^(not_assessed|implemented|partial|not_implemented|not_applicable)$")
    evidence_reference: str = Field(default="", max_length=500)
    notes: str = Field(default="", max_length=5000)

class GovernanceIn(BaseModel):
    policy_key: str = Field(min_length=3, max_length=100)
    decision: str = Field(pattern="^(approved|rejected|review_required)$")
    rationale: str = Field(min_length=5, max_length=3000)

SEVERITY_WEIGHT={"critical":40,"high":25,"medium":12,"low":5,"info":1}
CONTROL_CATALOG=[
 {"id":"GOV-01","title":"Defined security ownership and accountability","domain":"Governance"},
 {"id":"IAM-01","title":"Strong authentication and least privilege","domain":"Identity"},
 {"id":"AST-01","title":"Maintained and classified asset inventory","domain":"Asset Management"},
 {"id":"LOG-01","title":"Centralized security logging and time synchronization","domain":"Detection"},
 {"id":"IR-01","title":"Documented incident response and escalation process","domain":"Response"},
 {"id":"BCP-01","title":"Tested backups and recovery procedures","domain":"Resilience"},
 {"id":"SUP-01","title":"Third-party and supply-chain risk review","domain":"Supply Chain"},
 {"id":"PRV-01","title":"Data minimization, retention and access controls","domain":"Privacy"},
]

@router.post("/api/v1/analyst/cases/{case_id}/investigate",status_code=201)
def investigate_case(case_id:int,payload:InvestigationIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    case=db.query(IncidentCase).filter_by(id=case_id,organization_id=user.organization_id).first()
    if not case: raise HTTPException(404,"Incident case not found")
    links=db.query(IncidentCaseAlert).filter_by(case_id=case.id).all(); alert_ids=[x.alert_id for x in links]
    alerts=db.query(DetectionAlert).filter(DetectionAlert.organization_id==user.organization_id,DetectionAlert.id.in_(alert_ids)).all() if alert_ids else []
    event_ids=[a.event_id for a in alerts]
    events=db.query(DetectionEvent).filter(DetectionEvent.organization_id==user.organization_id,DetectionEvent.id.in_(event_ids)).all() if event_ids else []
    evidence=[]; recs=[]; matched_iocs=[]
    for a in alerts:
        evidence.append({"kind":"alert","id":a.id,"rule_id":a.rule_id,"title":a.title,"severity":a.severity,"status":a.status,"source_ip":a.src_ip})
        recs.append({"priority":"high" if a.severity in {"critical","high"} else "normal","action":"Validate alert evidence and affected asset scope","reason":f"Alert {a.id}: {a.title}","requires_human_approval":True})
    for e in events:
        evidence.append({"kind":"event","id":e.id,"source":e.source,"event_type":e.source_event_type,"severity":e.severity,"src_ip":e.src_ip,"dst_ip":e.dst_ip,"message":e.message[:500]})
        if payload.include_ioc_correlation:
            candidates={x for x in (e.src_ip,e.dst_ip) if x}
            if candidates:
                found=db.query(ThreatIntelIOC).filter(ThreatIntelIOC.organization_id==user.organization_id,ThreatIntelIOC.value.in_(list(candidates))).all()
                for ioc in found:
                    matched_iocs.append({"id":ioc.id,"value":ioc.value,"type":ioc.indicator_type,"source":ioc.source,"confidence":ioc.confidence,"label":ioc.threat_label})
    if matched_iocs:
        evidence.extend([{"kind":"threat_intel_ioc",**x} for x in matched_iocs])
        recs.insert(0,{"priority":"high","action":"Escalate for analyst validation of IOC match","reason":f"{len(matched_iocs)} exact-match IOC(s) found in local organization intelligence","requires_human_approval":True})
    if not alerts and not events:
        recs.append({"priority":"normal","action":"Collect supporting telemetry and link relevant alerts","reason":"No linked detection alerts or events were found for this case","requires_human_approval":True})
    maxsev=max((SEVERITY_WEIGHT.get(a.severity,1) for a in alerts),default=5)
    confidence=min(95,35+len(alerts)*10+len(events)*5+len(matched_iocs)*15)
    summary=f"Evidence review for {case.case_number}: {len(alerts)} linked alert(s), {len(events)} event(s), and {len(matched_iocs)} exact-match IOC(s). This is deterministic decision support, not an autonomous AI verdict."
    row=AIInvestigation(organization_id=user.organization_id,case_id=case.id,analyst_user_id=user.id,confidence=confidence,summary=summary,evidence=evidence,recommendations=recs)
    db.add(row); db.commit(); db.refresh(row)
    write_audit(db,request,"analyst.investigation.create","success",user,f"investigation:{row.id}",{"case_id":case.id,"evidence_count":len(evidence)})
    return {"id":row.id,"case_id":case.id,"engine":row.engine,"confidence":confidence,"summary":summary,"evidence":evidence,"recommendations":recs,"decision":"human_review_required"}

@router.get("/api/v1/analyst/investigations")
def list_investigations(limit:int=100,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    limit=max(1,min(limit,200)); rows=db.query(AIInvestigation).filter_by(organization_id=user.organization_id).order_by(AIInvestigation.id.desc()).limit(limit).all()
    return [{"id":r.id,"case_id":r.case_id,"engine":r.engine,"confidence":r.confidence,"summary":r.summary,"created_at":r.created_at} for r in rows]

@router.put("/api/v1/platform/assets/{asset_id}/profile")
def upsert_asset_profile(asset_id:int,payload:AssetProfileIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    asset=db.query(Asset).filter_by(id=asset_id,organization_id=user.organization_id).first()
    if not asset: raise HTTPException(404,"Asset not found")
    row=db.query(AssetProfile).filter_by(asset_id=asset.id).first()
    if not row: row=AssetProfile(asset_id=asset.id); db.add(row)
    for k,v in payload.model_dump().items(): setattr(row,k,v)
    db.commit(); db.refresh(row); write_audit(db,request,"asset.profile.update","success",user,f"asset:{asset.id}")
    return {"asset_id":asset.id,**payload.model_dump(),"updated_at":row.updated_at}

@router.get("/api/v1/platform/assets")
def platform_assets(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    rows=db.query(Asset).filter_by(organization_id=user.organization_id).order_by(Asset.id.desc()).all(); result=[]
    for a in rows:
        p=db.query(AssetProfile).filter_by(asset_id=a.id).first()
        result.append({"id":a.id,"name":a.name,"target":a.canonical_target,"asset_type":a.asset_type,"active":a.active,"profile":({"owner":p.owner,"criticality":p.criticality,"environment":p.environment,"data_classification":p.data_classification,"tags":p.tags} if p else None)})
    return result

@router.get("/api/v1/platform/assets/{asset_id}/risk")
def asset_risk(asset_id:int,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    a=db.query(Asset).filter_by(id=asset_id,organization_id=user.organization_id).first()
    if not a: raise HTTPException(404,"Asset not found")
    profile=db.query(AssetProfile).filter_by(asset_id=a.id).first(); base={"critical":40,"high":30,"medium":20,"low":10}.get(profile.criticality if profile else "medium",20)
    findings=db.query(Finding).join(Assessment,Finding.assessment_id==Assessment.id).filter(Assessment.asset_id==a.id,Finding.organization_id==user.organization_id).all()
    score=min(100,base+sum(SEVERITY_WEIGHT.get(f.severity,1) for f in findings if f.status not in {"resolved","false_positive"}))
    return {"asset_id":a.id,"asset_name":a.name,"risk_score":score,"risk_band":"critical" if score>=80 else "high" if score>=60 else "medium" if score>=35 else "low","criticality":profile.criticality if profile else "medium","open_findings":len([f for f in findings if f.status not in {"resolved","false_positive"}]),"method":"transparent weighted heuristic; not a validated probability"}

@router.get("/api/v1/assurance/catalog")
def assurance_catalog(): return {"framework":"GCDG-Baseline","notice":"Operational starter checklist; not a certification or a substitute for official framework text.","controls":CONTROL_CATALOG}

@router.post("/api/v1/assurance/evidence",status_code=201)
def add_evidence(payload:EvidenceIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    row=ComplianceEvidence(organization_id=user.organization_id,owner_user_id=user.id,**payload.model_dump()); db.add(row); db.commit(); db.refresh(row)
    write_audit(db,request,"assurance.evidence.create","success",user,f"evidence:{row.id}")
    return {"id":row.id,"framework":row.framework,"control_id":row.control_id,"title":row.title,"status":row.status,"evidence_reference":row.evidence_reference,"notes":row.notes,"created_at":row.created_at}

@router.get("/api/v1/assurance/evidence")
def list_evidence(framework:str|None=None,db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    q=db.query(ComplianceEvidence).filter_by(organization_id=user.organization_id)
    if framework: q=q.filter_by(framework=framework[:60])
    rows=q.order_by(ComplianceEvidence.updated_at.desc()).limit(500).all()
    return [{"id":r.id,"framework":r.framework,"control_id":r.control_id,"title":r.title,"status":r.status,"evidence_reference":r.evidence_reference,"notes":r.notes,"owner_user_id":r.owner_user_id,"review_due":r.review_due,"updated_at":r.updated_at} for r in rows]

@router.get("/api/v1/assurance/summary")
def assurance_summary(db:Session=Depends(get_db),user:User=Depends(get_current_user)):
    rows=db.query(ComplianceEvidence).filter_by(organization_id=user.organization_id).all(); counts={s:sum(1 for r in rows if r.status==s) for s in ("implemented","partial","not_implemented","not_assessed","not_applicable")}
    implemented_controls={r.control_id for r in rows if r.status=="implemented" and r.control_id in {c["id"] for c in CONTROL_CATALOG}}
    return {"framework":"GCDG-Baseline","catalog_controls":len(CONTROL_CATALOG),"evidence_records":len(rows),"status_counts":counts,"implemented_catalog_controls":len(implemented_controls),"coverage_percent":round(100*len(implemented_controls)/max(1,len(CONTROL_CATALOG)),1),"warning":"Evidence-record coverage is not an audit opinion or compliance certification."}

@router.post("/api/v1/governance/decisions",status_code=201)
def governance_decision(payload:GovernanceIn,request:Request,db:Session=Depends(get_db),user:User=Depends(require_roles("admin"))):
    row=GovernanceDecision(organization_id=user.organization_id,actor_user_id=user.id,**payload.model_dump()); db.add(row); db.commit(); db.refresh(row)
    write_audit(db,request,"governance.decision.create","success",user,f"decision:{row.id}")
    return {"id":row.id,"policy_key":row.policy_key,"decision":row.decision,"rationale":row.rationale,"created_at":row.created_at}

@router.get("/api/v1/governance/decisions")
def list_governance_decisions(db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    rows=db.query(GovernanceDecision).filter_by(organization_id=user.organization_id).order_by(GovernanceDecision.id.desc()).limit(200).all()
    return [{"id":r.id,"policy_key":r.policy_key,"decision":r.decision,"rationale":r.rationale,"actor_user_id":r.actor_user_id,"created_at":r.created_at} for r in rows]

@router.get("/api/v1/governance/federation-peers")
def governance_peers(db:Session=Depends(get_db),user:User=Depends(require_roles("admin","analyst"))):
    rows=db.query(PeerNode).order_by(PeerNode.id.desc()).all()
    return [{"node_id":r.node_id,"display_name":r.display_name,"country_code":r.country_code,"enabled":r.enabled,"policy_approved":r.policy_approved,"created_at":r.created_at} for r in rows]

@router.get("/api/v1/ops/readiness")
def ops_readiness(db:Session=Depends(get_db),user:User=Depends(require_roles("admin"))):
    checks=[{"name":"JWT secret configured","ok":len(settings.jwt_secret)>=32},{"name":"Production environment","ok":settings.app_env=="production"},{"name":"PostgreSQL configured","ok":settings.database_url.startswith("postgresql")},{"name":"Federation encryption key configured","ok":bool(settings.federation_fernet_key)},{"name":"MISP credentials configured","ok":bool(settings.misp_url and settings.misp_api_key)},{"name":"OpenCTI credentials configured","ok":bool(settings.opencti_url and settings.opencti_token)}]
    return {"checks":checks,"passed":sum(1 for c in checks if c["ok"]),"total":len(checks),"production_ready":all(c["ok"] for c in checks),"warning":"This is a configuration checklist, not a penetration test, HA validation or security certification."}

@router.get("/api/v1/ops/backup/export")
def backup_export(db:Session=Depends(get_db),user:User=Depends(require_roles("admin"))):
    org=user.organization_id
    def rows(model, query):
        out=[]
        for obj in query.all():
            item={c.name:getattr(obj,c.name) for c in model.__table__.columns if c.name not in {"password_hash","shared_secret_ciphertext","key_hash"}}
            out.append({k:(v.isoformat() if isinstance(v,datetime) else v) for k,v in item.items()})
        return out
    payload={"format":"cybershield-org-backup-v2","organization_id":org,"created_at":datetime.now(timezone.utc).isoformat(),"scope":"organization operational data; credentials and federation secrets excluded; restore not supported by this endpoint","data":{
        "assets":rows(Asset,db.query(Asset).filter_by(organization_id=org)),
        "asset_profiles":rows(AssetProfile,db.query(AssetProfile).join(Asset,AssetProfile.asset_id==Asset.id).filter(Asset.organization_id==org)),
        "assessments":rows(Assessment,db.query(Assessment).filter_by(organization_id=org)),
        "findings":rows(Finding,db.query(Finding).filter_by(organization_id=org)),
        "detection_events":rows(DetectionEvent,db.query(DetectionEvent).filter_by(organization_id=org)),
        "detection_alerts":rows(DetectionAlert,db.query(DetectionAlert).filter_by(organization_id=org)),
        "incident_cases":rows(IncidentCase,db.query(IncidentCase).filter_by(organization_id=org)),
        "incident_case_notes":rows(IncidentCaseNote,db.query(IncidentCaseNote).filter_by(organization_id=org)),
        "incident_case_activities":rows(IncidentCaseActivity,db.query(IncidentCaseActivity).filter_by(organization_id=org)),
        "ai_investigations":rows(AIInvestigation,db.query(AIInvestigation).filter_by(organization_id=org)),
        "threat_intel_iocs":rows(ThreatIntelIOC,db.query(ThreatIntelIOC).filter_by(organization_id=org)),
        "threat_intel_cves":rows(ThreatIntelCVE,db.query(ThreatIntelCVE).filter_by(organization_id=org)),
        "threat_intel_sync_logs":rows(ThreatIntelSyncLog,db.query(ThreatIntelSyncLog).filter_by(organization_id=org)),
        "compliance_evidence":rows(ComplianceEvidence,db.query(ComplianceEvidence).filter_by(organization_id=org)),
        "governance_decisions":rows(GovernanceDecision,db.query(GovernanceDecision).filter_by(organization_id=org)),
        "audit_logs":rows(AuditLog,db.query(AuditLog).filter_by(organization_id=org))}}
    payload["sha256"]=hashlib.sha256(json.dumps(payload,sort_keys=True,default=str).encode()).hexdigest()
    write_audit(db,None,"ops.backup.export","success",user,"organization",{"tables":len(payload["data"])})
    return JSONResponse(payload,headers={"Content-Disposition":"attachment; filename=cybershield-org-backup.json"})

@router.post("/api/v1/ops/backup/validate")
def backup_validate(payload:dict=Body(...),user:User=Depends(require_roles("admin"))):
    raw=json.dumps(payload,default=str).encode()
    if len(raw)>10_000_000: raise HTTPException(413,"Backup exceeds 10 MB validation limit")
    if payload.get("format")!="cybershield-org-backup-v2" or not isinstance(payload.get("data"),dict): raise HTTPException(400,"Unsupported backup format")
    if payload.get("organization_id")!=user.organization_id: raise HTTPException(403,"Backup belongs to another organization")
    required={"assets","asset_profiles","assessments","findings","detection_events","detection_alerts","incident_cases","incident_case_notes","incident_case_activities","ai_investigations","threat_intel_iocs","threat_intel_cves","threat_intel_sync_logs","compliance_evidence","governance_decisions","audit_logs"}
    if not required.issubset(payload["data"]): raise HTTPException(400,"Backup is missing required datasets")
    counts={k:(len(v) if isinstance(v,list) else -1) for k,v in payload["data"].items()}
    if any(v<0 for v in counts.values()): raise HTTPException(400,"Every dataset must be an array")
    supplied=payload.get("sha256","")
    unsigned={k:v for k,v in payload.items() if k!="sha256"}
    expected=hashlib.sha256(json.dumps(unsigned,sort_keys=True,default=str).encode()).hexdigest()
    if not supplied or not hmac.compare_digest(str(supplied),expected): raise HTTPException(400,"Backup checksum is missing or invalid")
    return {"valid":True,"checksum_verified":True,"dataset_counts":counts,"mode":"dry_run_only","restored":False,"note":"Validation never writes to the database. Perform restore only through a separately reviewed offline migration procedure."}
