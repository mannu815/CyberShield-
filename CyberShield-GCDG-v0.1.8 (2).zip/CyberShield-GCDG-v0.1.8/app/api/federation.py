from datetime import datetime, timedelta, timezone
from hashlib import sha256
from fastapi import APIRouter, Depends, HTTPException, Request, Query
from cryptography.fernet import Fernet, InvalidToken
from sqlalchemy import delete
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import Session
from app.core.config import settings
from app.db.models import FederatedIndicator, FederationReplayNonce, PeerNode
from app.db.session import get_db
from app.dependencies import require_roles
from app.core.rate_limit import limiter
from app.db.models import User
from app.global_grid.signing import verify_envelope, canonical_json

router = APIRouter(prefix="/federation", tags=["Sovereign Federation"] )

@router.post("/indicators/{sender_node}", status_code=202)
@limiter.limit(settings.rate_limit_default)
def receive_indicator(sender_node: str, envelope: dict, request: Request, db: Session = Depends(get_db)):
    """Receive approved, signed IOC data. Protect this route with mTLS at the reverse proxy."""
    if len(sender_node) > 128 or not sender_node.replace("-", "").replace("_", "").isalnum():
        raise HTTPException(status_code=422, detail="Invalid sender node identifier")
    try:
        content_length = int(request.headers.get("content-length", "0") or 0)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid Content-Length header")
    if content_length > 262144:
        raise HTTPException(status_code=413, detail="Federation envelope exceeds 256 KB")
    if not isinstance(envelope, dict) or len(envelope) > 12:
        raise HTTPException(status_code=422, detail="Invalid federation envelope")
    if not settings.federation_fernet_key:
        raise HTTPException(status_code=503, detail="Federation key encryption is not configured")
    peer = db.query(PeerNode).filter(PeerNode.node_id == sender_node, PeerNode.enabled.is_(True), PeerNode.policy_approved.is_(True)).first()
    if not peer:
        raise HTTPException(status_code=403, detail="Sender is not an enabled, policy-approved peer")
    try:
        key = Fernet(settings.federation_fernet_key.encode()).decrypt(peer.shared_secret_ciphertext.encode())
        indicator = verify_envelope(envelope, expected_sender=sender_node, expected_recipient=settings.federation_node_id, peer_secret=key)
    except (InvalidToken, ValueError, PermissionError, TypeError):
        raise HTTPException(status_code=400, detail="Federation package rejected by signature, routing, freshness or policy validation")
    nonce = envelope["nonce"]
    digest = sha256(canonical_json(envelope["payload"])).hexdigest()
    expires = datetime.now(timezone.utc) + timedelta(minutes=10)
    try:
        # Remove expired replay records so the replay-protection table remains bounded.
        db.execute(delete(FederationReplayNonce).where(FederationReplayNonce.expires_at < datetime.now(timezone.utc)))
        db.add(FederationReplayNonce(sender_node=sender_node, nonce=nonce, expires_at=expires))
        db.add(FederatedIndicator(sender_node=sender_node, value=indicator.value, indicator_type=indicator.indicator_type,
                                  confidence=str(indicator.confidence), handling=indicator.handling, payload_sha256=digest, payload=envelope["payload"]))
        db.commit()
    except IntegrityError:
        db.rollback()
        raise HTTPException(status_code=409, detail="Replay detected or indicator already received")
    return {"status": "accepted", "sender_node": sender_node, "indicator_type": indicator.indicator_type,
            "payload_sha256": digest, "stored": True, "response_action": "none"}

@router.get("/indicators")
def list_received_indicators(limit: int = Query(100, ge=1, le=200), db: Session = Depends(get_db), user: User = Depends(require_roles("admin"))):
    # Only explicitly public/clear intelligence is exposed through this shared-node view.
    rows = db.query(FederatedIndicator).filter(FederatedIndicator.handling.in_(["TLP:CLEAR", "WHITE"])).order_by(FederatedIndicator.received_at.desc()).limit(limit).all()
    return [{"id": r.id, "sender_node": r.sender_node, "value": r.value, "indicator_type": r.indicator_type,
             "confidence": r.confidence, "handling": r.handling, "payload": r.payload, "received_at": r.received_at}
            for r in rows]
