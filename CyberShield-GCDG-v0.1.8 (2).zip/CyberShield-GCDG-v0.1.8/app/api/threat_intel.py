from datetime import datetime, timezone
from fastapi import APIRouter, Depends, HTTPException, Query, Request
from sqlalchemy.orm import Session
from app.audit import write_audit
from app.core.rate_limit import limiter
from app.core.config import settings
from app.db.models import ThreatIntelCVE, ThreatIntelIOC, ThreatIntelSyncLog, User
from app.db.session import get_db
from app.dependencies import require_roles
from app.threat_intel import connectors

router = APIRouter(prefix="/threat-intel", tags=["Threat Intelligence"])

@router.get("/feeds")
def feed_status(user: User = Depends(require_roles("admin", "analyst"))):
    return {
        "nvd": {"configured": True, "authentication": "api_key_optional", "endpoint": "NVD CVE API 2.0"},
        "cisa_kev": {"configured": True, "authentication": "public_feed", "endpoint": "CISA KEV JSON"},
        "misp": {"configured": bool(settings.misp_url and settings.misp_api_key), "endpoint_configured": bool(settings.misp_url), "token_configured": bool(settings.misp_api_key)},
        "opencti": {"configured": bool(settings.opencti_url and settings.opencti_token), "endpoint_configured": bool(settings.opencti_url), "token_configured": bool(settings.opencti_token)},
        "policy": "manual administrator/analyst initiated ingestion; no automatic blocking or response",
    }


def _sync_cves(source: str, fetcher, request: Request, db: Session, user: User):
    log = ThreatIntelSyncLog(organization_id=user.organization_id, source=source, status="running")
    db.add(log); db.commit(); db.refresh(log)
    try:
        records = fetcher()
        created = updated = 0
        for item in records:
            cve_id = item["cve_id"]
            row = db.query(ThreatIntelCVE).filter(ThreatIntelCVE.organization_id == user.organization_id, ThreatIntelCVE.cve_id == cve_id).first()
            metadata = item.get("metadata", {}) if isinstance(item.get("metadata", {}), dict) else {}
            published = connectors._parse_date(metadata.get("published") or metadata.get("dateAdded"))
            source_updated = connectors._parse_date(metadata.get("lastModified"))
            if row is None:
                row = ThreatIntelCVE(organization_id=user.organization_id, cve_id=cve_id, sources=[source], summary=item.get("summary", ""),
                    severity=item.get("severity", "unknown"), cvss_score=str(item.get("cvss_score", "")),
                    known_exploited=bool(item.get("known_exploited", False)), references=item.get("references", []),
                    source_metadata={source: metadata}, published_at=published, source_updated_at=source_updated)
                db.add(row); created += 1
            else:
                # KEV is authoritative for exploited-in-the-wild status; NVD contributes CVSS and description.
                row.sources = sorted(set((row.sources or []) + [source]))
                if item.get("summary"): row.summary = item["summary"][:4000]
                if item.get("severity") and item["severity"] != "unknown": row.severity = item["severity"][:20]
                if item.get("cvss_score"): row.cvss_score = str(item["cvss_score"])[:10]
                row.known_exploited = row.known_exploited or bool(item.get("known_exploited", False))
                row.references = list(dict.fromkeys((row.references or []) + (item.get("references") or [])))[:50]
                row.source_metadata = {**(row.source_metadata or {}), source: metadata}
                row.published_at = row.published_at or published
                row.source_updated_at = source_updated or row.source_updated_at
                row.updated_at = datetime.now(timezone.utc)
                updated += 1
        log.status = "success"; log.records_seen = len(records); log.records_created = created; log.records_updated = updated
        log.completed_at = datetime.now(timezone.utc); db.commit()
        write_audit(db, request, f"threat_intel.sync.{source}", "success", user=user, resource=f"feed:{source}",
                    details={"seen": len(records), "created": created, "updated": updated})
        return {"status": "success", "source": source, "records_seen": len(records), "created": created, "updated": updated}
    except connectors.FeedError as exc:
        db.rollback(); log = db.query(ThreatIntelSyncLog).filter(ThreatIntelSyncLog.id == log.id).first()
        if log:
            log.status = "failed"; log.error_summary = str(exc)[:500]; log.completed_at = datetime.now(timezone.utc); db.commit()
        write_audit(db, request, f"threat_intel.sync.{source}", "failed", user=user, resource=f"feed:{source}", details={"error_type": type(exc).__name__})
        raise HTTPException(status_code=502, detail=f"{source} feed sync failed: {str(exc)[:180]}")
    except Exception:
        db.rollback()
        raise

@router.post("/sync/nvd")
@limiter.limit("10/hour")
def sync_nvd(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst"))):
    return _sync_cves("nvd", connectors.fetch_nvd, request, db, user)

@router.post("/sync/cisa-kev")
@limiter.limit("10/hour")
def sync_kev(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst"))):
    return _sync_cves("cisa_kev", connectors.fetch_kev, request, db, user)


def _store_iocs(source: str, records: list[dict], request: Request, db: Session, user: User):
    created = updated = 0
    for item in records[:2000]:
        value = str(item.get("value", "")).strip()
        kind = str(item.get("indicator_type", ""))
        if not value or len(value) > 2048 or kind not in {"ip", "domain", "url", "md5", "sha1", "sha256", "email"}:
            continue
        row = db.query(ThreatIntelIOC).filter_by(organization_id=user.organization_id, source=source, indicator_type=kind, value=value).first()
        try:
            confidence = max(0, min(100, int(item.get("confidence", 50))))
        except (ValueError, TypeError):
            confidence = 50
        if row is None:
            row = ThreatIntelIOC(organization_id=user.organization_id, source=source, indicator_type=kind, value=value,
                confidence=confidence, threat_label=str(item.get("threat_label", ""))[:160],
                description=str(item.get("description", ""))[:2000], tags=item.get("tags", [])[:30], references=item.get("references", [])[:30],
                raw_metadata=item.get("raw_metadata", {}))
            db.add(row); created += 1
        else:
            row.confidence = max(row.confidence, confidence)
            row.threat_label = str(item.get("threat_label", row.threat_label))[:160]
            row.description = str(item.get("description", row.description))[:2000]
            row.raw_metadata = item.get("raw_metadata", row.raw_metadata)
            updated += 1
    log = ThreatIntelSyncLog(organization_id=user.organization_id, source=source, status="success", records_seen=len(records),
                             records_created=created, records_updated=updated, completed_at=datetime.now(timezone.utc))
    db.add(log); db.commit()
    write_audit(db, request, f"threat_intel.sync.{source}", "success", user=user, resource=f"feed:{source}",
                details={"seen": len(records), "created": created, "updated": updated})
    return {"status": "success", "source": source, "records_seen": len(records), "created": created, "updated": updated}

def _sync_iocs(source: str, fetcher, request: Request, db: Session, user: User):
    try: return _store_iocs(source, fetcher(), request, db, user)
    except connectors.FeedError as exc:
        db.add(ThreatIntelSyncLog(organization_id=user.organization_id, source=source, status="failed",
                                  error_summary=str(exc)[:500], completed_at=datetime.now(timezone.utc)))
        db.commit()
        write_audit(db, request, f"threat_intel.sync.{source}", "failed", user=user, resource=f"feed:{source}", details={"error_type": type(exc).__name__})
        raise HTTPException(status_code=502, detail=f"{source} feed sync failed: {str(exc)[:180]}")

@router.post("/sync/misp")
@limiter.limit("10/hour")
def sync_misp(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst"))):
    return _sync_iocs("misp", connectors.fetch_misp, request, db, user)

@router.post("/sync/opencti")
@limiter.limit("10/hour")
def sync_opencti(request: Request, db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst"))):
    return _sync_iocs("opencti", connectors.fetch_opencti, request, db, user)

@router.get("/cves")
def list_cves(known_exploited: bool | None = None, limit: int = Query(100, ge=1, le=200), db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst", "viewer"))):
    q = db.query(ThreatIntelCVE).filter(ThreatIntelCVE.organization_id == user.organization_id)
    if known_exploited is not None: q = q.filter(ThreatIntelCVE.known_exploited.is_(known_exploited))
    return [{"cve_id": r.cve_id, "sources": r.sources, "summary": r.summary, "severity": r.severity, "cvss_score": r.cvss_score,
             "known_exploited": r.known_exploited, "references": r.references, "source_metadata": r.source_metadata,
             "published_at": r.published_at, "source_updated_at": r.source_updated_at, "updated_at": r.updated_at}
            for r in q.order_by(ThreatIntelCVE.updated_at.desc()).limit(limit).all()]

@router.get("/iocs")
def list_iocs(indicator_type: str | None = None, limit: int = Query(100, ge=1, le=200), db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst", "viewer"))):
    q = db.query(ThreatIntelIOC).filter(ThreatIntelIOC.organization_id == user.organization_id)
    if indicator_type: q = q.filter(ThreatIntelIOC.indicator_type == indicator_type)
    rows = q.order_by(ThreatIntelIOC.updated_at.desc()).limit(limit).all()
    return [{"id": r.id, "source": r.source, "indicator_type": r.indicator_type, "value": r.value, "confidence": r.confidence,
             "threat_label": r.threat_label, "description": r.description, "tags": r.tags, "references": r.references,
             "updated_at": r.updated_at} for r in rows]

@router.get("/correlate")
def correlate_indicator(value: str = Query(..., min_length=1, max_length=2048), db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst", "viewer"))):
    rows = db.query(ThreatIntelIOC).filter(ThreatIntelIOC.organization_id == user.organization_id, ThreatIntelIOC.value == value.strip()).limit(50).all()
    return {"indicator": value.strip(), "match_count": len(rows), "matches": [{"source": r.source, "type": r.indicator_type,
            "confidence": r.confidence, "label": r.threat_label, "updated_at": r.updated_at} for r in rows],
            "response_action": "none", "note": "Correlation only; verify context before taking defensive action."}

@router.get("/sync-history")
def sync_history(limit: int = Query(30, ge=1, le=100), db: Session = Depends(get_db), user: User = Depends(require_roles("admin", "analyst"))):
    rows = db.query(ThreatIntelSyncLog).filter(ThreatIntelSyncLog.organization_id == user.organization_id).order_by(ThreatIntelSyncLog.id.desc()).limit(limit).all()
    return [{"id": r.id, "source": r.source, "status": r.status, "records_seen": r.records_seen, "created": r.records_created,
             "updated": r.records_updated, "error": r.error_summary, "started_at": r.started_at, "completed_at": r.completed_at} for r in rows]
