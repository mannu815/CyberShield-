import os
import pytest

# Ensure testing defaults are always present regardless of local shell environment
os.environ.setdefault("APP_ENV", "test")
os.environ.setdefault("JWT_SECRET", "test_jwt_secret_must_be_at_least_32_bytes_long_for_security_checks_12345")
os.environ.setdefault("GCDG_FERNET_KEY", "4J3gvzvB6Ki0ER6LR0HzBsqsVlkFyZPwceeglkQhjBY=")
os.environ.setdefault("FEDERATION_FERNET_KEY", "4J3gvzvB6Ki0ER6LR0HzBsqsVlkFyZPwceeglkQhjBY=")
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")
