# Detection benchmark protocol

Do not publish performance percentages until you have a labelled, versioned dataset and repeatable runs. Each test case should record: test ID, fixture, expected rule IDs, actual rule IDs, scanner version, and evidence. Keep training/development fixtures separate from held-out evaluation fixtures.

For binary classification per rule, report TP, FP, FN, precision, recall and F1. Include confidence intervals for small samples. Report false-positive rate separately. Do not use the AI model to label its own ground truth. Human-review labels should be double-checked for disagreements.

This MVP currently has only unit-level rule fixtures. It does not yet have a representative benchmark corpus, so no detection-accuracy claims are made.
