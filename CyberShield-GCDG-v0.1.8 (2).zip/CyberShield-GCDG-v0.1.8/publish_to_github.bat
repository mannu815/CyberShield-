@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo   CyberShield GCDG - GitHub One-Click Publishing Tool
echo ========================================================
echo.
echo This tool directly creates and pushes the CyberShield codebase
echo to your GitHub account using the secure GitHub REST/Git Data API.
echo No external Git installation or administrator rights required.
echo.
if "%GITHUB_TOKEN%"=="" (
  echo If you do not have a token yet, generate one at:
  echo   https://github.com/settings/tokens/new (select 'repo' scope)
  echo.
)
python scripts\publish_to_github.py %*
if errorlevel 1 (
  echo.
  echo [!] Publishing failed. Check the error message above.
  pause
  exit /b 1
)
echo.
pause
exit /b 0
