# National SOC and Sovereign Admin Portal (v0.1.8)

## Portals
- `/national-soc`: organization-scoped SOC console. Uses the existing bearer-token login, `/dashboard/overview`, `/detection/alerts`, `/detection/events`, `/incidents/cases`, `/detection/summary`, `/assurance/summary`, and authenticated incident CSV export. Analysts/admins can work cases through the existing incident APIs and alerts through existing detection APIs. Viewer role is read-only.
- `/sovereign-admin`: global federation governance console. Requires the distinct `platform_admin` role and calls `/api/v1/sovereign/overview`, `/peers`, `/audit`, and `/peers/{id}/decision`.

## Provisioning a sovereign administrator
1. Create a normal, verified account using the trusted local bootstrap process.
2. On the trusted application host, run `python scripts/provision_platform_admin.py` from the project root.
3. Verify the target email and type the exact confirmation phrases. This is a local operator action; no tenant-facing API can elevate roles.
4. Sign out and sign back in so the account receives a token with the new role.
5. Open `/sovereign-admin`.

Do not give `platform_admin` to ordinary national SOC staff. Protect the host, database, backups and operator account with MFA at the deployment/identity-provider layer before any real sovereign deployment.

## Trust decision process
A tenant admin may submit a disabled peer registration request through the existing admin API. Only a `platform_admin` can approve, reject or suspend a peer. Approval requires a documented rationale and is audit logged. Verify sovereign authority, node identity, bilateral agreement, cryptographic key exchange and handling policy out-of-band before approval. This portal does not implement legal recognition, PKI issuance, external identity proofing or a production federation trust ceremony.

## Data sovereignty
National SOC endpoints remain organization scoped. Sovereign overview exposes aggregate counts and global peer governance metadata only; it does not expose national event bodies, incident narratives, IOC values or raw telemetry. A real deployment should use separate sovereign databases/keys and a formally approved data-sharing contract.

## Limitations
This is an engineering MVP, not a certified National SOC, government service or production-ready multi-country control plane. UI data is live only where the connected API has records; no simulated telemetry is inserted. Browser token storage is session-scoped, but a production deployment should move to an OIDC provider with MFA and secure, HttpOnly cookie sessions, strong CSP nonces, dedicated platform-admin identity store, immutable remote audit storage, and independent security review.
