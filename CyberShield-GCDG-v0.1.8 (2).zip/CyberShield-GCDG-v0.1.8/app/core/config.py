from functools import lru_cache
from pydantic import AliasChoices, Field, field_validator, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    app_env: str = "development"
    app_name: str = "CyberShield AI"
    database_url: str = "sqlite:///./cybershield_phase1.db"
    jwt_secret: str = Field(min_length=32)
    jwt_algorithm: str = "HS256"
    access_token_minutes: int = 20
    jwt_issuer: str = "cybershield-ai"
    federation_node_id: str = Field(default="local-node", validation_alias=AliasChoices("gcdg_federation_node_id", "federation_node_id"))
    federation_fernet_key: str = Field(default="", validation_alias=AliasChoices("gcdg_fernet_key", "federation_fernet_key"))
    jwt_audience: str = "cybershield-api"
    rate_limit_auth: str = "5/minute"
    rate_limit_default: str = "60/minute"

    # Threat-intelligence connectors. Endpoints are fixed/configured by operators, never supplied by API callers.
    nvd_api_key: str = ""
    threat_intel_timeout_seconds: int = 15
    threat_intel_max_response_bytes: int = 8_000_000
    misp_url: str = ""
    misp_api_key: str = ""
    opencti_url: str = ""
    opencti_token: str = ""

    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    @field_validator("jwt_algorithm")
    @classmethod
    def only_hs256_for_this_mvp(cls, value: str) -> str:
        if value != "HS256":
            raise ValueError("This MVP supports HS256 only; use a managed asymmetric key design before multi-service production.")
        return value

    @field_validator("app_env")
    @classmethod
    def valid_env(cls, value: str) -> str:
        if value not in {"development", "test", "production"}:
            raise ValueError("APP_ENV must be development, test, or production")
        return value

    @model_validator(mode="after")
    def production_guardrails(self):
        if self.app_env == "production":
            if self.jwt_secret.lower() in {"change-me", "changeme", "secret", "development-secret"}:
                raise ValueError("A unique JWT_SECRET is required in production")
            if self.database_url.startswith("sqlite:"):
                raise ValueError("Production requires PostgreSQL; SQLite is supported for local development only")
        return self


@lru_cache
def get_settings() -> Settings:
    return Settings()


settings = get_settings()
