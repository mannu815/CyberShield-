"""Minimal JSON-lines shipper for Wazuh alerts.json, Suricata eve.json, or Zeek JSON logs.
Run one shipper per source. HTTPS certificate verification remains enabled.
"""
import json, os, sys, time, urllib.request, urllib.error

API=os.environ.get("CYBERSHIELD_API_URL","").rstrip("/")
KEY=os.environ.get("CYBERSHIELD_SENSOR_KEY","")
SOURCE=os.environ.get("CYBERSHIELD_SENSOR_SOURCE","").lower()
LOG=os.environ.get("CYBERSHIELD_SENSOR_LOG","")
BATCH_SIZE=50
if not API.startswith("https://"):
    raise SystemExit("CYBERSHIELD_API_URL must use HTTPS")
if SOURCE not in {"wazuh","suricata","zeek"} or not KEY or not LOG:
    raise SystemExit("Set CYBERSHIELD_SENSOR_SOURCE, CYBERSHIELD_SENSOR_KEY and CYBERSHIELD_SENSOR_LOG")

def send(batch):
    body=json.dumps({"events":batch},separators=(",",":")).encode()
    req=urllib.request.Request(f"{API}/api/v1/detection/ingest/{SOURCE}",data=body,headers={"Content-Type":"application/json","X-Sensor-Key":KEY},method="POST")
    with urllib.request.urlopen(req,timeout=20) as response:
        return response.read(2048).decode("utf-8","replace")

# Start at EOF to avoid uploading historical logs on first launch. Pending batch is
# retained in memory and retried before reading more lines; no durable offset exists.
with open(LOG,"r",encoding="utf-8",errors="replace") as handle:
    handle.seek(0,2); batch=[]
    while True:
        if len(batch)>=BATCH_SIZE:
            try:
                print(send(batch),flush=True); batch=[]
            except urllib.error.HTTPError as exc:
                print(f"HTTP {exc.code}; verify sensor key, source and payload. Retrying in 10s.",file=sys.stderr,flush=True); time.sleep(10); continue
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                print(f"Connection failed; pending batch retained. Retrying in 5s: {exc}",file=sys.stderr,flush=True); time.sleep(5); continue
        line=handle.readline()
        if not line:
            if batch:
                try:
                    print(send(batch),flush=True); batch=[]
                except urllib.error.HTTPError as exc:
                    print(f"HTTP {exc.code}; final batch retained. Retrying in 10s.",file=sys.stderr,flush=True); time.sleep(10); continue
                except (urllib.error.URLError, TimeoutError, OSError) as exc:
                    print(f"Connection failed; pending batch retained. Retrying in 5s: {exc}",file=sys.stderr,flush=True); time.sleep(5); continue
            time.sleep(1); continue
        try:
            item=json.loads(line)
            if isinstance(item,dict): batch.append(item)
        except json.JSONDecodeError:
            continue
