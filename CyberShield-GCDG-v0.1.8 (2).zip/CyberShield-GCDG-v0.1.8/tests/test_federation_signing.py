from datetime import datetime, timezone, timedelta
import copy
import unittest

from app.global_grid.signing import Indicator, build_envelope, verify_envelope

NOW = datetime(2026, 11, 5, 12, 0, tzinfo=timezone.utc)
KEY = b"development-peer-secret-32-bytes-minimum!!"


def sample(**overrides):
    data = dict(
        value="203.0.113.25", indicator_type="ipv4", source_node="np-cert-01",
        confidence=0.91, first_seen="2026-11-05T11:00:00Z",
        expires_at="2026-11-06T11:00:00Z", handling="TLP:GREEN",
    )
    data.update(overrides)
    return Indicator(**data)


class FederationSigningTests(unittest.TestCase):
    def test_approved_indicator_round_trip(self):
        package = build_envelope(sample(), sender_node="np-cert-01", recipient_node="partner-02",
                                 policy_approved=True, peer_secret=KEY, now=NOW)
        result = verify_envelope(package, expected_sender="np-cert-01", expected_recipient="partner-02",
                                 peer_secret=KEY, now=NOW)
        self.assertEqual(result.value, "203.0.113.25")

    def test_unapproved_export_rejected(self):
        with self.assertRaises(PermissionError):
            build_envelope(sample(), sender_node="np-cert-01", recipient_node="partner-02",
                           policy_approved=False, peer_secret=KEY, now=NOW)

    def test_tampered_payload_rejected(self):
        package = build_envelope(sample(), sender_node="np-cert-01", recipient_node="partner-02",
                                 policy_approved=True, peer_secret=KEY, now=NOW)
        package["payload"]["value"] = "198.51.100.9"
        with self.assertRaises(PermissionError):
            verify_envelope(package, expected_sender="np-cert-01", expected_recipient="partner-02",
                            peer_secret=KEY, now=NOW)

    def test_wrong_recipient_rejected(self):
        package = build_envelope(sample(), sender_node="np-cert-01", recipient_node="partner-02",
                                 policy_approved=True, peer_secret=KEY, now=NOW)
        with self.assertRaises(PermissionError):
            verify_envelope(package, expected_sender="np-cert-01", expected_recipient="other-node",
                            peer_secret=KEY, now=NOW)

    def test_expired_indicator_rejected(self):
        with self.assertRaises(ValueError):
            build_envelope(sample(expires_at="2026-11-05T11:59:00Z"), sender_node="np-cert-01",
                           recipient_node="partner-02", policy_approved=True, peer_secret=KEY, now=NOW)

    def test_restricted_handling_rejected(self):
        with self.assertRaises(PermissionError):
            build_envelope(sample(handling="TLP:RED"), sender_node="np-cert-01",
                           recipient_node="partner-02", policy_approved=True, peer_secret=KEY, now=NOW)

    def test_stale_envelope_rejected(self):
        package = build_envelope(sample(), sender_node="np-cert-01", recipient_node="partner-02",
                                 policy_approved=True, peer_secret=KEY, now=NOW - timedelta(minutes=10))
        with self.assertRaises(PermissionError):
            verify_envelope(package, expected_sender="np-cert-01", expected_recipient="partner-02",
                            peer_secret=KEY, now=NOW)

    def test_short_peer_secret_rejected(self):
        with self.assertRaises(ValueError):
            build_envelope(sample(), sender_node="np-cert-01", recipient_node="partner-02",
                           policy_approved=True, peer_secret=b"short", now=NOW)


if __name__ == "__main__":
    unittest.main()
