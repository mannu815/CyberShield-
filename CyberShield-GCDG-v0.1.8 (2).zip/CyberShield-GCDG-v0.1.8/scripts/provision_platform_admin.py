"""Promote an existing account to sovereign platform_admin via local operator CLI.
Run only on the trusted control-plane host after verifying the account owner.
"""
import argparse
import sys
from pathlib import Path

# Ensure project root is in sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from sqlalchemy.orm import Session
from app.db.session import SessionLocal
from app.db.models import User, AuditLog

parser = argparse.ArgumentParser(description="Promote an account to platform_admin")
parser.add_argument("--email", required=False, help="Email of user to promote")
parser.add_argument("--yes", action="store_true", help="Confirm promotion non-interactively")
args = parser.parse_args()

if args.email:
    email = args.email.strip().lower()
else:
    email = input("Existing account email to promote: ").strip().lower()

if not args.yes:
    confirm = input("Type PROMOTE PLATFORM ADMIN to continue: ").strip()
    if confirm != "PROMOTE PLATFORM ADMIN":
        raise SystemExit("Cancelled")

with SessionLocal() as db:
    user = db.query(User).filter(User.email == email, User.is_active.is_(True)).first()
    if not user:
        raise SystemExit("Active user not found")
    print(f"Target: {user.full_name} <{user.email}> org_id={user.organization_id} current_role={user.role}")
    if not args.yes and input("Confirm exact target? Type YES: ").strip() != "YES":
        raise SystemExit("Cancelled")
    user.role = "platform_admin"
    db.add(AuditLog(organization_id=user.organization_id, actor_user_id=None, actor_email="local-operator", action="sovereign.platform_admin.provision", resource=f"user:{user.id}", outcome="success", client_ip="local", details={"target_email":user.email,"role":"platform_admin"}))
    db.commit()
    print("Role updated. Sign out and sign in again to obtain a token with the new role.")
