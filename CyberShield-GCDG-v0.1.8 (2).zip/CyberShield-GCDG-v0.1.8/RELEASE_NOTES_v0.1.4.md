# CyberShield GCDG v0.1.4 — Phase 4

## Delivered
- Wazuh, Suricata EVE JSON and Zeek JSON event normalizers.
- Organization-bound sensor credentials (SHA-256 hashes at rest; one-time secret display; admin disable).
- Authenticated, rate-limited event ingestion with batch and payload limits.
- Sensitive-field filtering, IP validation, event fingerprint deduplication and tenant-scoped storage.
- Starter deterministic detection rules and human-reviewed alert lifecycle.
- Event, alert, sensor and summary APIs.
- Minimal HTTPS JSON-lines shipper and operator documentation.

## Verification
- `python -m compileall -q app tests scripts`: passed.
- `JWT_SECRET='test-only-secret-value-32-characters-minimum' pytest -q --ignore=tests/test_security.py`: 38 passed.
- `tests/test_security.py` was not run because `pwdlib` is unavailable in the build environment; it is pinned in `requirements.txt` and will be installed by `setup_windows.bat`.
- No live Wazuh, Suricata or Zeek services were available. The release does not claim live sensor connectivity.
- ZIP integrity check and SHA-256 are provided with the handoff.

## Production gaps
- Existing databases need Alembic migrations; `create_all()` is not a schema migration tool.
- The included shipper has no durable offset checkpoint or guaranteed delivery. Use a production log forwarder for critical workloads.
- Detection rules are starter heuristics and require tuning and validation.
- Deploy behind TLS termination, a restrictive network policy, secrets management, backups and monitoring.
- No automated response, blocking, endpoint isolation or remote command execution.
