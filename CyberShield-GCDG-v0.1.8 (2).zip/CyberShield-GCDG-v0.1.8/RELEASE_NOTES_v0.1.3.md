# CyberShield GCDG v0.1.3 — Phase 3 Threat Intelligence MVP

## Added
- Bounded NVD CVE API 2.0 ingestion (up to 500 CVEs per run).
- CISA Known Exploited Vulnerabilities catalog ingestion.
- Optional MISP REST and OpenCTI GraphQL connectors.
- Organization-scoped CVE and IOC tables with source provenance and timestamps.
- Sync history, audit events, feed status, IOC exact-match correlation and manual sync endpoints.
- HTTPS-only operator-configured connectors, disabled redirects, bounded timeouts/response sizes and sync rate limits.
- Windows setup and run batch files.

## Verification
- Python compilation: passed.
- `pytest -q --ignore=tests/test_security.py`: 32 passed.
- Full suite: not verified in this build environment because `pwdlib` is not installed; `tests/test_security.py` cannot import. Install the pinned requirements and run the complete suite locally/CI.
- Live NVD, CISA KEV, MISP and OpenCTI connectivity was not tested. Configure credentials and run syncs in an authorized environment.

## Known limitations
- NVD is bounded to 500 records per run; no durable incremental cursor/scheduler.
- MISP imports up to 1,000 supported `to_ids` attributes per run.
- OpenCTI imports up to 100 indicators and intentionally skips complex STIX patterns.
- Exact IOC correlation is not yet linked to endpoint/network event streams or software inventory.
- Startup `create_all()` is still used; apply Alembic migrations before upgrading existing production databases.
- This is an MVP, not a certified national cyber-defence system.
