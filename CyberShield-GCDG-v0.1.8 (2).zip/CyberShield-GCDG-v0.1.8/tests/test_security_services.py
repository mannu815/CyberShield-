import pytest
from app.security_services import normalize_web_target, analyze_headers, analyze_cloud_config, ai_explanation

def test_normalize_target_adds_https():
    assert normalize_web_target("example.com") == "https://example.com"

def test_rejects_private_ip():
    with pytest.raises(ValueError):
        normalize_web_target("http://127.0.0.1")

def test_rejects_credentials_and_non_http():
    with pytest.raises(ValueError): normalize_web_target("https://user:pass@example.com")
    with pytest.raises(ValueError): normalize_web_target("ftp://example.com")

def test_missing_security_headers_create_potential_findings():
    findings = analyze_headers({}, "https")
    assert any(f["title"] == "Content Security Policy missing" and f["status"] == "potential" for f in findings)

def test_https_missing_creates_high_finding():
    findings = analyze_headers({}, "http")
    assert any(f["category"] == "transport" and f["severity"] == "high" for f in findings)

def test_cloud_config_detects_public_storage_and_wildcard_iam():
    findings = analyze_cloud_config({"resources": [
        {"type": "storageBucket", "properties": {"publicRead": True}},
        {"type": "iamPolicy", "properties": {"actions": ["*"]}},
    ]})
    assert len(findings) == 2

def test_ai_fallback_is_explicitly_not_generated():
    result = ai_explanation({"title": "Test", "severity": "low", "evidence": {}, "remediation": "Review"})
    assert result["generated"] is False
    assert result["provider"] == "deterministic-fallback"
