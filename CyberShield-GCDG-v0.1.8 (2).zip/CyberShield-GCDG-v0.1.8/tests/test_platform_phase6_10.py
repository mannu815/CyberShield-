from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.db.session import Base
from app.db.models import Organization, User, Asset, AssetProfile, ComplianceEvidence, GovernanceDecision, AIInvestigation


def test_phase6_to10_models_create_and_org_scope():
    engine=create_engine('sqlite:///:memory:')
    Base.metadata.create_all(engine)
    Session=sessionmaker(bind=engine); db=Session()
    org=Organization(name='Node A',slug='node-a'); db.add(org); db.flush()
    user=User(organization_id=org.id,email='admin@node-a.test',full_name='Admin',password_hash='unused',role='admin'); db.add(user); db.flush()
    asset=Asset(organization_id=org.id,name='Portal',asset_type='web',canonical_target='https://portal.example.test',authorization_reference='AUTH-1',created_by=user.id)
    db.add(asset); db.flush()
    db.add(AssetProfile(asset_id=asset.id,owner='IT',criticality='critical',environment='production',data_classification='restricted',tags=['internet-facing']))
    db.add(ComplianceEvidence(organization_id=org.id,framework='GCDG-Baseline',control_id='IAM-01',title='Strong authentication',status='partial',owner_user_id=user.id))
    db.add(GovernanceDecision(organization_id=org.id,policy_key='ioc-sharing',decision='approved',rationale='Approved by security committee',actor_user_id=user.id))
    db.commit()
    assert db.query(AssetProfile).filter_by(asset_id=asset.id).one().criticality=='critical'
    assert db.query(ComplianceEvidence).filter_by(organization_id=org.id).count()==1
    assert db.query(GovernanceDecision).filter_by(organization_id=org.id).count()==1
    assert db.query(AssetProfile).filter_by(asset_id=asset.id+1000).first() is None
    db.close(); engine.dispose()

