from fastapi import APIRouter, Depends, HTTPException, Request
from cryptography.fernet import Fernet
import secrets
from sqlalchemy.orm import Session
from app.audit import write_audit
from app.core.security import hash_password
from app.db.models import AuditLog, PeerNode, User
from app.db.session import get_db
from app.dependencies import require_roles
from app.schemas import UserCreate, UserRead

router = APIRouter(prefix="/admin", tags=["Administration"])


@router.post("/users", response_model=UserRead, status_code=201)
def create_user(payload: UserCreate, request: Request, db: Session = Depends(get_db), admin: User = Depends(require_roles("admin"))):
    email = str(payload.email).lower()
    exists = db.query(User).filter(User.organization_id == admin.organization_id, User.email == email).first()
    if exists:
        raise HTTPException(status_code=409, detail="A user with this email already exists in your organization")
    user = User(organization_id=admin.organization_id, email=email, full_name=payload.full_name.strip(), password_hash=hash_password(payload.password), role=payload.role)
    db.add(user)
    db.commit()
    db.refresh(user)
    write_audit(db, request, "admin.user.create", "success", user=admin, resource=f"user:{user.id}", details={"assigned_role": user.role})
    return user


@router.get("/users", response_model=list[UserRead])
def list_users(db: Session = Depends(get_db), admin: User = Depends(require_roles("admin"))):
    return db.query(User).filter(User.organization_id == admin.organization_id).order_by(User.id.asc()).all()


@router.get("/audit-logs")
def list_audit_logs(limit: int = 100, db: Session = Depends(get_db), admin: User = Depends(require_roles("admin"))):
    limit = max(1, min(limit, 200))
    rows = db.query(AuditLog).filter(AuditLog.organization_id == admin.organization_id).order_by(AuditLog.id.desc()).limit(limit).all()
    return [{"id": r.id, "created_at": r.created_at, "actor_email": r.actor_email, "action": r.action, "resource": r.resource, "outcome": r.outcome, "client_ip": r.client_ip, "details": r.details} for r in rows]


@router.post("/federation/peers", status_code=201)
def register_federation_peer(payload: dict, request: Request, db: Session = Depends(get_db), admin: User = Depends(require_roles("admin"))):
    """Create a disabled peer request; sovereign activation requires independent review."""
    from app.core.config import settings
    node_id = str(payload.get("node_id", "")).strip()
    display_name = str(payload.get("display_name", "")).strip()
    country_code = str(payload.get("country_code", "")).strip().upper()
    if not node_id or len(node_id) > 128 or not display_name or len(display_name) > 160 or len(country_code) != 2 or not country_code.isalpha():
        raise HTTPException(status_code=422, detail="Valid node_id, display_name and two-letter country_code are required")
    if not settings.federation_fernet_key:
        raise HTTPException(status_code=503, detail="Federation key encryption is not configured; set GCDG_FERNET_KEY")
    # Tenant administrators cannot approve a globally trusted sovereign peer.
    # Registration creates a disabled, unapproved request for out-of-band platform review.
    supplied_secret = payload.get("shared_secret")
    if supplied_secret is not None and (not isinstance(supplied_secret, str) or len(supplied_secret) < 32 or len(supplied_secret) > 256):
        raise HTTPException(status_code=422, detail="shared_secret must be 32-256 characters")
    if db.query(PeerNode).filter(PeerNode.node_id == node_id).first():
        raise HTTPException(status_code=409, detail="Peer node already exists")
    try:
        cipher = Fernet(settings.federation_fernet_key.encode())
    except Exception:
        raise HTTPException(status_code=503, detail="GCDG_FERNET_KEY is invalid; generate a Fernet key")
    secret = supplied_secret or secrets.token_urlsafe(48)
    peer = PeerNode(node_id=node_id, display_name=display_name, country_code=country_code,
                    shared_secret_ciphertext=cipher.encrypt(secret.encode()).decode(), enabled=False, policy_approved=False)
    db.add(peer); db.commit(); db.refresh(peer)
    write_audit(db, request, "federation.peer.registration_request", "success", user=admin, resource=f"peer:{peer.node_id}", details={"state":"pending_platform_review"})
    result = {"id": peer.id, "node_id": peer.node_id, "display_name": peer.display_name, "country_code": peer.country_code,
              "enabled": peer.enabled, "policy_approved": peer.policy_approved, "approval_state": "pending_platform_review"}
    if supplied_secret is None:
        result["shared_secret"] = secret
        result["warning"] = "Copy this secret securely now. Peer remains disabled until independent platform-level sovereign approval."
    else:
        result["secret_imported"] = True
    return result


@router.get("/federation/peers")
def list_federation_peers(db: Session = Depends(get_db), admin: User = Depends(require_roles("admin"))):
    rows = db.query(PeerNode).order_by(PeerNode.node_id.asc()).all()
    return [{"node_id": p.node_id, "display_name": p.display_name, "country_code": p.country_code,
             "enabled": p.enabled, "policy_approved": p.policy_approved, "created_at": p.created_at} for p in rows]
