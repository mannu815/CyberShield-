from __future__ import annotations
from datetime import datetime, timezone
from ipaddress import ip_address
from urllib.parse import urlparse
import re
import httpx
from app.core.config import settings

NVD_URL = "https://services.nvd.nist.gov/rest/json/cves/2.0"
KEV_URL = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
MAX_PAGE_SIZE = 100

class FeedError(RuntimeError):
    pass

def _configured_https_url(value: str, label: str) -> str:
    parsed = urlparse(value)
    if parsed.scheme != "https" or not parsed.hostname or parsed.username or parsed.password:
        raise FeedError(f"{label} must be a valid HTTPS URL")
    try:
        literal = ip_address(parsed.hostname)
        if not literal.is_global:
            raise FeedError(f"{label} cannot point to a non-public IP address")
    except ValueError:
        pass
    return value.rstrip("/")

def _get_json(url: str, *, headers: dict | None = None, params: dict | None = None) -> dict:
    timeout = max(3, min(int(settings.threat_intel_timeout_seconds), 30))
    limit = max(1024, min(int(settings.threat_intel_max_response_bytes), 8_000_000))
    try:
        with httpx.Client(timeout=timeout, follow_redirects=False, headers=headers) as client:
            with client.stream("GET", url, params=params) as response:
                response.raise_for_status()
                content_type = response.headers.get("content-type", "")
                if "json" not in content_type.lower():
                    raise FeedError("Feed did not return JSON")
                chunks = []
                total = 0
                for chunk in response.iter_bytes():
                    total += len(chunk)
                    if total > limit:
                        raise FeedError("Feed response exceeded configured size limit")
                    chunks.append(chunk)
                import json
                data = json.loads(b"".join(chunks))
                if not isinstance(data, dict):
                    raise FeedError("Feed JSON root must be an object")
                return data
    except (httpx.HTTPError, ValueError) as exc:
        raise FeedError(f"Feed request failed: {type(exc).__name__}") from exc

def _post_json(url: str, *, headers: dict, payload: dict) -> dict:
    timeout = max(3, min(int(settings.threat_intel_timeout_seconds), 30))
    limit = max(1024, min(int(settings.threat_intel_max_response_bytes), 8_000_000))
    try:
        with httpx.Client(timeout=timeout, follow_redirects=False, headers=headers) as client:
            response = client.post(url, json=payload)
            response.raise_for_status()
            if len(response.content) > limit:
                raise FeedError("Feed response exceeded configured size limit")
            data = response.json()
            if not isinstance(data, dict): raise FeedError("Feed JSON root must be an object")
            return data
    except (httpx.HTTPError, ValueError) as exc:
        raise FeedError(f"Feed request failed: {type(exc).__name__}") from exc

def _parse_date(value: str | None):
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(value.replace("Z", "+00:00"))
        return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)
    except (ValueError, TypeError):
        return None

def fetch_kev() -> list[dict]:
    data = _get_json(KEV_URL)
    rows = data.get("vulnerabilities", [])
    if not isinstance(rows, list):
        raise FeedError("CISA KEV schema was not recognized")
    output = []
    for item in rows[:10000]:
        if not isinstance(item, dict) or not re.fullmatch(r"CVE-\d{4}-\d{4,}", str(item.get("cveID", ""))):
            continue
        output.append({"cve_id": item["cveID"], "source": "cisa_kev", "summary": str(item.get("shortDescription", ""))[:4000],
                       "severity": "high", "cvss_score": "", "known_exploited": True,
                       "references": ["https://www.cisa.gov/known-exploited-vulnerabilities-catalog"],
                       "metadata": {"vendorProject": item.get("vendorProject"), "product": item.get("product"),
                                    "dateAdded": item.get("dateAdded"), "dueDate": item.get("dueDate"),
                                    "knownRansomwareCampaignUse": item.get("knownRansomwareCampaignUse")}})
    return output

def fetch_nvd(max_pages: int = 2) -> list[dict]:
    headers = {"apiKey": settings.nvd_api_key} if settings.nvd_api_key else {}
    output = []
    for page in range(max(1, min(max_pages, 5))):
        data = _get_json(NVD_URL, headers=headers, params={"resultsPerPage": MAX_PAGE_SIZE, "startIndex": page * MAX_PAGE_SIZE})
        rows = data.get("vulnerabilities", [])
        if not isinstance(rows, list):
            raise FeedError("NVD schema was not recognized")
        for wrapper in rows:
            cve = wrapper.get("cve", {}) if isinstance(wrapper, dict) else {}
            cve_id = cve.get("id", "")
            if not re.fullmatch(r"CVE-\d{4}-\d{4,}", str(cve_id)):
                continue
            descriptions = cve.get("descriptions", [])
            summary = next((d.get("value", "") for d in descriptions if d.get("lang") == "en"), "")
            score = ""
            severity = "unknown"
            metrics = cve.get("metrics", {})
            for metric_key in ("cvssMetricV31", "cvssMetricV30", "cvssMetricV2"):
                entries = metrics.get(metric_key, [])
                if entries:
                    cvss = entries[0].get("cvssData", {})
                    score = str(cvss.get("baseScore", ""))
                    severity = str(entries[0].get("baseSeverity", cvss.get("baseSeverity", "unknown"))).lower()
                    break
            refs = [r.get("url") for r in cve.get("references", []) if isinstance(r, dict) and str(r.get("url", "")).startswith("https://")][:30]
            output.append({"cve_id": cve_id, "source": "nvd", "summary": str(summary)[:4000], "severity": severity,
                           "cvss_score": score, "known_exploited": False, "references": refs,
                           "metadata": {"published": cve.get("published"), "lastModified": cve.get("lastModified"),
                                        "vulnStatus": cve.get("vulnStatus")}})
        if len(rows) < MAX_PAGE_SIZE or (page + 1) * MAX_PAGE_SIZE >= int(data.get("totalResults", 0)):
            break
    return output

def _normalize_misp_attribute(attr: dict) -> dict | None:
    kind = str(attr.get("type", "" )).lower()
    value = str(attr.get("value", "")).strip()
    mapping = {"ip-src": "ip", "ip-dst": "ip", "domain": "domain", "hostname": "domain", "url": "url",
               "md5": "md5", "sha1": "sha1", "sha256": "sha256", "email-src": "email", "email-dst": "email"}
    indicator_type = mapping.get(kind)
    if not indicator_type or not value or len(value) > 2048:
        return None
    if indicator_type == "ip":
        try: value = str(ip_address(value))
        except ValueError: return None
    elif indicator_type == "domain":
        value = value.lower().rstrip(".")
        if len(value) > 253 or not re.fullmatch(r"(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", value): return None
    elif indicator_type in {"md5", "sha1", "sha256"}:
        expected = {"md5": 32, "sha1": 40, "sha256": 64}[indicator_type]
        if not re.fullmatch(rf"[a-fA-F0-9]{{{expected}}}", value): return None
        value = value.lower()
    return {"indicator_type": indicator_type, "value": value, "confidence": 70,
            "threat_label": str(attr.get("category", "MISP indicator"))[:160],
            "description": str(attr.get("comment", ""))[:2000], "tags": [],
            "references": [], "raw_metadata": {"to_ids": bool(attr.get("to_ids", False)), "uuid": attr.get("uuid")}}

def fetch_misp() -> list[dict]:
    base = _configured_https_url(settings.misp_url, "MISP_URL")
    if not settings.misp_api_key:
        raise FeedError("MISP_API_KEY is not configured")
    data = _post_json(base + "/attributes/restSearch", headers={"Authorization": settings.misp_api_key,
                      "Accept": "application/json", "Content-Type": "application/json"}, payload={"limit": 1000, "page": 1, "to_ids": 1})
    rows = data.get("response", {}).get("Attribute", [])
    if not isinstance(rows, list): raise FeedError("MISP response schema was not recognized")
    output = []
    for attr in rows[:1000]:
        if isinstance(attr, dict):
            normalized = _normalize_misp_attribute(attr)
            if normalized: output.append(normalized)
    return output

def fetch_opencti() -> list[dict]:
    base = _configured_https_url(settings.opencti_url, "OPENCTI_URL")
    if not settings.opencti_token: raise FeedError("OPENCTI_TOKEN is not configured")
    query = "query GCDGIndicators { indicators(first: 100) { edges { node { id name pattern description confidence x_opencti_score } } } }"
    data = _post_json(base + "/graphql", headers={"Authorization": "Bearer " + settings.opencti_token,
                      "Accept": "application/json", "Content-Type": "application/json"}, payload={"query": query})
    if data.get("errors"): raise FeedError("OpenCTI returned GraphQL errors")
    edges = data.get("data", {}).get("indicators", {}).get("edges", [])
    output = []
    for edge in edges[:100]:
        node = edge.get("node", {}) if isinstance(edge, dict) else {}
        pattern = str(node.get("pattern", ""))
        # Only accept simple STIX IPv4/domain/hash observables; complex patterns need a dedicated parser.
        match = re.fullmatch(r"\[ipv4-addr:value = '([^']+)'\]", pattern)
        kind = "ip"
        if not match:
            match = re.fullmatch(r"\[domain-name:value = '([^']+)'\]", pattern); kind = "domain"
        if not match:
            match = re.fullmatch(r"\[file:hashes.'SHA-256' = '([a-fA-F0-9]{64})'\]", pattern); kind = "sha256"
        if not match: continue
        value = match.group(1)
        if kind == "ip":
            try: value = str(ip_address(value))
            except ValueError: continue
        if kind == "domain":
            value = value.lower().rstrip(".")
            if not re.fullmatch(r"(?=.{1,253}$)([a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", value): continue
        output.append({"indicator_type": kind, "value": value, "confidence": max(0, min(100, int(node.get("confidence") or node.get("x_opencti_score") or 60))),
                       "threat_label": str(node.get("name", "OpenCTI indicator"))[:160], "description": str(node.get("description", ""))[:2000],
                       "tags": [], "references": [], "raw_metadata": {"opencti_id": node.get("id")}})
    return output
